# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later - see LICENSE file
# Part of SuperLocalMemory V3 | https://qualixar.com | https://varunpratap.com

"""SLM Unified Daemon — single FastAPI process for ALL routes.

Replaces the dual-process architecture (stdlib daemon + FastAPI dashboard).
One MemoryEngine singleton shared by CLI, MCP, Dashboard, and Mesh routes.

Architecture:
  slm serve       → starts unified daemon (uvicorn on port 8765)
  slm remember X  → HTTP POST to daemon → instant
  slm recall X    → HTTP GET from daemon → instant
  slm dashboard   → opens browser to http://localhost:8765
  slm serve stop  → POST /stop → graceful uvicorn shutdown

Port 8765: primary (dashboard + API + daemon routes)
Port 8767: TCP redirect for backward compat (deprecated)

24/7 by default. Opt-in auto-kill: --idle-timeout=1800

Part of Qualixar | Author: Varun Pratap Bhardwaj
License: AGPL-3.0-or-later
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import functools
import hashlib
import json
import logging
import os
import signal
import sqlite3
import sys
import threading
import time
import uuid
from contextlib import AsyncExitStack, asynccontextmanager
from dataclasses import replace
from pathlib import Path
from typing import Optional

# v3.6.7: Tell mcp/server.py it is being imported inside the daemon process.
# This suppresses the three side-effect threads (mcp-warmup, parent-watchdog,
# stdin-eof-monitor) that are harmful when the MCP server runs embedded.
# Must be set BEFORE any import of superlocalmemory.mcp.server.
os.environ.setdefault("SLM_MCP_EMBEDDED", "1")

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from pydantic import BaseModel, field_validator

from superlocalmemory.core.config import CANONICAL_RECALL_LIMIT
from superlocalmemory.infra.daemon_identity import (
    DaemonDescriptor,
    build_descriptor,
    clear_descriptor,
    descriptor_path,
    write_descriptor,
)
from superlocalmemory.infra.data_root import (
    assert_no_durable_root_conflict,
    canonical_data_root,
    state_path,
)


def _notify_migration_applied(
    applied: list,
    elapsed: float,
    backup_dir: "Path | None" = None,
) -> None:
    """Print a one-line confirmation after migrations complete successfully.

    Written to stdout so it is visible in daemon.log and in interactive runs.
    """
    count = len(applied)
    if count == 0:
        return
    parts = [f"[SLM] {count} migration(s) applied in {elapsed:.1f}s."]
    if backup_dir is not None:
        parts.append(f"Backup: {backup_dir}")
    print(" ".join(parts), flush=True)


def _write_migration_error_log(
    failed: list,
    backup_dir: "Path | None",
    slm_home: "Path | None" = None,
    applied: "list | None" = None,
) -> "Path":
    """Write a migration-error-{timestamp}.log to the SLM home directory.

    Returns the Path of the written log file.
    """
    import datetime

    if slm_home is None:
        slm_home = canonical_data_root()

    slm_home.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    log_path = slm_home / f"migration-error-{ts}.log"

    lines = [
        f"Migration error — {ts}",
        f"Failed: {', '.join(str(f) for f in failed)}",
    ]
    # An upgrade is applied step by step and is deliberately non-fatal: some
    # steps can succeed while a later one fails. Saying "your data was not
    # modified" whenever a snapshot exists was therefore untrue in exactly the
    # case that matters — and a user who believes nothing changed may delete the
    # snapshot to reclaim space.
    if applied:
        lines.append(f"Applied before the failure: {', '.join(str(a) for a in applied)}")
        lines.append(
            "YOUR DATABASE WAS PARTIALLY CHANGED. The steps listed above "
            "completed; the ones under 'Failed' did not."
        )
    elif applied is not None:
        lines.append("No steps completed, so your database was not changed.")
    if backup_dir is not None:
        lines.append(f"Snapshot of the state before the upgrade: {backup_dir}")
        lines.append(
            "That snapshot is intact and can be restored. Keep it until you are "
            "satisfied your data is correct."
        )
    else:
        lines.append(
            "NO SNAPSHOT WAS TAKEN for this attempt — do not assume a recovery "
            "copy exists. Check for earlier snapshots before changing anything."
        )
    lines.append("")
    lines.append("To diagnose, run: slm doctor")

    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return log_path


def _notify_windows_user(message: str) -> None:
    """Best-effort notification on Windows.  Silent no-op on other platforms."""
    import sys

    if sys.platform != "win32":
        return

    # Attempt 1 — Windows MessageBox via PowerShell
    try:
        import subprocess

        safe_msg = message.replace("'", "").replace('"', "")
        subprocess.run(
            [
                "powershell",
                "-Command",
                "[System.Reflection.Assembly]::LoadWithPartialName"
                "('System.Windows.Forms') | Out-Null; "
                f"[System.Windows.Forms.MessageBox]::Show('{safe_msg}', "
                "'SuperLocalMemory')",
            ],
            check=False,
            timeout=5,
        )
        return
    except Exception:
        pass

    # Attempt 2 — Windows Application EventLog
    try:
        import subprocess

        subprocess.run(
            [
                "eventcreate",
                "/T", "INFORMATION",
                "/ID", "1001",
                "/L", "APPLICATION",
                "/SO", "SuperLocalMemory",
                "/D", message[:512],
            ],
            check=False,
            timeout=5,
        )
    except Exception:
        pass  # best-effort only


def _learning_db_for_config(config) -> Path:
    """Single learning.db path for daemon migration + engine (F-05).

    Always resolves through ``canonical_data_root(configured_base_dir=...)`` so
    a custom ``SLMConfig.base_dir`` without env aliases cannot diverge from the
    engine's ``config.base_dir / "learning.db"``.
    """
    base = getattr(config, "base_dir", None)
    root = canonical_data_root(configured_base_dir=base)
    return root / "learning.db"


def _memory_db_for_config(config) -> Path:
    """Memory DB path aligned with :func:`_learning_db_for_config`."""
    base = getattr(config, "base_dir", None)
    root = canonical_data_root(configured_base_dir=base)
    return root / "memory.db"
from superlocalmemory.learning.source_quality import (
    SourceQualityRepairUnavailable,
    enumerate_source_quality_repair_profiles,
    repair_historical_source_quality,
)

# D-02 fix: import at module load so the reference survives interpreter teardown.
# A lazy import inside the shutdown path races the namespace-cleanup phase on
# CPython and can raise ImportError: "cannot import name 'trigram_index'".
try:
    from superlocalmemory.learning import trigram_index as _trigram_index_mod
except ImportError:  # pragma: no cover — defensive for stripped installs
    _trigram_index_mod = None  # type: ignore[assignment]

# D-03 fix: move this import to module top so the already-compiled .pyc object
# is used at shutdown time. A lazy import of a source .py during interpreter
# shutdown on macOS triggers TCC xattr checks and can raise PermissionError.
try:
    from superlocalmemory.hooks._outcome_common import _perf_log_flush as _perf_log_flush_fn
except ImportError:  # pragma: no cover — defensive for stripped installs
    _perf_log_flush_fn = None  # type: ignore[assignment]

logger = logging.getLogger("superlocalmemory.unified_daemon")

_DEFAULT_PORT = 8765
_LEGACY_PORT = 8767
_ACTIVE_DAEMON_DESCRIPTOR: DaemonDescriptor | None = None
_SOURCE_QUALITY_MAX_BATCH_SIZE = 250
_SOURCE_QUALITY_PROFILE_REFRESH_SECONDS = 60.0
_FACT_ENTITY_REPAIR_MIN_RETRY_SECONDS = 0.05
_FACT_ENTITY_REPAIR_MAX_RETRY_SECONDS = 30.0
# How long a write may spend making itself findable by meaning before the
# receipt goes out. Storing a memory has a 1.5 s ceiling, and this is a ceiling
# rather than a target: the cost of coming in under it is a memory that can only
# be found by quoting its own wording, which is not how anyone asks. So the
# window is most of the budget, not a token amount of it. ``wait=true`` is still
# never permission to hold the event loop open indefinitely — past this the
# background pass finishes the job.
# The ceiling for a whole store request, shared by the durable write and the
# window that makes the memory findable by meaning. Both are sequential, so the
# second gets what the first left rather than a fresh grant.
_REMEMBER_TOTAL_CEILING_SECONDS = 1.5
_REMEMBER_ENRICHMENT_WAIT_SECONDS = 1.2

# Enrichment runs off the event loop, but NOT on the loop's default executor.
# `asyncio.to_thread` uses that default pool, so N simultaneous writers really did
# create N threads — and every other handler that borrows the same pool queued
# behind them. One shared, small pool bounds the cost of a burst: past its width
# the extra callers miss their deadline and defer, which is the intended
# degradation, instead of multiplying threads.
_ENRICHMENT_WORKERS = 2
_enrichment_pool: "concurrent.futures.ThreadPoolExecutor | None" = None
_enrichment_pool_lock = threading.Lock()

# Bounds how much enrichment may be in flight at once. A ThreadPoolExecutor
# queues without limit, so bounding the pool's WIDTH does not bound what can be
# handed to it: a burst of writers all submit, the first two run, and the rest sit
# in a queue nobody is waiting for any more — then wake up and write to the
# database after their callers have already been answered. A permit is taken
# before submitting and released by the worker when it has really finished, so at
# most `_ENRICHMENT_WORKERS` pieces of work exist at once and a caller that
# cannot get one is told immediately instead of being queued.
_enrichment_semaphore = threading.Semaphore(_ENRICHMENT_WORKERS)

# Set once the pool has been shut down, and never cleared. Without it, a caller
# that passed the unlocked check below arrives after shutdown, finds None, and
# builds a replacement pool that the completed shutdown will never reach.
_enrichment_pool_closed = False


class _EnrichmentAtCapacity(Exception):
    """No permit was free, so nothing was submitted.

    Its own type, so that "we chose not to start" is never reported through the
    same path as "it started and then failed" — those are different events and
    only one of them is worth a warning about degradation.
    """


def _enrichment_executor():
    """The one pool inline enrichment may use. Created on first need.

    Raises ``RuntimeError`` once the pool has been shut down. It deliberately
    does not return ``None`` on that path: ``run_in_executor(None, ...)`` means
    *the event loop's default executor*, which is the unbounded-thread behaviour
    this pool exists to replace, so a None here would silently reintroduce it at
    exactly the moment the process is trying to stop.
    """
    global _enrichment_pool
    # Everything happens under the lock, including the read that is returned. An
    # earlier version checked the closed flag only on the create branch and then
    # returned the global, so a caller that found a live pool, lost the CPU, and
    # resumed after shutdown returned None — and None means the event loop's own
    # default executor, unbounded and shared with every other handler. That is
    # the precise failure this function exists to prevent, reintroduced at the
    # one moment it matters.
    with _enrichment_pool_lock:
        if _enrichment_pool_closed:
            raise RuntimeError("enrichment pool is shut down")
        if _enrichment_pool is None:
            _enrichment_pool = concurrent.futures.ThreadPoolExecutor(
                max_workers=_ENRICHMENT_WORKERS,
                thread_name_prefix="slm-enrich",
            )
        pool = _enrichment_pool
    if pool is None:  # pragma: no cover — belt and braces around the invariant
        raise RuntimeError("enrichment pool is unavailable")
    return pool


def _open_enrichment_pool() -> None:
    """Allow the pool to be created again, for a fresh run in this process.

    The closed flag has to survive shutdown — that is its whole purpose — so
    something has to clear it when a new run legitimately begins. Without this a
    second startup in one process (a restart, or a test that builds the app more
    than once) would find enrichment permanently refused and every write would
    come back findable by wording only, with nothing in the logs to explain it.
    """
    global _enrichment_pool_closed, _enrichment_semaphore
    with _enrichment_pool_lock:
        _enrichment_pool_closed = False
        # A fresh run starts with its full capacity. Shutdown cancels work that
        # was queued and never started, and a task that never starts never runs
        # the release in its finally — so permits taken by cancelled work are
        # gone. Without this reset the next run in the same process would run at
        # reduced capacity, or none at all, and the only symptom would be every
        # write coming back findable by wording with nothing in the log.
        _enrichment_semaphore = threading.Semaphore(_ENRICHMENT_WORKERS)


def _enrich_and_release(
    engine, fact_ids: list[str], budget: float, profile_id: str | None = None,
) -> int:
    """Run inline enrichment, releasing the permit only when it is really done.

    The permit has to be released here rather than by the caller. A caller that
    stops waiting at its own deadline has not finished the work — the worker is
    still holding a pool thread — so releasing on the caller's timeout would let
    the next request submit into a pool that is still fully occupied, which is
    the unbounded queueing this permit exists to prevent.

    ``profile_id`` is the write-target of the request these facts came from: a
    per-request routed write names a profile the engine's active pointer does
    not point at, and the enrichment lookups are tenant-scoped — without the
    routed profile the facts resolve to None and every routed write reports
    "findable by wording" no matter what. ``None`` (legacy path) enriches the
    active profile.
    """
    try:
        return engine.enrich_new_facts_now(
            fact_ids, timeout_s=budget, profile_id=profile_id,
        )
    finally:
        _enrichment_semaphore.release()


def _shutdown_enrichment_pool_if_created() -> None:
    """Shut down the enrichment pool if it was ever created.

    Safe to call when the pool was never created (no-op) and safe to call
    twice (second call is a no-op because the pool is set to None under the
    lock before shutdown is called).

    cancel_futures=True drops any work that is still queued but has not yet
    started.  Workers already inside embed() will finish their current call
    and then stop; they do not block the caller because wait=False.
    """
    global _enrichment_pool, _enrichment_pool_closed
    with _enrichment_pool_lock:
        # Marked closed under the same lock that guards creation, so a caller
        # already past the unlocked check cannot build a replacement pool that
        # this shutdown has already walked past.
        _enrichment_pool_closed = True
        pool = _enrichment_pool
        _enrichment_pool = None
    if pool is not None:
        pool.shutdown(wait=False, cancel_futures=True)
_SENSITIVE_READ_PREFIXES = (
    "/api/memories", "/api/facts", "/api/clusters", "/api/graph",
    "/api/v3/associations", "/api/v3/core-memory",
    "/api/v3/soft-prompts", "/api/v3/dashboard", "/api/v3/mode",
    "/api/v3/embedding/config", "/api/v3/scope/config",
    "/api/v3/storage/config", "/api/v3/daemon/config",
    "/api/v3/mesh/config", "/api/v3/trust/config",
    "/api/v3/forgetting/config", "/api/v3/mcp/profiles",
    "/api/learning", "/api/behavioral",
    # Event stream, agent activity, trust signals, and v3 profiling data
    # expose cross-agent coordination signals and behavioral profiles.
    "/events", "/api/events", "/api/agents", "/api/trust/",
    "/api/v3/abstraction", "/api/v3/insights",
)
_SENSITIVE_READ_EXACT_PATHS = (
    "/api/search", "/api/v3/recall/trace", "/api/patterns",
    "/api/feedback/stats", "/api/stats", "/api/timeline",
)


def _is_sensitive_dashboard_read(method: str, path: str) -> bool:
    return (
        method == "GET"
        and (
            path.startswith(_SENSITIVE_READ_PREFIXES)
            or path in _SENSITIVE_READ_EXACT_PATHS
            or path.startswith("/api/v3/recall")
        )
    )


def _rbac_read_gate(request, app_state):
    """RBAC gate for sensitive content reads. Returns a JSONResponse to reject,
    or None to allow. No-op unless RBAC is active (>=1 user)."""
    from fastapi.responses import JSONResponse
    rbac = getattr(app_state, "rbac", None)
    if rbac is None:
        return None
    try:
        active = rbac.user_count() > 0
    except Exception:
        # Fail CLOSED: if we cannot determine RBAC state we must not silently
        # allow reads (a DB error would otherwise open the whole read surface).
        return JSONResponse(status_code=503,
                            content={"error": "authorization temporarily unavailable"})
    if not active:
        return None  # single-operator install — reads are open
    token = (request.headers.get("x-slm-user-session", "")
             or (request.cookies.get("slm_session", "") if request.cookies else ""))
    user = rbac.resolve_session(token) if token else None
    if user is None:
        if rbac.require_login():
            return JSONResponse(status_code=401,
                                content={"error": "Login required to read memory."})
        return None  # owner/operator, personal mode
    from superlocalmemory.access.rbac import Permission
    from superlocalmemory.server.routes.helpers import get_active_profile
    if rbac.has_permission(user["user_id"], get_active_profile(), Permission.READ):
        return None
    return JSONResponse(status_code=403,
                        content={"error": "Your role cannot read this workspace."})


# Adapter process-control routes that change running state (start/stop) or
# persistence state (enable/disable). These require WRITE permission.
_ADAPTER_CONTROL_PREFIXES = (
    "/api/adapters/enable",
    "/api/adapters/disable",
    "/api/adapters/start",
    "/api/adapters/stop",
)


def _is_adapter_control_mutation(method: str, path: str) -> bool:
    return (
        method in ("POST", "PUT", "PATCH", "DELETE")
        and path.startswith(_ADAPTER_CONTROL_PREFIXES)
    )


def _rbac_write_gate(request, app_state):
    """RBAC gate for state-changing dashboard mutations. Returns a JSONResponse
    to reject, or None to allow. No-op unless RBAC is active (>=1 user).

    Mirror of _rbac_read_gate but checks WRITE instead of READ permission.
    Fails closed on RBAC errors (503), consistent with _rbac_read_gate.
    """
    from fastapi.responses import JSONResponse
    rbac = getattr(app_state, "rbac", None)
    if rbac is None:
        return None
    try:
        active = rbac.user_count() > 0
    except Exception:
        return JSONResponse(status_code=503,
                            content={"error": "authorization temporarily unavailable"})
    if not active:
        return None  # single-operator install — mutations are open
    token = (request.headers.get("x-slm-user-session", "")
             or (request.cookies.get("slm_session", "") if request.cookies else ""))
    user = rbac.resolve_session(token) if token else None
    if user is None:
        if rbac.require_login():
            return JSONResponse(status_code=401,
                                content={"error": "Login required to perform this action."})
        return None  # owner/operator, personal mode
    from superlocalmemory.access.rbac import Permission
    from superlocalmemory.server.routes.helpers import get_active_profile
    if rbac.has_permission(user["user_id"], get_active_profile(), Permission.WRITE):
        return None
    return JSONResponse(status_code=403,
                        content={"error": "Your role cannot modify this workspace."})


def _configured_daemon_port() -> int:
    """Return the configured bind port, falling back safely to the default."""
    try:
        return int(os.environ.get("SLM_DAEMON_PORT", "") or _DEFAULT_PORT)
    except ValueError:
        return _DEFAULT_PORT


# Paths that must remain reachable when required schema migrations have failed.
# All other paths are feature routes subject to the readiness gate.
_MIGRATION_EXEMPT_PATH_PREFIXES: tuple[str, ...] = (
    "/health",
    "/status",
    "/api/v3/health",
    "/api/health",
    "/api/status",
    "/api/v3/components",    # component status/heal endpoints
    "/api/v3/repair",
    "/api/repair",
    "/api/version",          # version probe (non-schema-dependent)
    "/static",               # UI assets (served regardless of schema state)
)


def _serving_blocked_by(migration_result: dict) -> list[str]:
    """Failed migrations that should stop this daemon serving. Fail-closed.

    A failed migration used to 503 every route without asking what had failed.
    For a missing table that is right. For a data invariant that ordinary use can
    re-violate it is not: one drifted row made the whole store unreachable until
    somebody restarted it by hand, and the restart fixed nothing that a
    background repair would not have fixed on its own.

    A migration may answer for itself by exposing ``blocks_serving(conn)``.
    Anything that does not is treated as blocking, so this cannot quietly open a
    door for a migration nobody has thought about.
    """
    failed = list(migration_result.get("failed") or [])
    if not failed:
        return []
    try:
        import sqlite3

        from superlocalmemory.infra.data_root import state_path
        from superlocalmemory.storage._migration_internals import _MODULES
    except Exception:  # noqa: BLE001 — never let this decide by crashing
        return failed

    blocking: list[str] = []
    for name in failed:
        decide = getattr(_MODULES.get(name), "blocks_serving", None)
        if not callable(decide):
            blocking.append(name)
            continue
        try:
            db = state_path("memory.db")
            conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            try:
                if decide(conn):
                    blocking.append(name)
            finally:
                conn.close()
        except Exception:  # noqa: BLE001 — unknown means blocking
            blocking.append(name)
    return blocking


def _is_migration_exempt_path(path: str) -> bool:
    """Return True for health, status, and repair paths that must stay reachable
    even when the daemon reports a schema migration failure.

    All other paths are considered feature routes whose correctness depends on
    the schema being fully applied.
    """
    return any(
        path == prefix or path.startswith(prefix + "/") or path.startswith(prefix + "?")
        for prefix in _MIGRATION_EXEMPT_PATH_PREFIXES
    )


def _process_descriptor(port: int, version: str, state: str) -> DaemonDescriptor:
    """Return this process's stable namespace/instance identity."""
    global _ACTIVE_DAEMON_DESCRIPTOR
    if _ACTIVE_DAEMON_DESCRIPTOR is None:
        descriptor = build_descriptor(
            port=port,
            version=version,
            pid=os.getpid(),
            instance_id=os.environ.get("SLM_DAEMON_INSTANCE_ID") or None,
            capability=os.environ.get("SLM_DAEMON_CAPABILITY") or None,
            state=state,
        )
        os.environ["SLM_DAEMON_INSTANCE_ID"] = descriptor.instance_id
        os.environ["SLM_DAEMON_CAPABILITY"] = descriptor.capability
        _ACTIVE_DAEMON_DESCRIPTOR = descriptor
    elif _ACTIVE_DAEMON_DESCRIPTOR.state != state:
        _ACTIVE_DAEMON_DESCRIPTOR = replace(
            _ACTIVE_DAEMON_DESCRIPTOR,
            state=state,
            port=port,
            version=version,
        )
    return _ACTIVE_DAEMON_DESCRIPTOR


def _publish_process_descriptor(
    port: int, version: str, state: str,
) -> DaemonDescriptor:
    """Atomically publish identity plus one-release PID/port mirrors."""
    descriptor = _process_descriptor(port, version, state)
    write_descriptor(descriptor)
    pid_file = descriptor_path().with_name("daemon.pid")
    port_file = descriptor_path().with_name("daemon.port")
    pid_file.write_text(str(descriptor.pid))
    port_file.write_text(str(descriptor.port))
    return descriptor


def _cleanup_process_descriptor(descriptor: DaemonDescriptor | None) -> None:
    """Remove lifecycle state only when this process still owns the instance."""
    if descriptor is None or not clear_descriptor(descriptor.instance_id):
        return
    for path, expected in (
        (descriptor_path().with_name("daemon.pid"), str(descriptor.pid)),
        (descriptor_path().with_name("daemon.port"), str(descriptor.port)),
    ):
        try:
            if path.read_text().strip() == expected:
                path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class RememberRequest(BaseModel):
    content: str
    tags: str = ""
    metadata: dict | None = None  # v3.4.26: pass-through from MCP pool_store
    idempotency_key: str | None = None
    session_id: str = ""
    # Per-request profile routing (spec section 3/5): a non-empty profile_id
    # routes THIS ONE write to that profile — pure routing, the ProfileRuntime
    # active pointer never moves, and an unknown id is a 404 (never an
    # implicit creation). Empty/absent keeps the legacy path: the active
    # profile. The old 409 stale-client guard remains in place only for that
    # empty legacy shape and is unreachable for routed requests (routing
    # replaced the guard for them).
    profile_id: str = ""
    #: WHEN this memory is about, as distinct from when it was written.
    #:
    #: The internal admission record has carried this field all along and this
    #: model never had it, so every memory arriving over HTTP — which is every
    #: memory, from the CLI, the tool interface and the dashboard alike — was
    #: stamped with its ingestion date. Measured on the author's store: 200 of
    #: the 200 most recent facts have an observation_date, and 196 of them are
    #: the day they were written. A store that cannot be told "this happened in
    #: March" cannot answer a question about March.
    #:
    #: Empty means "today", the previous behaviour. Format is YYYY-MM-DD or a
    #: full ISO 8601 timestamp.
    session_date: str = ""

    @field_validator("session_date")
    @classmethod
    def _session_date_is_a_date(cls, value: str) -> str:
        """Reject a malformed date rather than ignore it.

        Dropping it silently would leave the caller believing the date was
        recorded while the memory quietly filed itself under today — which is
        the exact failure this field exists to fix, reintroduced one layer up.
        Rejecting is recoverable: the caller sees the error and resends.

        ISO ONLY, DELIBERATELY, even though this system ships a parser that is
        far more permissive. ``encoding/temporal_parser.parse_session_date``
        accepts "May 8, 2026", "1:56 pm on 8 May, 2026", "14/03/2026", and also
        "last tuesday" and "March 2026" — and those last two are why it is not
        used here. Asked on 2026-08-21 it resolves "last tuesday" to
        **2026-08-25**, four days into the future, and "March 2026" to the 21st,
        a day it invents. Accepting either at this boundary would file a memory
        under a confidently wrong date, silently, which is precisely the class
        of defect this field was added to remove.

        The caller here is a program — the command line, the tool interface, the
        dashboard — not a person typing. ISO is the right contract for a
        program, and a caller holding a human-typed date can run it through the
        parser itself and send the result.
        """
        if not value:
            return value
        from datetime import datetime as _dt

        text = value.strip()
        try:
            _dt.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            raise ValueError(
                "session_date must be YYYY-MM-DD or a full ISO 8601 timestamp; "
                f"got {value!r}. To accept looser human phrasing, parse it "
                "first with TemporalParser.parse_session_date and send the ISO "
                "result — but check what it returns, because it resolves "
                "relative phrases against today and can answer with a future "
                "date."
            ) from None
        return text
    # v3.6.15 multi-scope: visibility of the new memory. ``None`` scope means
    # "use the configured default_scope" (personal). shared_with is the list of
    # profile_ids for scope='shared'.
    scope: str | None = None
    shared_with: list[str] | None = None


def _require_remember_profile(requested: str, active: str) -> None:
    """Reject a stale profile-bound write before any durable mutation."""
    if requested and requested != active:
        raise HTTPException(
            status_code=409,
            detail=(
                f"profile mismatch: request is bound to '{requested}' but "
                f"the daemon currently serves '{active}'"
            ),
        )


def _daemon_profile_exists(engine, profile_id: str) -> bool:
    """Whether ``profile_id`` names a profile row the daemon already serves."""
    rows = engine._db.execute(
        "SELECT 1 AS one FROM profiles WHERE profile_id = ?", (profile_id,),
    )
    return bool(rows)


def _unknown_profile_body(profile_id: str) -> dict:
    """Error body for a per-request route to a profile that does not exist.

    Spec section 3/5: unknown means 404, no implicit creation, no engine call.
    This is the daemon's existing route-local structured-error shape (same
    pattern as the ``invalid_as_of`` 400 on /recall) — the global FastAPI
    ``{"detail": ...}`` format is deliberately untouched.
    """
    return {
        "success": False,
        "error": {
            "code": "unknown_profile",
            "profile_id": profile_id,
            "message": (
                f"profile {profile_id!r} does not exist; per-request routing "
                "never creates a profile implicitly"
            ),
        },
    }


class SessionOpenRequest(BaseModel):
    # #49: local session-open warm (no model roundtrip needed)
    project_path: str = ""
    query: str = ""
    max_results: int = 10


class SessionCloseRequest(BaseModel):
    # #49: local session-close (e.g. a Claude /quit hook). Empty session_id
    # closes the most recent real session.
    session_id: str = ""


class ObserveRequest(BaseModel):
    content: str


# ---------------------------------------------------------------------------
# V3.4.37: Engine recall adapter — routes QueueConsumer through the daemon's
# in-process MemoryEngine instead of spawning a recall_worker subprocess.
# Saves ~800 MB by eliminating the duplicate engine.
# ---------------------------------------------------------------------------

class EngineRecallAdapter:
    """Adapts MemoryEngine.recall() to RecallPoolProtocol for QueueConsumer.

    The daemon already has a full MemoryEngine in-process. The QueueConsumer
    previously routed through WorkerPool → recall_worker subprocess, which
    loaded a SECOND MemoryEngine. This adapter eliminates that duplication.
    """

    def __init__(self, engine, profile_runtime=None) -> None:
        self._engine = engine
        self._profile_runtime = profile_runtime

    def set_engine(self, engine) -> None:
        """Replace the engine while the profile runtime is exclusive."""
        self._engine = engine

    def recall(self, query: str, limit: int = 10, session_id: str = "") -> dict:
        from contextlib import nullcontext

        lease = (
            self._profile_runtime.operation()
            if self._profile_runtime is not None
            else nullcontext()
        )
        with lease:
            return self._recall(query, limit=limit, session_id=session_id)

    def _recall(self, query: str, limit: int = 10, session_id: str = "") -> dict:
        response = self._engine.recall(
            query, limit=limit, session_id=session_id or None,
        )
        memory_ids = list({
            r.fact.memory_id for r in response.results[:limit]
            if r.fact.memory_id
        })
        memory_map = (
            self._engine._db.get_memory_content_batch(
                memory_ids, self._engine.profile_id,
                include_global=True, include_shared=True,
            )
            if memory_ids else {}
        )
        # v3.6.6: same shared chokepoint as the HTTP route — identical output.
        from superlocalmemory.server.recall_serializer import (
            recall_response_metadata,
            serialize_recall_response,
        )
        _rc = getattr(self._engine._config, "retrieval", None)
        results, no_confident_match = serialize_recall_response(
            response,
            limit=limit,
            memory_map={k: _sanitize_json_text(v) for k, v in memory_map.items()},
            per_fact_max=getattr(_rc, "recall_per_fact_max_chars", 2400),
            total_max=getattr(_rc, "recall_total_max_chars", 12000),
            # Option B: markers only on session-bearing recalls. A marker can
            # only buy a learning signal when a pending_outcomes row exists
            # to settle, and those exist only when session_id is present.
            include_marker=bool(session_id),
        )
        for _r in results:
            _r["content"] = _sanitize_json_text(_r.get("content", ""))
        return {
            "ok": True,
            "query": query,
            "query_type": response.query_type,
            "result_count": len(results),
            "retrieval_time_ms": round(response.retrieval_time_ms, 1),
            "channel_weights": {
                k: round(v, 3)
                for k, v in (response.channel_weights or {}).items()
            },
            "total_candidates": getattr(response, "total_candidates", 0),
            "results": results,
            "no_confident_match": no_confident_match,
            **recall_response_metadata(response),
        }


def _configure_scale_backends(engine, config) -> None:
    """Attach optional graph/vector backends to one initialized engine."""
    try:
        from superlocalmemory.core.backend_orchestrator import (
            BackendOrchestrator,
            set_orchestrator,
        )

        orchestrator = BackendOrchestrator(config=config, db=engine._db)
        orchestrator.on_daemon_start()
        set_orchestrator(orchestrator)
        cozo_backend = orchestrator.get_graph_backend()
        lancedb_backend = orchestrator.get_vector_backend()
        retrieval = getattr(engine, "_retrieval_engine", None)
        if retrieval is not None:
            entity_graph = getattr(retrieval, "_entity", None)
            if (
                entity_graph is not None
                and cozo_backend is not None
                and orchestrator.graph_retrieval_ready()
            ):
                entity_graph._cozo = cozo_backend
            semantic = getattr(retrieval, "_semantic", None)
            if semantic is not None and lancedb_backend is not None:
                semantic.set_scale_vector_backend(lancedb_backend)
        logger.info(
            "BackendOrchestrator: ready (cozo=%s, lancedb=%s)",
            "active" if cozo_backend else "off",
            "active" if lancedb_backend else "off",
        )
    except Exception as exc:
        logger.warning("BackendOrchestrator init failed (non-fatal): %s", exc)


def _hot_reconfigure_engine(application, new_config, *, mode_change: bool) -> None:
    """Build and publish one coherent daemon engine for a saved config."""
    from superlocalmemory.core.engine import MemoryEngine

    old_engine = getattr(application.state, "engine", None)
    new_engine = MemoryEngine(new_config)
    try:
        if mode_change:
            # A mode switch may change the embedding dimension.  VectorStore
            # detects the mismatch on init and rebuilds the vec0 table at the
            # new dimension automatically (see VectorStore._ensure_vec0_table).
            logger.info(
                "Mode change detected: vector index will be rebuilt at new "
                "embedding dimension if dimension changed."
            )
        new_engine.initialize()
        new_config.save(mode_change=mode_change)
    except BaseException:
        new_engine.close()
        raise

    canonical_remember = getattr(
        application.state,
        "canonical_remember_runtime",
        None,
    )
    if canonical_remember is not None:
        try:
            canonical_remember.rebind_engine(new_engine)
        except BaseException:
            new_engine.close()
            raise

    # The profile transition barrier is exclusive here. Publish every
    # long-lived reference before closing the former engine.
    application.state.engine = new_engine
    application.state.config = new_config
    global _engine
    _engine = new_engine
    _observe_buffer.set_engine(new_engine)
    adapter = getattr(application.state, "engine_recall_adapter", None)
    if adapter is not None:
        adapter.set_engine(new_engine)
    _configure_scale_backends(new_engine, new_config)

    old_health_stop = getattr(application.state, "recall_health_stop", None)
    if old_health_stop is not None:
        old_health_stop.set()
    try:
        from superlocalmemory.server.recall_health import start_recall_health_monitor

        runtime = getattr(application.state, "profile_runtime", None)
        _thread, health_stop, _state = start_recall_health_monitor(
            new_engine, runtime=runtime,
        )
        application.state.recall_health_stop = health_stop
    except Exception as exc:
        application.state.recall_health_stop = None
        logger.warning("recall-health restart failed (non-fatal): %s", exc)

    if old_engine is not None and old_engine is not new_engine:
        old_engine.close()


# ---------------------------------------------------------------------------
# v3.4.32: Recall-priority gate for the pending materializer.
# All /remember writes go to pending.db and return fast; a background
# thread drains pending while yielding to any in-flight /search.
# See ``superlocalmemory.core.recall_gate``.
# ---------------------------------------------------------------------------

from superlocalmemory.core.recall_gate import (
    begin_recall as _begin_recall,
)
from superlocalmemory.core.recall_gate import (
    end_recall as _end_recall,
)
from superlocalmemory.core.recall_gate import (
    in_flight as _recalls_in_flight,
)

# v3.4.38: Module-level engine reference for the pending materializer.
# Set by the FastAPI lifespan after engine.initialize(). Was missing before,
# causing "name '_engine' is not defined" errors that blocked materialization
# of pending memories — they accumulated forever, only being processed at
# daemon startup via engine._process_pending_memories().
_engine = None
_profile_runtime = None


def _emit_event(
    event_type: str,
    payload: dict | None = None,
    *,
    source_agent: str = "http_client",
) -> None:
    """Emit a best-effort EventBus event from an HTTP write path.

    Mirrors mcp.shared.emit_event but tags source_protocol="http" so the
    dashboard can distinguish HTTP traffic from MCP tool calls. Never raises
    — a bus failure must not affect the caller's response.
    """
    try:
        from superlocalmemory.infra.event_bus import EventBus
        from superlocalmemory.server.routes.helpers import DB_PATH
        bus = EventBus.get_instance(DB_PATH)
        bus.emit(
            event_type,
            payload=payload,
            source_agent=source_agent,
            source_protocol="http",
        )
    except Exception as exc:
        logger.debug("EventBus emit failed (%s): %s", event_type, exc)


# v3.4.53: Limit concurrent full (non-fast) recalls. Without this, N parallel
# /recall calls spawn N × full-recall threads → Ollama serialises, reranker
# lock queues, and total wall time is N × single-recall-time. 3 concurrent
# full recalls gives parallelism benefit without resource oversaturation.
import asyncio as _asyncio

_recall_semaphore = _asyncio.Semaphore(3)


def _recall_budget_s() -> float:
    """Generous latency budget for a recall before the keyword fallback (v3.8.3).

    SLM's value is quality recall under heavy multi-agent load, so semantic
    recall is given ample time; the keyword fallback is a LAST-RESORT safety
    net for a genuine hang (e.g. a wedged embedder), not a speed cutoff. Tune
    with SLM_SEARCH_RECALL_TIMEOUT_S (shared with the dashboard search route).
    """
    import os
    try:
        v = float(os.environ.get("SLM_SEARCH_RECALL_TIMEOUT_S", ""))
        return v if v > 0 else 25.0
    except (TypeError, ValueError):
        return 25.0


def _recall_keyword_fallback(
    engine, query: str, limit: int, *, profile_id: str | None = None,
    profile: str | None = None, profile_generation: int | None = None,
) -> dict:
    """Fast profile-scoped keyword (LIKE) fallback for /recall.

    Used only when semantic recall exceeds its budget, so CLI/MCP callers get
    a bounded response instead of hanging. Mirrors the dashboard /api/search
    fallback shape (retrieval_mode=degraded_lexical). ``profile_id`` follows
    the per-request routing convention: None/"" means the active profile.

    4.1.14 audit: the envelope echoes the SERVED namespace (profile +
    profile_generation), exactly like the success path — a degraded routed
    recall must never be readable as an active-profile answer.
    """
    results = []
    try:
        rows = engine._db.execute(
            "SELECT fact_id, content, confidence FROM atomic_facts "
            "WHERE profile_id = ? AND content LIKE ? "
            "ORDER BY confidence DESC LIMIT ?",
            (profile_id or engine.profile_id, f"%{query}%", limit),
        )
        for pos, r in enumerate(rows, start=1):
            d = dict(r)
            results.append({
                "fact_id": d.get("fact_id"),
                "content": (d.get("content") or "")[:2400],
                "score": None, "relevance_score": None, "ranking_score": None,
                "confidence": d.get("confidence"),
                "rank_position": pos,
            })
    except Exception as exc:
        logger.warning("recall keyword fallback failed (non-fatal): %s", exc)
    return {
        "ok": True,
        "query": query,
        "query_type": "text_search",
        "retrieval_mode": "degraded_lexical",
        "degraded_reason": "recall_budget_exceeded",
        "profile": profile if profile else engine.profile_id,
        "profile_generation": profile_generation,
        "result_count": len(results),
        "results": results,
        "count": len(results),
        "no_confident_match": True,
        # PR #101: every other recall path returns this key, so clients format
        # it unconditionally. Omitting it here made the degraded path — the one
        # that fires when recall is ALREADY struggling — crash the CLI.
        "retrieval_time_ms": 0,
    }

# v3.4.52: Embedding model warm state. Set to True by the async pre-warm
# thread once Ollama has loaded the embedding model. /health reports this
# so MCP clients can wait for warm state before issuing recall calls.
_embedding_warm: bool = False


def _sanitize_json_text(text: str) -> str:
    """Strip control characters that break JSON serialization.

    Facts ingested from agent conversations can contain raw \\n, \\r, \\t,
    null bytes, and other ASCII control chars (0x00-0x1F) that survive
    database round-trips but cause ``json.JSONDecodeError: Invalid control
    character`` when FastAPI serialises the /recall response payload.

    We replace them with spaces rather than dropping them so the byte
    length is preserved and :300 truncation semantics stay predictable.
    Python's ``str.isprintable()`` is too aggressive (it also drops
    Unicode line separators), so we target only the ASCII control range.
    """
    if not text:
        return text
    # Fast path: most facts are clean JSON text. Check in C before allocating.
    if all(c >= " " or c in "\n\r\t" for c in text):
        return text
    return "".join(c if c >= " " or c in "\n\r\t" else " " for c in text)


# ---------------------------------------------------------------------------
# Observation debounce buffer (migrated from daemon.py)
# ---------------------------------------------------------------------------

class ObserveBuffer:
    """Durable observation admission with a short duplicate window.

    An accepted observation is submitted to M018 before ``enqueue`` returns.
    The timer clears only the in-memory duplicate set; it never owns evidence
    or delays persistence.
    """

    def __init__(self, debounce_sec: float = 3.0):
        self._debounce_sec = debounce_sec
        self._seen: set[str] = set()
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._engine = None

    def set_engine(self, engine) -> None:
        self._engine = engine

    def enqueue(self, content: str, *, trusted_actor_id: str = "") -> dict:
        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        with self._lock:
            if content_hash in self._seen:
                return {"captured": False, "reason": "duplicate within debounce window"}
            self._seen.add(content_hash)
            window_size = len(self._seen)
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self._debounce_sec, self._clear_seen)
            self._timer.daemon = True
            self._timer.start()
        _emit_event(
            "memory.observed",
            payload={
                "content_hash": content_hash,
                "content_preview": content[:120],
                "buffer_size": window_size,
            },
        )
        if self._engine is None:
            with self._lock:
                self._seen.discard(content_hash)
            return {
                "captured": False,
                "durable": False,
                "reason": "memory engine unavailable",
            }

        try:
            from superlocalmemory.core.engine_ingestion import (
                build_engine_ingestion_command,
            )
            from superlocalmemory.core.ingestion_command import IngestionRequest
            from superlocalmemory.hooks.auto_capture import AutoCapture

            decision = AutoCapture().evaluate(content)
            if not decision.capture:
                _emit_event(
                    "memory.dropped",
                    payload={
                        "reason": decision.reason,
                        "content_preview": content[:120],
                    },
                )
                return {
                    "captured": False,
                    "durable": False,
                    "reason": decision.reason,
                    "category": decision.category,
                    "confidence": round(decision.confidence, 3),
                }

            scope_config = getattr(self._engine._config, "scope", None)
            scope = getattr(scope_config, "default_scope", "personal")
            command = build_engine_ingestion_command(self._engine)
            receipt = command.submit(IngestionRequest(
                content=content,
                profile_id=self._engine._profile_id,
                source_type="http-observe",
                idempotency_key=f"observe:v1:{content_hash}",
                metadata={
                    "source": "auto-capture",
                    "category": decision.category,
                    "confidence": decision.confidence,
                },
                scope=scope,
                trusted_actor_id=trusted_actor_id or _materializer_actor_id(),
            ))
            _emit_event(
                "memory.captured",
                payload={
                    "operation_id": receipt.operation_id,
                    "category": decision.category,
                    "confidence": decision.confidence,
                    "content_preview": content[:120],
                },
            )
            return {
                "captured": True,
                "durable": True,
                "queued": receipt.state.value != "complete",
                "operation_id": receipt.operation_id,
                "fact_ids": list(receipt.fact_ids),
                "materialization_state": receipt.state.value,
                "category": decision.category,
                "confidence": round(decision.confidence, 3),
            }
        except Exception as exc:
            with self._lock:
                self._seen.discard(content_hash)
            logger.warning(
                "ObserveBuffer: durable admission failed for content %.40r: %s",
                content,
                exc,
            )
            _emit_event(
                "memory.dropped",
                payload={
                    "reason": "durable admission failed",
                    "content_preview": content[:120],
                },
            )
            return {
                "captured": False,
                "durable": False,
                "reason": "durable admission failed",
                "error": "internal error",
            }

    def _clear_seen(self) -> None:
        with self._lock:
            self._seen.clear()
            self._timer = None

    def _flush(self) -> None:
        """Compatibility alias: no evidence is buffered in V3.7."""
        self._clear_seen()

    def flush_sync(self) -> None:
        """Clear duplicate-window state for shutdown."""
        if self._timer is not None:
            self._timer.cancel()
        self._clear_seen()


_observe_buffer = ObserveBuffer(
    debounce_sec=float(os.environ.get("SLM_OBSERVE_DEBOUNCE_SEC", "3.0"))
)


# ---------------------------------------------------------------------------
# Idle watchdog (opt-in)
# ---------------------------------------------------------------------------

_last_activity = time.monotonic()


def _start_idle_watchdog(timeout_sec: int) -> None:
    """Auto-shutdown after idle. Only if timeout > 0."""
    if timeout_sec <= 0:
        return

    def _watch():
        while True:
            time.sleep(30)
            idle = time.monotonic() - _last_activity
            if idle > timeout_sec:
                logger.info("Daemon idle for %ds, shutting down", int(idle))
                os.kill(os.getpid(), signal.SIGTERM)
                break

    t = threading.Thread(target=_watch, daemon=True, name="idle-watchdog")
    t.start()


# ---------------------------------------------------------------------------
# Periodic full consolidation (4.0.8)
# ---------------------------------------------------------------------------
#
# Steps 8-11 of ConsolidationEngine — behavioural assertions, soft prompts,
# skill performance, skill evolution — had no automatic trigger at all. The
# session-end hook is the fast path; this timer is the guarantee, because a hook
# that does not fire is indistinguishable from a feature that does not exist.
#
# Two constraints shape the schedule:
#
#   1. Remember and recall latency must not move. So the pass only starts when
#      the daemon has served nothing for _CONSOLIDATION_IDLE_SEC. Consolidation
#      is catch-up work; there is never a reason for it to compete with a live
#      request. If the machine is busy every time we look, we simply skip and
#      check again next tick.
#   2. It must not pile up. run_full_consolidation() holds a lock and skips
#      rather than queues, so a slow pass cannot be overlapped by the next tick
#      or by the session-end hook.

#: How often to consider running. Not how often it runs.
_CONSOLIDATION_CHECK_SEC = int(os.environ.get("SLM_CONSOLIDATION_CHECK_SEC", 900))

#: Minimum quiet period before a scheduled pass may start.
_CONSOLIDATION_IDLE_SEC = int(os.environ.get("SLM_CONSOLIDATION_IDLE_SEC", 300))

#: Minimum gap between two scheduled passes.
_CONSOLIDATION_MIN_GAP_SEC = int(
    os.environ.get("SLM_CONSOLIDATION_MIN_GAP_SEC", 6 * 3600)
)

#: Delay before the first check, so daemon startup is never slowed by it.
_CONSOLIDATION_FIRST_DELAY_SEC = int(
    os.environ.get("SLM_CONSOLIDATION_FIRST_DELAY_SEC", 120)
)


async def _consolidation_timer_loop(application: FastAPI) -> None:
    """Run full consolidation on a schedule, but only while the daemon is idle."""
    from superlocalmemory.server.consolidation_runner import run_full_consolidation

    await asyncio.sleep(_CONSOLIDATION_FIRST_DELAY_SEC)
    last_run = 0.0

    while True:
        try:
            await asyncio.sleep(_CONSOLIDATION_CHECK_SEC)

            now = time.monotonic()
            if last_run and (now - last_run) < _CONSOLIDATION_MIN_GAP_SEC:
                continue
            if (now - _last_activity) < _CONSOLIDATION_IDLE_SEC:
                continue  # busy — try again next tick

            # get_engine_lazy, not state.engine directly: a mode switch nulls
            # state.engine, and reading it raw would silently disable scheduled
            # consolidation until the next daemon restart.
            from superlocalmemory.server.routes.helpers import get_engine_lazy

            engine = get_engine_lazy(application.state)
            profile_id = getattr(engine, "profile_id", None) if engine else None
            if not profile_id:
                continue

            result = await run_full_consolidation(
                application.state, profile_id, trigger="timer",
            )
            # Only a pass that actually ran resets the clock; a skip must not
            # buy another six hours of silence.
            if not result.get("skipped"):
                last_run = time.monotonic()
        except asyncio.CancelledError:
            raise
        except Exception:
            # Never let a bad pass kill the loop — that would silently disable
            # consolidation for the life of the daemon, which is the failure
            # mode this timer exists to end. Log loudly and try again.
            logger.exception("scheduled consolidation failed; will retry")


# ---------------------------------------------------------------------------
# Legacy port TCP redirect (backward compat for port 8767)
# ---------------------------------------------------------------------------

async def _start_legacy_redirect(primary_port: int, legacy_port: int) -> None:
    """Start TCP redirect from legacy_port → primary_port.

    Simple byte-level proxy. No shared event loop with uvicorn — runs
    in its own asyncio task within the same loop.
    """
    _deprecation_warned = False

    async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        nonlocal _deprecation_warned
        if not _deprecation_warned:
            logger.warning(
                "Request on deprecated port %d. Update config to use port %d.",
                legacy_port, primary_port,
            )
            _deprecation_warned = True

        try:
            upstream_r, upstream_w = await asyncio.open_connection("127.0.0.1", primary_port)
            await asyncio.gather(
                _pipe(reader, upstream_w),
                _pipe(upstream_r, writer),
            )
        except Exception:
            pass
        finally:
            writer.close()

    async def _pipe(src: asyncio.StreamReader, dst: asyncio.StreamWriter):
        try:
            while True:
                data = await src.read(8192)
                if not data:
                    break
                dst.write(data)
                await dst.drain()
        except Exception:
            pass
        finally:
            try:
                dst.close()
            except Exception:
                pass

    try:
        server = await asyncio.start_server(_handle_client, "127.0.0.1", legacy_port)
        logger.info("Legacy redirect: port %d → %d (deprecated)", legacy_port, primary_port)
        await server.serve_forever()
    except OSError:
        logger.info("Port %d in use (old daemon?), skipping legacy redirect", legacy_port)


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

def _warm_spreading_activation(engine, runtime) -> bool:
    """Pre-warm the spreading-activation channel for the active profile.

    The ``--fast`` warmup recalls deliberately skip spreading activation (and the
    Mode-C remote agentic verification), which left the first FULL user recall
    paying the cold graph-load cost: the ``graph_edges`` + ``association_edges``
    page cache and the ``fact_importance`` PageRank/community cache. This warms
    that channel directly — pure local graph work, never a remote/LLM call — so
    the first full recall is warm. Fail-soft; returns True only when it ran.
    """
    try:
        retr = getattr(engine, "_retrieval_engine", None)
        sa = getattr(retr, "_spreading_activation", None) if retr else None
        embedder = getattr(retr, "_embedder", None) if retr else None
        if sa is None or embedder is None or not hasattr(embedder, "embed"):
            return False
        query_embedding = embedder.embed("memory recall performance")
        if query_embedding is None:
            return False
        active_pid = getattr(engine, "profile_id", "default") or "default"
        lease = runtime.operation_nowait() if runtime is not None else None
        if lease is not None:
            with lease as snap:
                if snap is None:
                    return False
                sa.search(query_embedding, profile_id=active_pid, top_k=7)
        else:
            sa.search(query_embedding, profile_id=active_pid, top_k=7)
        # v3.8.5: pre-load the per-profile graph-metrics cache (PageRank +
        # community for every fact) here in the background, so the FIRST real
        # recall does not pay the ~12k-row load on its hot path.  Observed as a
        # large chunk of the 8-13s "cold first query" spike: the metrics cache
        # was loading lazily during the user's first recall instead of at boot.
        try:
            sa._load_graph_metrics_cache(active_pid)
        except Exception:
            pass
        # v3.8.5: warm the EntityGraphChannel's in-memory adjacency cache (ALL
        # ~208K edges + entity maps + graph metrics, ~18 MB) at boot.  This was
        # the dominant cause of the "cold first query" spike (8-13s): the cache
        # loaded lazily on the FIRST real recall that routed to the entity
        # channel, not during warmup.  Force it here via the channel's own
        # search entry so it is warm before any user query.
        try:
            entity_channel = getattr(retr, "_entity", None)
            if entity_channel is not None:
                entity_channel.search(
                    "memory graph adjacency warmup", active_pid, top_k=5,
                )
        except Exception:
            pass
        logger.info(
            "Spreading-activation graph pre-warmed for profile %s", active_pid,
        )
        return True
    except Exception as exc:
        logger.warning("Spreading-activation warmup failed (non-fatal): %s", exc)
        return False


def _set_source_quality_repair_status(application, **updates) -> dict:
    current = getattr(
        application.state, "source_quality_repair_status", {},
    )
    status = {**current, **updates}
    application.state.source_quality_repair_status = status
    return status


def _schedule_fact_entity_association_repair(
    application,
    memory_db_path: Path,
    *,
    batch_size: int = 250,
    tick_seconds: float = 1.0,
) -> asyncio.Task:
    """Schedule bounded M028 backfill only after readiness is published."""
    from superlocalmemory.storage.migrations.M028_fact_entity_associations import (
        get_repair_status,
    )

    durable = get_repair_status(Path(memory_db_path))
    application.state.fact_entity_association_repair_status = {
        **durable,
        "source": "startup_background_repair",
        "batch_size": batch_size,
    }
    task = asyncio.create_task(
        _fact_entity_association_repair_loop(
            application,
            Path(memory_db_path),
            batch_size=batch_size,
            tick_seconds=tick_seconds,
        ),
        name="fact-entity-association-upgrade-repair",
    )
    application.state.fact_entity_association_repair_task = task
    return task


async def _fact_entity_association_repair_loop(
    application,
    memory_db_path: Path,
    *,
    batch_size: int,
    tick_seconds: float,
) -> None:
    from superlocalmemory.storage.migrations.M028_fact_entity_associations import (
        get_repair_status,
        repair_fact_entity_associations,
    )

    consecutive_failures = 0
    try:
        while True:
            try:
                await asyncio.to_thread(
                    repair_fact_entity_associations,
                    memory_db_path,
                    batch_size=batch_size,
                    max_batches=1,
                )
                durable = await asyncio.to_thread(
                    get_repair_status, memory_db_path,
                )
            except sqlite3.Error as exc:
                consecutive_failures += 1
                retry_delay = min(
                    _FACT_ENTITY_REPAIR_MAX_RETRY_SECONDS,
                    max(
                        _FACT_ENTITY_REPAIR_MIN_RETRY_SECONDS,
                        float(tick_seconds),
                    ) * (2 ** min(consecutive_failures - 1, 10)),
                )
                try:
                    durable = await asyncio.to_thread(
                        get_repair_status, memory_db_path,
                    )
                except sqlite3.Error:
                    durable = getattr(
                        application.state,
                        "fact_entity_association_repair_status",
                        {},
                    )
                application.state.fact_entity_association_repair_status = {
                    **durable,
                    "state": "retrying",
                    "source": "startup_background_repair",
                    "batch_size": batch_size,
                    "last_error": (
                        durable.get("last_error") or type(exc).__name__
                    ),
                    "retry_attempt": consecutive_failures,
                    "retry_delay_seconds": retry_delay,
                }
                await asyncio.sleep(retry_delay)
                continue

            consecutive_failures = 0
            application.state.fact_entity_association_repair_status = {
                **durable,
                "source": "startup_background_repair",
                "batch_size": batch_size,
                "retry_attempt": 0,
                "retry_delay_seconds": 0.0,
            }
            if durable["state"] == "complete":
                return
            await asyncio.sleep(max(0.0, float(tick_seconds)))
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        durable = await asyncio.to_thread(get_repair_status, memory_db_path)
        application.state.fact_entity_association_repair_status = {
            **durable,
            "source": "startup_background_repair",
            "batch_size": batch_size,
            "last_error": durable.get("last_error") or type(exc).__name__,
        }


async def _cancel_fact_entity_association_repair(application) -> None:
    task = getattr(
        application.state, "fact_entity_association_repair_task", None,
    )
    if task is None:
        return
    if not task.done():
        task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


def _schedule_source_quality_repair(
    application,
    memory_db_path: Path,
    learning_db_path: Path,
    *,
    batch_size: int = 25,
    tick_seconds: float = 1.0,
) -> asyncio.Task:
    """Schedule post-readiness repair without awaiting historical DB work."""
    _set_source_quality_repair_status(
        application,
        state="scheduled",
        source="startup_background_repair",
        batch_size=batch_size,
        profiles=[],
        completed_profiles=[],
        profile_results={},
        batches_completed=0,
        scanned=0,
        observations=0,
        last_error=None,
    )
    task = asyncio.create_task(
        _source_quality_repair_loop(
            application,
            Path(memory_db_path),
            Path(learning_db_path),
            batch_size=batch_size,
            tick_seconds=tick_seconds,
        ),
        name="source-quality-upgrade-repair",
    )
    application.state.source_quality_repair_task = task
    return task


async def _repair_one_source_quality_profile(
    memory_db_path: Path,
    learning_db_path: Path,
    profile_id: str,
    batch_size: int,
) -> dict[str, int | bool]:
    worker = asyncio.create_task(
        asyncio.to_thread(
            repair_historical_source_quality,
            memory_db_path,
            learning_db_path,
            profile_id,
            batch_size=batch_size,
            max_batches=1,
        ),
        name=f"source-quality-repair-batch-{profile_id}",
    )
    try:
        return await asyncio.shield(worker)
    except asyncio.CancelledError:
        # Cancellation cannot stop a running worker thread. Await the bounded
        # batch so SQLite writes finish before daemon teardown closes storage.
        await worker
        raise


def _record_source_quality_repair_result(
    application,
    profile_id: str,
    result: dict[str, int | bool],
) -> bool:
    current = getattr(
        application.state, "source_quality_repair_status", {},
    )
    completed = set(current.get("completed_profiles", []))
    if result["complete"]:
        completed.add(profile_id)
    results = {
        **current.get("profile_results", {}),
        profile_id: result,
    }
    _set_source_quality_repair_status(
        application,
        profile_results=results,
        completed_profiles=sorted(completed),
        batches_completed=int(current.get("batches_completed", 0)) + 1,
        scanned=int(current.get("scanned", 0)) + int(result["scanned"]),
        observations=int(current.get("observations", 0))
        + int(result["observations"]),
    )
    return not bool(result["complete"])


async def _source_quality_repair_tick(
    application,
    memory_db_path: Path,
    learning_db_path: Path,
    profiles: list[str],
    *,
    batch_size: int,
) -> list[str]:
    _set_source_quality_repair_status(
        application,
        state="running",
        profiles=profiles,
        current_batch_size=batch_size,
        last_error=None,
    )
    pending = []
    for profile_id in profiles:
        result = await _repair_one_source_quality_profile(
            memory_db_path, learning_db_path, profile_id, batch_size,
        )
        if _record_source_quality_repair_result(
            application, profile_id, result,
        ):
            pending.append(profile_id)
        await asyncio.sleep(0)
    return pending


async def _discover_source_quality_profiles(
    memory_db_path: Path,
    pending: list[str] | None,
    completed: list[str],
) -> list[str]:
    discovered = await asyncio.to_thread(
        enumerate_source_quality_repair_profiles,
        memory_db_path,
    )
    return sorted(
        (set(pending or []) | set(discovered)) - set(completed),
    )


async def _source_quality_repair_loop(
    application,
    memory_db_path: Path,
    learning_db_path: Path,
    *,
    batch_size: int,
    tick_seconds: float,
) -> None:
    """Run one resumable repair batch per discovered profile and tick."""
    pending: list[str] | None = None
    next_refresh = 0.0
    successful_ticks = 0
    try:
        while True:
            try:
                now = time.monotonic()
                if pending is None or now >= next_refresh:
                    status = getattr(
                        application.state,
                        "source_quality_repair_status",
                        {},
                    )
                    pending = await _discover_source_quality_profiles(
                        memory_db_path,
                        pending,
                        status.get("completed_profiles", []),
                    )
                    next_refresh = (
                        now + _SOURCE_QUALITY_PROFILE_REFRESH_SECONDS
                    )
                adaptive_batch = min(
                    _SOURCE_QUALITY_MAX_BATCH_SIZE,
                    batch_size * (2 ** min(successful_ticks, 4)),
                )
                pending = await _source_quality_repair_tick(
                    application,
                    memory_db_path,
                    learning_db_path,
                    pending,
                    batch_size=adaptive_batch,
                )
            except (SourceQualityRepairUnavailable, sqlite3.Error):
                _set_source_quality_repair_status(
                    application,
                    state="retrying",
                    last_error="storage_temporarily_unavailable",
                )
            except Exception as exc:  # F6 fix: broad catch keeps loop alive
                # Any unexpected exception in a single tick (e.g. malformed JSON
                # blob, AttributeError from a half-migrated schema) must not kill
                # the entire repair loop.  Log and continue to next iteration.
                logger.warning(
                    "source-quality repair tick failed unexpectedly: %s — "
                    "loop continues",
                    exc,
                    exc_info=True,
                )
                _set_source_quality_repair_status(
                    application,
                    state="retrying",
                    last_error=type(exc).__name__,
                )
            else:
                successful_ticks += 1
            if pending == []:
                _set_source_quality_repair_status(application, state="complete")
                return
            await asyncio.sleep(max(0.0, float(tick_seconds)))
    except asyncio.CancelledError:
        _set_source_quality_repair_status(application, state="cancelled")
        raise
    except Exception as exc:
        logger.warning("source-quality startup repair failed: %s", exc)
        _set_source_quality_repair_status(
            application, state="failed", last_error=type(exc).__name__,
        )


async def _cancel_source_quality_repair(application) -> None:
    task = getattr(application.state, "source_quality_repair_task", None)
    if task is None:
        return
    if not task.done():
        task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


def _release_canonical_remember_runtime(application, runtime=None) -> bool:
    """Release the writer lease without discarding a still-running runtime."""
    runtime = (
        runtime
        if runtime is not None
        else getattr(application.state, "canonical_remember_runtime", None)
    )
    if runtime is None:
        return True
    try:
        runtime.stop()
    except Exception as exc:  # pragma: no cover - cleanup must continue
        logger.warning("canonical remember writer shutdown failed: %s", exc)
        return False
    if getattr(application.state, "canonical_remember_runtime", None) is runtime:
        application.state.canonical_remember_runtime = None
    return True


def _apply_readiness_gate(runtime, application) -> None:
    """Abort startup when the writer lease is held but the runtime is not serving.

    A swallowed exception in a critical startup step can leave the coordinator
    worker dead while the file lock remains held. Continuing to yield in that
    state keeps the lease on an unusable runtime, blocking any recovery process.
    This gate detects the broken state, releases the lease, and raises so the
    daemon exits cleanly and ownership transfers to the next start attempt.

    Calling this with a ready or absent runtime is a no-op.
    """
    if runtime is None or runtime.ready:
        return
    _release_canonical_remember_runtime(application, runtime)
    raise RuntimeError(
        "daemon writer runtime is not ready after startup — "
        "releasing writer lease so a recovery process can start"
    )


def _apply_deployment_runtime(config, deployment) -> None:
    """Upgrade engine policy from deployment config without downgrading it."""
    if deployment.pii_redaction and not getattr(config, "pii_redaction", False):
        config.pii_redaction = True


def _start_deployment_retention(application, config, deployment) -> None:
    """Start the named-rule retention scheduler when explicitly enabled."""
    application.state.retention_scheduler = None
    application.state.retention_connection = None
    if not deployment.retention_enabled:
        return

    from superlocalmemory.compliance.scheduler import RetentionScheduler

    scheduler = RetentionScheduler(db_path=config.db_path)
    scheduler.start()
    application.state.retention_scheduler = scheduler


def _stop_deployment_retention(application) -> bool:
    """Stop retention and report whether its writer thread fully terminated."""
    scheduler = getattr(application.state, "retention_scheduler", None)
    if scheduler is None:
        return True
    try:
        stopped = scheduler.stop()
    except Exception as exc:  # pragma: no cover - defensive shutdown
        logger.error("retention scheduler stop failed: %s", exc)
        return False
    if stopped is False:
        logger.error("retention scheduler did not stop within its shutdown budget")
        return False
    return True


def _start_embedder_warmup(engine: object) -> "threading.Thread | None":
    """Load the embedding model in the background. Never blocks startup.

    Returns the thread so a test can join it; ``None`` when there is nothing to
    warm. Every failure is "not warmed", never a failed startup: a daemon that
    cannot embed still serves keyword recall and still stores memories, and the
    materializer fills the vectors in afterwards either way.
    """
    embedder = getattr(engine, "_embedder", None)
    if embedder is None or not hasattr(embedder, "embed"):
        return None

    from superlocalmemory.core.engine import _is_remote_embedder

    if _is_remote_embedder(embedder):
        # A hosted embedder has no model to load and warming it would spend a
        # request, and money, on a sentence nobody asked about.
        return None

    def _warm() -> None:
        started = time.time()
        try:
            embedder.embed("slm embedder warm-up")
        except Exception as exc:  # pragma: no cover — warming is best effort
            logger.debug("embedder warm-up failed (%s) — writes will defer", exc)
            return
        logger.info(
            "Embedding model warm and ready (%.1fs)", time.time() - started,
        )

    thread = threading.Thread(target=_warm, daemon=True, name="slm-embed-warmup")
    thread.start()
    return thread


@asynccontextmanager
async def lifespan(application: FastAPI):
    """Initialize engine, workers, and optional services on startup."""
    global _last_activity

    # A previous run in this process left the enrichment pool closed so that a
    # write racing its shutdown could not resurrect it. This run is entitled to
    # one.
    _open_enrichment_pool()

    engine = None
    config = None
    deployment = None
    canonical_remember_runtime = None
    profile_runtime = None

    # The local dashboard obtains its short-lived browser credential from
    # ``/internal/token`` before its first write or token-gated read.  A
    # completely fresh Mode A install may not ingest or recall anything during
    # startup, so neither of those paths has created the install token yet.
    # Create it as part of the daemon's durable identity bootstrap instead.
    # This keeps the token endpoint read-only (and therefore fail-closed when a
    # token is unexpectedly missing after startup) while making every normal
    # daemon-backed dashboard usable from its first page load.
    try:
        from superlocalmemory.core.security_primitives import ensure_install_token

        ensure_install_token()
    except Exception as exc:  # pragma: no cover - startup remains fail-soft
        logger.warning("install-token bootstrap failed: %s", exc)

    # Register the SSE bridge inside the application lifespan.  FastAPI's
    # legacy ``on_event`` hook is deprecated and, more importantly, made a
    # second startup mechanism compete with the daemon's existing lifespan.
    from superlocalmemory.server.routes.events import register_event_listener
    register_event_listener()

    # H-21 (Stage 8) — first-boot-after-upgrade notice. Compare the cached
    # version marker against the current package version; if they differ
    # (fresh install or upgrade), log a one-time banner with a link to the
    # CHANGELOG. Non-fatal; any filesystem error is swallowed.
    try:
        try:
            from importlib.metadata import version as _pkg_version
            _slm_version = _pkg_version("superlocalmemory")
        except Exception:
            _slm_version = "unknown"
        _version_marker = state_path(".last_version")
        _prev = None
        if _version_marker.exists():
            try:
                _prev = _version_marker.read_text(encoding="utf-8").strip()
            except OSError:
                _prev = None
        # S9-SKEP-15: the version marker is written AFTER the migration
        # block succeeds (see below). A failed migration must NOT cause
        # the next successful start to skip the upgrade banner — the
        # banner is the operator's cue that a new version just landed.
        _want_write_marker = _prev != _slm_version
        if _want_write_marker:
            if _prev is None:
                logger.info(
                    "[slm] first boot on v%s — run `slm status` to see your "
                    "memory overview. Changelog: "
                    "https://github.com/qualixar/superlocalmemory/blob/main/CHANGELOG.md",
                    _slm_version,
                )
            else:
                logger.info(
                    "[slm] upgraded %s → %s. Data migrations run in a moment; "
                    "your 18k+ atomic facts are preserved. Changelog: "
                    "https://github.com/qualixar/superlocalmemory/blob/main/CHANGELOG.md",
                    _prev, _slm_version,
                )
    except Exception as _exc:  # pragma: no cover — never block startup
        logger.debug("version-banner skipped: %s", _exc)
        _want_write_marker = False
        _version_marker = None
        _slm_version = None

    # LLD-06 §7.3 / LLD-07 §4.1 — run additive schema migrations BEFORE
    # engine init so later queries see the expected columns/tables.
    # Non-fatal: any failure here is logged and the daemon still starts.
    #
    # F-05: resolve learning.db / memory.db from the same configured base
    # the engine will use (config.base_dir). Bare canonical_data_root() skips
    # configured_base_dir and can migrate ~/.superlocalmemory while the
    # engine writes a custom root.
    _path_config = None
    try:
        from superlocalmemory.core.config import SLMConfig as _SLMConfigForPaths

        try:
            _SLMConfigForPaths.migrate_to_3mode()
        except Exception as _m3_exc:  # pragma: no cover — non-fatal path prep
            logger.debug("migrate_to_3mode before path resolve: %s", _m3_exc)
        _path_config = _SLMConfigForPaths.load()
    except Exception as _cfg_exc:  # pragma: no cover — fall back below
        logger.debug("early config load for migration paths failed: %s", _cfg_exc)
        _path_config = None

    try:
        from superlocalmemory.storage.backup import InsufficientDiskSpaceError
        from superlocalmemory.storage.migration_runner import apply_all
        if _path_config is None:
            # Catastrophic early-load failure: still one root via Mode-A default
            # (runtime canonical root), never a bare second resolver branch.
            from superlocalmemory.core.config import SLMConfig as _SLMFallback
            from superlocalmemory.storage.models import Mode as _ModeFallback

            _path_config = _SLMFallback.for_mode(_ModeFallback.A)
        _learning_db = _learning_db_for_config(_path_config)
        _memory_db = _memory_db_for_config(_path_config)
        import time as _time_mod
        _t0 = _time_mod.monotonic()
        _result = apply_all(_learning_db, _memory_db)
        _elapsed = _time_mod.monotonic() - _t0
        _applied = _result.get("applied", [])
        _failed = _result.get("failed", [])
        _backup_dir = _result.get("details", {}).get("_backup")
        _backup_path = Path(_backup_dir) if _backup_dir else None
        if _applied:
            logger.info("migrations applied: %s", _applied)
            _notify_migration_applied(_applied, _elapsed, _backup_path)
            _notify_windows_user(
                f"SuperLocalMemory: {len(_applied)} database migration(s) applied."
            )
        if _failed:
            logger.warning("migrations failed (non-fatal): %s", _failed)
            try:
                _err_log = _write_migration_error_log(
                    _failed, _backup_path,
                    slm_home=_memory_db.parent if _memory_db else None,
                    applied=_applied,
                )
                import sys as _sys
                # "Data is safe" is only true when NOTHING was applied. Migrations
                # are non-fatal and applied in order, so a later failure can leave
                # earlier ones committed — a partially changed store. Saying the
                # data is untouched then tells the user to ignore the one copy
                # that still holds the original.
                if _applied:
                    _headline = (
                        f"[SLM] Migration incomplete. YOUR DATABASE WAS PARTIALLY "
                        f"CHANGED — {len(_applied)} step(s) applied, "
                        f"{len(_failed)} failed. The pre-change copy is at "
                        f"{_backup_path} — keep it until this is resolved."
                    )
                else:
                    _headline = (
                        f"[SLM] Migration failed before any change was made. Your "
                        f"data is as it was; a copy is also at {_backup_path}."
                    )
                print(
                    f"{_headline} See {_err_log}. Run: slm doctor",
                    file=_sys.stderr,
                    flush=True,
                )
                _notify_windows_user(
                    f"SuperLocalMemory migration failed. Run slm doctor. Log: {_err_log}"
                )
            except Exception:
                pass  # notification failures are non-fatal
        application.state.migration_result = _result
        # S9-SKEP-15: only commit the new `.last_version` AFTER migrations
        # complete with zero failures. A partial upgrade (schema didn't
        # land) must retain the old marker so the next successful start
        # still fires the upgrade banner — otherwise the operator loses
        # the one signal that tells them a version just changed.
        if (
            _want_write_marker
            and _version_marker is not None
            and _slm_version is not None
            and not _failed
        ):
            try:
                _version_marker.parent.mkdir(parents=True, exist_ok=True)
                _version_marker.write_text(_slm_version, encoding="utf-8")
            except OSError:
                pass  # non-fatal
    except InsufficientDiskSpaceError as _disk_exc:
        # This is not a crash and it must not be reported as "non-fatal". The
        # migration deliberately refused to start because there was not enough
        # room to keep a recoverable copy first. The store is intact and
        # unmigrated; the generic handler below would have logged a warning and
        # left the daemon serving as though nothing had happened.
        logger.error(
            "MIGRATION NOT RUN — not enough free disk to keep a recoverable "
            "copy first. Your data has NOT been modified. Need %s bytes, have "
            "%s free. Free some space and restart; run `slm doctor` for details.",
            f"{_disk_exc.needed_bytes:,}", f"{_disk_exc.free_bytes:,}",
        )
        try:
            _log_path = _write_migration_error_log(
                ["_insufficient_disk_space"], None,
                slm_home=locals().get("_memory_db").parent if locals().get("_memory_db") else None,
                applied=[],
            )
            logger.error("Details written to %s", _log_path)
        except OSError:
            pass
        application.state.migration_result = {
            "applied": [], "skipped": [], "failed": ["_insufficient_disk_space"],
            "details": {
                "_needed_bytes": _disk_exc.needed_bytes,
                "_free_bytes": _disk_exc.free_bytes,
                "_store_modified": False,
            },
        }
    except Exception as _exc:
        logger.warning("migration runner crashed (non-fatal): %s", _exc)
        application.state.migration_result = {
            "applied": [], "skipped": [], "failed": ["_runner_crash"],
            "details": {"_crash": str(_exc)},
        }

    # H1 — boot self-heal: remove provably-dead SLM lock/PID artifacts BEFORE
    # claiming the writer. The writer claim uses a portalocker OS advisory lock
    # that auto-releases on holder death, so stale artifacts are metadata-only
    # leftovers. Fail-soft — a crash here is logged but never blocks startup.
    try:
        from superlocalmemory.infra.self_heal import reap_stale_artifacts

        # NOTE: canonical_data_root is imported at module scope (top of file).
        # Do NOT re-import it locally here — a local import would shadow the
        # module name for this whole startup function and make the earlier
        # migration-runner reference raise UnboundLocalError.
        _sh_report = reap_stale_artifacts(canonical_data_root())
        if _sh_report["removed"]:
            logger.info(
                "boot self-heal: removed %d stale artifact(s)",
                len(_sh_report["removed"]),
            )
        if _sh_report["errors"]:
            logger.debug(
                "boot self-heal: %d removal error(s) (non-fatal)",
                len(_sh_report["errors"]),
            )
    except Exception as _sh_exc:
        logger.debug("boot self-heal failed (non-fatal): %s", _sh_exc)

    # H4 — mesh lock TTL expiry: delete expired mesh_locks rows on boot so
    # dead-node leases are cleared before any actor reads the lock table.
    # mesh_locks lives in memory.db.  Fail-soft — never blocks startup.
    try:
        from superlocalmemory.infra.self_heal import expire_stale_mesh_locks

        _mesh_db = canonical_data_root() / "memory.db"
        _mesh_expired = expire_stale_mesh_locks(_mesh_db)
        if _mesh_expired:
            logger.info("boot mesh expiry: cleared %d stale mesh_lock row(s)", _mesh_expired)
    except Exception as _mesh_exc:
        logger.debug("boot mesh expiry failed (non-fatal): %s", _mesh_exc)

    # H3 — process reaper: kill orphaned SLM child processes whose parent is
    # dead. Wires the existing infra/process_reaper.py at daemon start.
    # Fail-soft — never blocks the startup path.
    try:
        from superlocalmemory.infra.process_reaper import ReaperConfig, reap_stale_on_startup
        from superlocalmemory.infra.pid_manager import PidManager
        from superlocalmemory.infra.data_root import canonical_data_root as _cdr

        _rpr_cfg = ReaperConfig(orphan_age_threshold_hours=0.0)
        _rpr_mgr = PidManager(_cdr() / "slm.pids")
        reap_stale_on_startup(_rpr_cfg, _rpr_mgr)
    except Exception as _rpr_exc:
        logger.debug("boot process reaper failed (non-fatal): %s", _rpr_exc)

    try:
        from superlocalmemory.core.config import SLMConfig
        from superlocalmemory.core.engine import MemoryEngine

        # v3.4.54: one-time migration config.json → 3-mode system
        # (also attempted earlier for F-05 path resolution; idempotent)
        SLMConfig.migrate_to_3mode()

        config = _path_config if _path_config is not None else SLMConfig.load()
        from superlocalmemory.core.config import load_deployment_config
        deployment = load_deployment_config()
        _apply_deployment_runtime(config, deployment)
        application.state.deployment = deployment
        engine = MemoryEngine(config)
        engine.initialize()

        # Load the embedding model now, off the request path, the way the
        # cross-encoder is already warmed at startup.
        #
        # A write embeds inline so the memory it stores can be found by asking a
        # question rather than only by quoting its own words, and it gives that
        # one second before deferring to the materializer. Loading the model
        # takes 9.9-11.0 s here; once loaded an embed is 42 ms. So on a daemon
        # that had not embedded yet, the first writes each waited the full second
        # and stored no vector regardless -- and the model only ever loaded
        # because some *recall* eventually paid for it. Whoever recalled first
        # wore the cold start.
        #
        # This belongs to the daemon and not to engine wiring: the worker is a
        # subprocess per engine, so warming from wiring would have every `slm
        # status` spawn one and load a model it will never use.
        _start_embedder_warmup(engine)

        # Tell the hook subprocesses that skill evolution is on. The hook reads
        # this env var as its fast-path signal and nothing ever set it, so the
        # feature was off for everyone who had switched it on in config: the
        # hook checked, found nothing, and returned False. Hooks are launched as
        # children of this process and inherit its environment, which is the
        # only channel between the two.
        try:
            if getattr(getattr(config, "evolution", None), "enabled", False):
                os.environ["SLM_EVOLUTION_ENABLED"] = "1"
            else:
                # Cleared as well as set: a daemon restarted with the setting
                # turned off must not leave the previous run's answer behind in
                # an environment the next hook inherits.
                os.environ.pop("SLM_EVOLUTION_ENABLED", None)
        except Exception as _evo_exc:  # pragma: no cover — never block startup
            logger.debug("evolution flag not exported: %s", _evo_exc)

        # Refresh migration state now that the engine is initialised.  Any
        # schema work the engine's own bootstrap may have applied (e.g.
        # runtime-table creation) is captured here so the dashboard and
        # health endpoints see a current, consistent picture.  Non-fatal:
        # a runner crash here is logged but must not block the startup path.
        try:
            _result = apply_all(_learning_db, _memory_db)
            application.state.migration_result = _result
        except Exception as _ref_exc:  # pragma: no cover — defensive
            logger.debug("migration state refresh failed (non-fatal): %s", _ref_exc)

        # 3.8.6 canonical remember boundary. Migrations have already created
        # the immutable receipt ledger and engine init has created the runtime
        # tables. Claim the daemon's writer lease, install the typed admission
        # handler, and replay crash-surviving journal entries *before* any
        # background writer or ready descriptor is published.
        from superlocalmemory.core.remember_runtime import (
            CanonicalRememberRuntime,
            CanonicalRememberUnavailable,
            DaemonAlreadyServing,
        )

        canonical_remember_runtime = CanonicalRememberRuntime.for_engine(engine)
        try:
            canonical_remember_runtime.start()
        except (DaemonAlreadyServing, CanonicalRememberUnavailable):
            # H2 — graceful single-instance: a health-verified daemon is already
            # serving (DaemonAlreadyServing), OR the bounded retry loop exhausted
            # (CanonicalRememberUnavailable).  Belt-and-suspenders: a lost writer
            # race must NEVER be a traceback for a non-technical user.
            logger.info(
                "another SLM daemon holds the writer; this instance exits cleanly"
            )
            import sys
            sys.exit(0)
        application.state.canonical_remember_runtime = canonical_remember_runtime

        # WAL is already established at DB creation (DatabaseManager._enable_wal
        # / schema init). Re-asserting PRAGMA journal_mode=WAL here is a
        # schema-level write on the shared connection that raced in-flight
        # startup requests for the writer lock — removed (H-CONC-3).

        from superlocalmemory.server.profile_runtime import bind_profile_runtime

        profile_runtime = bind_profile_runtime(application.state, engine, config)
        application.state.reconfigure_engine = (
            lambda new_config, mode_change=False: _hot_reconfigure_engine(
                application, new_config, mode_change=mode_change,
            )
        )
        logger.info("Unified daemon: MemoryEngine initialized (mode=%s)", config.mode.value)

        # v3.5.0: Backend Orchestrator — CozoDB (graph) + LanceDB (vector) backends.
        # Initialise AFTER engine so the retrieval channels exist to receive backends.
        # Migrates edges/embeddings automatically; fail-soft (non-blocking).
        _configure_scale_backends(engine, config)

        # LLD-07 §4 — deferred migrations (e.g. M006 reward column) need to
        # run AFTER MemoryEngine.initialize() has bootstrapped runtime tables
        # like action_outcomes. Non-fatal by contract.
        try:
            from superlocalmemory.storage.migration_runner import apply_deferred
            _deferred = apply_deferred(_learning_db, _memory_db)
            _d_applied = _deferred.get("applied", [])
            _d_failed = _deferred.get("failed", [])
            if _d_applied:
                logger.info("deferred migrations applied: %s", _d_applied)
            if _d_failed:
                logger.warning(
                    "deferred migrations failed (non-fatal, trainer falls "
                    "back to position proxy): %s", _d_failed,
                )
            # Merge into the migration result already on app state so the
            # dashboard sees one consolidated picture.
            _mr = getattr(application.state, "migration_result", None) or {
                "applied": [], "skipped": [], "failed": [], "details": {},
            }
            _mr.setdefault("applied", []).extend(_d_applied)
            _mr.setdefault("skipped", []).extend(_deferred.get("skipped", []))
            _mr.setdefault("failed", []).extend(_d_failed)
            _mr.setdefault("details", {}).update(_deferred.get("details", {}))
            application.state.migration_result = _mr
        except Exception as _dexc:  # pragma: no cover — defensive
            logger.warning(
                "deferred migration runner crashed (non-fatal): %s", _dexc,
            )

        # Move an existing store onto the graph and vector backends on the
        # first start after an upgrade. They have shipped as required
        # dependencies since 3.7 and sat unused, because building the
        # projections was three manual commands almost nobody ran. Runs after
        # the deferred migrations so it projects the converted store, and never
        # fatal: if the libraries will not import or the projection does not
        # match, the daemon serves from SQLite and says so.
        try:
            from superlocalmemory.core.scale_autopromote import (
                auto_promote_scale_backends,
            )
            _promotion = auto_promote_scale_backends(config)
            application.state.scale_autopromotion = _promotion.as_dict()
            if _promotion.promoted and _promotion.restart_required:
                logger.info(
                    "graph and vector backends are promoted and serve after the "
                    "next restart",
                )
        except Exception as _pexc:  # pragma: no cover — defensive
            logger.warning("automatic backend promotion crashed (non-fatal): %s", _pexc)
            application.state.scale_autopromotion = {
                "attempted": True, "promoted": False, "reason": str(_pexc),
            }

        # S9-DASH-02: start the outcome-queue worker so recall →
        # pending_outcomes is actually produced. Before v3.4.22 this
        # producer had zero callers and the closed-loop pipeline was
        # dark. Worker drains at 250 ms cadence; one SQLite INSERT per
        # event via EngagementRewardModel.record_recall.
        try:
            from superlocalmemory.learning.outcome_queue import start_worker
            start_worker(_memory_db)
        except Exception as _oqexc:  # pragma: no cover — defensive
            logger.debug("outcome_queue start failed (non-fatal): %s", _oqexc)

        # Set up observe buffer
        _observe_buffer.set_engine(engine)

        # v3.4.52: Ensure covering indexes for SpreadingActivation queries.
        # SQLite 3.45+ streaming merge (UNION ALL + ORDER BY + LIMIT) uses
        # these to seek directly to top-K rows per subquery, avoiding a
        # full sort.  Without them full recall takes 7-10s on
        # >1M edges (the SpreadingActivation 4-UNION query disk-sorts every
        # node's neighbor list on each call).  With them: sub-second.
        #
        # Concurrency fix (v3.8.4): wrapped in memory_write() so the process
        # write lock is acquired before the connection is opened.  Previously
        # the raw sqlite3.connect() bypassed get_write_lock() and had no
        # busy_timeout, which risked SQLITE_BUSY at daemon startup when other
        # writers (hook / CLI) were already active.
        try:
            from superlocalmemory.storage.memory_write import memory_write as _mw
            with _mw(_memory_db) as _idx_conn:
                _idx_conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_edges_source_weight "
                    "ON graph_edges(profile_id, source_id, weight DESC)"
                )
                _idx_conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_edges_target_weight "
                    "ON graph_edges(profile_id, target_id, weight DESC)"
                )
                _idx_conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_assoc_source_weight "
                    "ON association_edges(profile_id, source_fact_id, weight DESC)"
                )
                _idx_conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_assoc_target_weight "
                    "ON association_edges(profile_id, target_fact_id, weight DESC)"
                )
        except Exception as _idx_exc:
            logger.debug("SpreadingActivation covering indexes skipped: %s", _idx_exc)

        # V3.4.37: Removed WorkerPool.warmup() — the recall_worker subprocess
        # duplicated the daemon's MemoryEngine (800+ MB). QueueConsumer now
        # uses the daemon's engine directly via EngineRecallAdapter.
        # WorkerPool is still available as fallback for dashboard/chat routes.

        # The reranker constructor has already started its background warmup.
        # Never block daemon publication here: a first-time model download or
        # ONNX compilation previously held every CLI/MCP request for 120s.
        # Until it is ready, retrieval uses its deterministic fallback scorer;
        # the worker upgrades subsequent recalls without changing their API.
        retrieval_eng = getattr(engine, '_retrieval_engine', None)

        # V3.4.11: Pre-warm embedding worker (load ONNX model on startup)
        # Without this, first recall takes 60-90s for model load.
        # Same pattern as reranker warmup above.
        # v3.4.52: Sets module-level _embedding_warm flag so /health can
        # report readiness. Combined with keep_alive=-1 in ollama_embedder.py
        # this keeps the embedding model resident forever after first warm-up.
        import threading
        global _embedding_warm
        _embedding_warm = False
        def _warmup_embedder():
            global _embedding_warm
            import time as _t
            # RETRY: the retrieval engine / embedder can be created lazily a
            # moment AFTER this thread starts.  The old one-shot attempt often
            # captured a None embedder and left _embedding_warm stuck False
            # forever — so /health reported not-ready even though on-demand
            # embeds worked.  A stuck not-ready can make an auto-start hook
            # believe the daemon is down and spawn a DUPLICATE daemon (two
            # processes writing memory.db → cross-process SQLITE_BUSY).  Poll
            # until the real embedder (retrieval_eng._embedder, the same one
            # recall uses) is available, warm it, and flip the flag.
            for _attempt in range(240):  # ~120s max at 0.5s steps
                try:
                    _re = retrieval_eng or getattr(engine, '_retrieval_engine', None)
                    embedder = getattr(_re, '_embedder', None) if _re else None
                    if embedder is not None and hasattr(embedder, 'embed'):
                        embedder.embed("warmup")
                        _embedding_warm = True
                        logger.info(
                            "Embedding worker pre-warmed (model resident, "
                            "keep_alive=-1)"
                        )
                        return
                except Exception as exc:
                    logger.debug("Embedding warmup attempt %d failed: %s",
                                 _attempt, exc)
                _t.sleep(0.5)
            logger.warning(
                "Embedding warmup did not complete after retries; /health "
                "may report not-ready even though on-demand embeds work"
            )

        def _warmup_recall():
            """v3.4.62: Fire a full recall after embedding warms up.

            Loads the graph_edges table (347K rows, ~100 MB) into the SQLite
            page cache. Without this, the first user query takes 15-24s because
            it reads graph_edges from disk. After this warmup completes, all
            subsequent queries hit the warm page cache at <2s.

            Runs after embedding warm (embed first so recall can use it).
            Named 'recall-warmup' so it appears clearly in thread dumps.

            v3.x: each warmup query holds its own operation_nowait() lease
            (previously one lease across both queries held for up to 20s,
            blocking any profile switch issued at daemon start).  A pending
            transition preempts remaining queries; they complete on next boot.
            """
            import time as _t
            for _ in range(60):
                if _embedding_warm:
                    break
                _t.sleep(0.5)
            try:
                t0 = _t.monotonic()
                # Fire 2 warmup queries: one to load the graph page cache,
                # second to warm the reranker subprocess + all producers.
                # Without this, dashboard POST /api/search hits 11s cold.
                # Each query holds its own brief operation_nowait() lease so a
                # concurrent profile switch is not blocked by both recalls.
                for wq in ("memory recall performance", "context injection retrieval"):
                    with profile_runtime.operation_nowait() as _snap:
                        if _snap is None:
                            logger.debug(
                                "Recall warmup preempted by profile transition "
                                "— skipping remaining warmup queries"
                            )
                            break
                        engine.recall(wq, limit=5, fast=True)  # short lease so a profile switch can drain within 5s
                # v3.8: the --fast recalls above skip spreading activation; warm
                # that channel directly so the first FULL recall is not cold.
                _warm_spreading_activation(engine, profile_runtime)
                # v3.8.5: the fast recalls above do NOT exercise the full ranking
                # path or the agentic round, so the FIRST real user query that
                # takes the full path paid an 8-13s cold cost (ranking model +
                # graph-metrics load).  Fire ONE full (fast=False) recall here in
                # the background so those load at boot, not on a user's query.
                # Best-effort; never blocks readiness.
                try:
                    with profile_runtime.operation_nowait() as _fsnap:
                        if _fsnap is not None:
                            engine.recall(
                                "memory recall performance", limit=5, fast=False,
                            )
                except Exception as _fexc:
                    logger.debug("Full-path warmup skipped (non-fatal): %s", _fexc)
                elapsed = round((_t.monotonic() - t0) * 1000)
                logger.info(
                    "Recall engine pre-warmed in %dms", elapsed,
                )
            except Exception as exc:
                logger.warning("Recall warmup failed (non-fatal): %s", exc)

        def _backfill_vector_store():
            """v3.5.0: index facts whose embeddings exist in atomic_facts but
            are missing from the sqlite-vec store. Facts stored before dual-write
            was complete were never indexed, so semantic + hopfield only saw a
            fraction of the corpus (observed: 5.8k indexed of 17.2k embedded).
            Idempotent (skips when the store is already complete), non-blocking,
            fail-soft. Runs once after a 3.5.0 upgrade, then no-ops every restart.
            """
            import time as _t
            from pathlib import Path as _P
            if os.environ.get("SLM_DISABLE_VS_BACKFILL") == "1":
                logger.info(
                    "VS backfill disabled via SLM_DISABLE_VS_BACKFILL=1"
                )
                return
            for _ in range(120):
                if _embedding_warm:
                    break
                _t.sleep(0.5)
            try:
                from superlocalmemory.retrieval.vector_store import (
                    VectorStore,
                    VectorStoreConfig,
                )
                db = engine._db
                db_path = getattr(db, "db_path", None) or getattr(db, "_db_path", None)
                if db_path is None:
                    return
                dim = getattr(getattr(config, "embedding", None), "dimension", 768) or 768
                vs = VectorStore(_P(db_path), VectorStoreConfig(dimension=dim))
                if not vs.available:
                    return
                try:
                    profiles = list(db.list_profiles()) or ["default"]
                except Exception:
                    profiles = ["default"]
                for pid in profiles:
                    facts = db.get_all_facts(pid)
                    with_emb = [
                        (f.fact_id, getattr(f, "profile_id", pid) or pid, f.embedding)
                        for f in facts
                        if getattr(f, "embedding", None) and len(f.embedding) == dim
                    ]
                    if not with_emb:
                        continue
                    indexed_ids = vs.indexed_fact_ids(pid)
                    missing = [
                        item for item in with_emb
                        if item[0] not in indexed_ids
                    ]
                    if not missing:
                        continue  # every metadata pointer has a vec0 payload
                    # Fix: route each upsert through db._lock with cooperative
                    # yield between facts.  Previously called
                    # vs.rebuild_from_facts() which opens its own sqlite3
                    # connection (bypassing db._lock), causing concurrent
                    # backfill_missing_embeddings writes to hit SQLITE_BUSY
                    # while holding db._lock — starving user writes for ~50 s.
                    import os as _selfheal_os
                    # Stage 2 (write-queue plan): batch upserts so the write lock
                    # is acquired a FEW times with a clear release window (pause)
                    # between batches — instead of thousands of rapid
                    # re-acquisitions.  threading.RLock is NOT fair, so on a
                    # fresh boot a waiting user /remember could be starved for
                    # ~50 s behind the per-fact churn.  A real pause between
                    # bounded batches guarantees the waiting user write wins the
                    # lock promptly.  One-time backfill; steady state no-ops.
                    _batch = max(1, int(
                        _selfheal_os.environ.get("SLM_SELFHEAL_BATCH", "50")))
                    _pause = max(0.0, float(
                        _selfheal_os.environ.get("SLM_SELFHEAL_BATCH_PAUSE_S", "0.05")))
                    n = 0
                    for _i in range(0, len(missing), _batch):
                        _chunk = missing[_i:_i + _batch]
                        with db._lock:
                            for _fact_id, _profile_id, _embedding in _chunk:
                                try:
                                    if vs.upsert(_fact_id, _profile_id, _embedding):
                                        n += 1
                                except Exception as _upsert_exc:
                                    logger.warning(
                                        "VS backfill[%s]: upsert failed for %s: %s",
                                        pid, str(_fact_id)[:16], _upsert_exc,
                                    )
                        # Release window: let any waiting user write through
                        # before grabbing the lock again.
                        if _pause > 0:
                            _t.sleep(_pause)
                    logger.info(
                        "VS backfill[%s]: repaired %d of %d missing vectors",
                        pid, n, len(missing),
                    )
            except Exception as exc:
                logger.warning("Vector store backfill failed (non-fatal): %s", exc)

        def _self_heal():
            """v3.8.2 zero-pain self-heal.

            On daemon start (especially right after a pip/npm upgrade of a
            months-old database), silently restore full retrieval capability
            with ZERO user action:
              1. embed facts that were never embedded (NULL embedding column),
              2. backfill key-expansion alt-keys (BM25 recall aid) via one
                 bounded maintenance pass per profile,
              3. index everything (including the just-embedded facts) into the
                 sqlite-vec store.
            Fully non-blocking (daemon thread) — recall keeps serving throughout.
            Every step is bounded + idempotent, so on an already-complete DB the
            whole pass is a fast no-op. Progress is exposed at /status.self_heal
            so the dashboard can show a plain-language "Optimizing memory…" line.
            """
            import time as _t
            global _SELF_HEAL_STATUS
            _SELF_HEAL_STATUS = {
                "state": "checking_components", "embeddings_backfilled": 0,
                "expansion_backfilled": 0, "null_remaining": None,
                "components": None,
                # Declared here so /status carries the same keys whatever
                # happens; a field that only appears on failure is a field
                # nobody's dashboard renders.
                "incomplete_reason": None,
                "started_at": _t.time(), "finished_at": None,
            }
            # Step 0 (v3.8.2 "whole self-healer"): repair components that
            # silently failed to install from the internet — BEFORE waiting on
            # the embedder, since a missing embedding model would make that wait
            # pointless. Downloads missing HF models (embedder/reranker, only
            # when torch is present) and pip-installs sqlite-vec when the
            # interpreter is user-writable. Bounded, fail-open, never sudo,
            # never auto-pulls Ollama. Manual-only items are recorded for the
            # dashboard "what's missing" report (GET /api/v3/components), not
            # acted on here.
            try:
                from superlocalmemory.core import component_healer
                heal_res = component_healer.heal_missing(
                    config,
                    on_progress=lambda k, m: logger.info(
                        "Self-heal component[%s]: %s", k, m,
                    ),
                )
                _SELF_HEAL_STATUS["components"] = heal_res
                if heal_res["attempted"]:
                    logger.info("Self-heal components: %s", heal_res)
            except Exception as exc:
                logger.warning(
                    "Self-heal component check failed (non-fatal): %s", exc,
                )
            _SELF_HEAL_STATUS["state"] = "waiting_embedder"
            for _ in range(120):  # up to ~60s for the embedder to warm
                if _embedding_warm:
                    break
                _t.sleep(0.5)
            try:
                embedder = getattr(retrieval_eng, "_embedder", None) if retrieval_eng else None
                db = engine._db
                if embedder is None or db is None:
                    _SELF_HEAL_STATUS["state"] = "skipped_no_embedder"
                    return
                # 1) Embed never-embedded facts (all profiles, the upgrade
                #    headline). Looped: backfill is idempotent + bounded, and the
                #    shared embedding worker can transiently return None under
                #    startup contention (concurrent recall-warmup). Retrying until
                #    the NULL count stops shrinking makes the heal converge
                #    robustly rather than abandoning on one transient miss.
                #    Facts that never embed (e.g. a document far over the model's
                #    token limit) are left as-is after a bounded number of no-progress
                #    attempts. No-op when there are no NULLs.
                _SELF_HEAL_STATUS["state"] = "backfilling_embeddings"
                try:
                    # RECALL-PRIORITY THROTTLE: the embedding worker is a single
                    # serialized subprocess shared with foreground recall. A
                    # continuous backfill starves interactive query-embedding and
                    # recalls time out. So: (a) tiny batches (short worker holds),
                    # and (b) before each batch, defer while ANY user recall is in
                    # flight — reusing the same recall_gate the pending materializer
                    # uses. This keeps recall responsive throughout the heal (the
                    # zero-pain requirement); the heal just takes a little longer.
                    from superlocalmemory.core import recall_gate
                    from superlocalmemory.storage.embedding_migrator import (
                        backfill_missing_embeddings,
                    )
                    total_embedded = 0
                    no_progress = 0
                    for _attempt in range(500):
                        # Absolute priority to user recalls: pause the heal while
                        # a recall is active (bounded wait so we never wedge).
                        _waited = 0.0
                        while recall_gate.in_flight() > 0 and _waited < 30.0:
                            _t.sleep(0.5)
                            _waited += 0.5
                        r = backfill_missing_embeddings(
                            config, db, embedder, limit=5, all_profiles=True,
                        )
                        got = r.get("embedded", 0)
                        total_embedded += got
                        _SELF_HEAL_STATUS["embeddings_backfilled"] = total_embedded
                        _SELF_HEAL_STATUS["null_remaining"] = r.get("remaining_null", 0)
                        if r.get("remaining_null", 0) == 0:
                            break
                        if got == 0:
                            no_progress += 1
                            if no_progress >= 5:  # transient recovery exhausted
                                break
                            _t.sleep(3)  # let the worker settle, then retry
                        else:
                            no_progress = 0
                            _t.sleep(0.5)  # brief pause between bursts
                    if total_embedded:
                        logger.info(
                            "Self-heal: embedded %d previously-unembedded facts "
                            "(%d remaining)", total_embedded,
                            _SELF_HEAL_STATUS["null_remaining"],
                        )
                except Exception as exc:
                    logger.warning("Self-heal embedding backfill failed (non-fatal): %s", exc)
                # 2) Math/key-expansion maintenance is intentionally NOT run here:
                #    run_maintenance triggers a full Langevin backfill over every
                #    fact, which on a large legacy DB takes minutes and its CPU
                #    burst inflates foreground recall latency during the heal
                #    window. The startup heal stays lean (embeddings + vector
                #    index — what makes facts findable again). Langevin/Sheaf/
                #    key-expansion continue to converge on the periodic
                #    MaintenanceScheduler exactly as before — unchanged behavior.
                # 3) Index everything (incl. newly-embedded) into the vector store.
                _SELF_HEAL_STATUS["state"] = "indexing_vectors"
                try:
                    _backfill_vector_store()
                except Exception as exc:
                    logger.warning("Self-heal vector index failed (non-fatal): %s", exc)

                # "complete" has to mean complete.
                #
                # This line used to set "complete" unconditionally, so a
                # backfill that gave up after five no-progress attempts, or ran
                # out its 500-iteration budget, reported success with facts
                # still unembedded — and an unembedded fact cannot be found by
                # meaning at all. That is how a machine sat at 56.3% of its
                # memory reachable while its own status endpoint said the heal
                # had finished. Nobody was going to look past a green light.
                #
                # Now the state is derived from the remaining count, and the
                # gap is named in plain language for the dashboard, so an
                # incomplete heal is visible and gets retried on next start
                # instead of being declared done forever.
                _remaining = _SELF_HEAL_STATUS.get("null_remaining")
                _SELF_HEAL_STATUS["finished_at"] = _t.time()
                if _remaining is None:
                    _SELF_HEAL_STATUS["state"] = "complete"
                elif int(_remaining) > 0:
                    _SELF_HEAL_STATUS["state"] = "incomplete"
                    _SELF_HEAL_STATUS["incomplete_reason"] = (
                        f"{int(_remaining)} memories still have no meaning "
                        f"vector, so they cannot be found by asking a question. "
                        f"This retries automatically next time the service "
                        f"starts. It usually means the embedding model was "
                        f"unavailable."
                    )
                    logger.warning(
                        "Self-heal INCOMPLETE: %d facts still unembedded and "
                        "therefore unreachable by meaning; will retry on next "
                        "start. %s", int(_remaining), _SELF_HEAL_STATUS,
                    )
                else:
                    _SELF_HEAL_STATUS["state"] = "complete"
                    logger.info("Self-heal complete: %s", _SELF_HEAL_STATUS)
            except Exception as exc:
                _SELF_HEAL_STATUS["state"] = "error"
                logger.warning("Self-heal failed (non-fatal): %s", exc)

        def _component_recheck_loop():
            """Periodic component re-check (v3.8.2 "whole self-healer").

            The startup heal (_self_heal Step 0) runs once. This keeps the
            self-healer promise for a long-running daemon: it re-probes
            components on a slow cadence and auto-repairs any that regress
            (a cache eviction, a half-finished install). No-op on a healthy
            machine — nothing is auto-fixable-missing, so it is just a cheap
            probe. Disable with SLM_COMPONENT_RECHECK_SEC=0.
            """
            import os as _os
            import time as _t
            try:
                cadence = int(_os.environ.get("SLM_COMPONENT_RECHECK_SEC", "1800"))
            except ValueError:
                cadence = 1800
            if cadence <= 0:
                return
            # Let the startup heal + warmup settle before the first re-check.
            _t.sleep(max(cadence, 300))
            while True:
                try:
                    from superlocalmemory.core import component_healer
                    res = component_healer.heal_missing(
                        config,
                        on_progress=lambda k, m: logger.info(
                            "Component re-check[%s]: %s", k, m,
                        ),
                    )
                    if res["attempted"]:
                        logger.info("Component re-check repaired: %s", res)
                except Exception as exc:
                    logger.debug("Component re-check failed (non-fatal): %s", exc)
                _t.sleep(cadence)

        threading.Thread(target=_warmup_embedder, daemon=True, name="embed-warmup").start()
        threading.Thread(target=_warmup_recall, daemon=True, name="recall-warmup").start()
        # v3.8.2: self-heal supersedes the bare vector-store backfill (it calls
        # _backfill_vector_store itself, after embedding + expansion heal).
        threading.Thread(target=_self_heal, daemon=True, name="self-heal").start()
        threading.Thread(
            target=_component_recheck_loop, daemon=True, name="component-recheck",
        ).start()

        # v3.6.8: Runtime recall-health monitor. The three warmups above run
        # ONCE at boot; on a long-running daemon the graph page cache gets
        # evicted and the embedder can start returning None while _embedding_warm
        # still claims True — both silently degrade recall to keyword-only BM25
        # (observed: session_init "pool.recall timed out → DEGRADED MODE", 7×/2d).
        # This monitor re-warms + actively probes the semantic channel + self-heals
        # a dead embedder for the daemon's whole life. See server/recall_health.py.
        try:
            from superlocalmemory.server.recall_health import (
                start_recall_health_monitor,
            )
            _rh_thread, _rh_stop, _ = start_recall_health_monitor(
                engine, runtime=profile_runtime,
            )
            application.state.recall_health_stop = _rh_stop
        except Exception as _rh_exc:
            logger.warning(
                "recall-health monitor start failed (non-fatal): %s", _rh_exc,
            )
            application.state.recall_health_stop = None

        # v3.4.37: QueueConsumer uses daemon's engine directly via adapter.
        # Previously routed through WorkerPool → recall_worker subprocess,
        # which loaded a duplicate MemoryEngine (~800 MB waste).
        try:
            from superlocalmemory.core.queue_consumer import QueueConsumer
            from superlocalmemory.core.recall_queue import RecallQueue
            _queue_db = state_path("recall_queue.db")
            _recall_queue = RecallQueue(_queue_db)
            _engine_recall_adapter = EngineRecallAdapter(engine, profile_runtime)
            _queue_consumer = QueueConsumer(
                queue=_recall_queue,
                pool=_engine_recall_adapter,
            )
            _queue_consumer.start()
            application.state.queue_consumer = _queue_consumer
            application.state.engine_recall_adapter = _engine_recall_adapter
            application.state.recall_queue = _recall_queue
            logger.info("QueueConsumer started (recall_queue.db)")

            # v3.4.36: Start persistent hook daemon (Unix socket server).
            # Eliminates Python subprocess startup for each recall hook call.
            try:
                from superlocalmemory.hooks.hook_daemon import HookDaemon
                _hook_daemon = HookDaemon(queue_db_path=_queue_db)
                _hook_daemon.start()
                application.state.hook_daemon = _hook_daemon
            except Exception as _hd_exc:
                logger.warning("HookDaemon start failed (non-fatal): %s", _hd_exc)
                application.state.hook_daemon = None
        except Exception as _qc_exc:
            logger.warning("QueueConsumer start failed (non-fatal): %s", _qc_exc)
            application.state.queue_consumer = None
            application.state.engine_recall_adapter = None
            application.state.recall_queue = None

    except Exception:
        logger.exception("Engine init failed")  # auto-includes traceback
        writer_released = _release_canonical_remember_runtime(
            application, canonical_remember_runtime,
        )
        application.state.engine = None
        application.state.config = None
        if engine is not None and writer_released:
            try:
                engine.close()
            except Exception:
                logger.debug("partially initialized engine cleanup failed", exc_info=True)
        raise

    application.state.observe_buffer = _observe_buffer

    # Readiness gate: if the writer lease was claimed but the coordinator is not
    # serving (e.g., a swallowed exception in a critical startup step killed the
    # worker thread), release the lease and abort startup.  A living process that
    # holds an unusable lease blocks any recovery daemon from starting.
    _apply_readiness_gate(canonical_remember_runtime, application)

    # Phase B: Start health monitor
    try:
        from superlocalmemory.core.health_monitor import HealthMonitor
        health_config = getattr(config, 'health', None)
        # v3.6.9 BUG-A: env override + RAM-scaled default (HealthMonitor computes
        # 40% of physical RAM when budget=0). SLM_RSS_BUDGET_MB takes priority.
        _env_budget = int(os.environ.get("SLM_RSS_BUDGET_MB", "0") or 0)
        _cfg_budget = getattr(health_config, 'global_rss_budget_mb', 0) if health_config else 0
        monitor = HealthMonitor(
            global_rss_budget_mb=_env_budget or _cfg_budget or 0,
            heartbeat_timeout_sec=getattr(health_config, 'heartbeat_timeout_sec', 60) if health_config else 60,
            check_interval_sec=getattr(health_config, 'health_check_interval_sec', 15) if health_config else 15,
            enable_structured_logging=getattr(health_config, 'enable_structured_logging', True) if health_config else True,
        )
        monitor.start()
        application.state.health_monitor = monitor
    except Exception as exc:
        logger.debug("Health monitor init: %s", exc)
        application.state.health_monitor = None

    # Phase C: Start mesh broker
    try:
        mesh_enabled = getattr(config, 'mesh_enabled', True) if config else True
        if mesh_enabled:
            from superlocalmemory.mesh.broker import MeshBroker
            db_path = config.db_path if config else state_path("memory.db")
            mesh_broker = MeshBroker(str(db_path))
            mesh_broker.start_cleanup()
            application.state.mesh_broker = mesh_broker
            logger.info("Mesh broker started")
        else:
            application.state.mesh_broker = None
    except Exception as exc:
        logger.warning("Mesh broker init failed: %s", exc)
        application.state.mesh_broker = None

    # Phase C-2: opt-in mDNS advertiser (default OFF — backward-compatible).
    # Enabled only when SLM_MESH_ADVERTISE=1|on|true|yes is set explicitly.
    # Gating on the env var BEFORE importing discovery keeps the default-off
    # path byte-for-byte identical to pre-3b (no discovery import, no thread
    # hop, no object alloc). See mesh.discovery.MeshAdvertiser for full docs.
    application.state.mesh_advertiser = None
    _advertise_requested = (
        os.environ.get("SLM_MESH_ADVERTISE", "").strip().lower()
        in ("1", "on", "true", "yes")
    )
    if _advertise_requested and application.state.mesh_broker is None:
        # Operator asked for advertising but the broker isn't up — make the
        # skip diagnosable rather than silent (audit P2).
        logger.warning(
            "mDNS advertise requested (SLM_MESH_ADVERTISE) but mesh broker is "
            "not running — advertising skipped"
        )
    elif _advertise_requested and application.state.mesh_broker is not None:
        try:
            import socket as _adv_sock
            from superlocalmemory.mesh.discovery import MeshAdvertiser as _MeshAdvertiser
            _adv_node_id = _adv_sock.gethostname()
            _advertiser = _MeshAdvertiser(
                service_port=_configured_daemon_port(),
                node_id=_adv_node_id,
            )
            # register_service blocks ~750 ms (mDNS probe phase) — run off the
            # event loop to avoid stalling the async startup path (CRIT fix #2).
            await asyncio.to_thread(_advertiser.start)
            application.state.mesh_advertiser = _advertiser
        except Exception as exc:
            logger.warning("mDNS advertiser init failed (non-fatal): %s", exc)
            application.state.mesh_advertiser = None

    # RBAC / teams (C3): user identity + role enforcement over memory.db.
    # Additive — with zero users the daemon stays single-operator (owner).
    try:
        from superlocalmemory.access.rbac import RbacEngine
        rbac_db = config.db_path if config else state_path("memory.db")
        rbac_engine = RbacEngine(str(rbac_db))
        rbac_engine.purge_expired_sessions()
        application.state.rbac = rbac_engine
        logger.info("RBAC engine ready (users=%d)", rbac_engine.user_count())
    except Exception as exc:
        logger.warning("RBAC engine init failed: %s", exc)
        application.state.rbac = None

    # Deployment config (v3.8.0) — read [deployment] from config.toml and wire.
    # Additive / fail-open: personal defaults are a no-op so existing installs
    # with no [deployment] section behave EXACTLY as before.
    # ENFORCE rule: only UPGRADE a setting, NEVER downgrade an already-stronger
    # runtime setting (e.g. RBAC require_login already True → leave it alone).
    try:
        if deployment is None:
            from superlocalmemory.core.config import load_deployment_config
            deployment = load_deployment_config()
        application.state.deployment = deployment
        if deployment.require_login:
            _dep_rbac = getattr(application.state, "rbac", None)
            if _dep_rbac is not None and not _dep_rbac.require_login():
                _dep_rbac.set_require_login(True)
                logger.info(
                    "Deployment: require_login enforced via enterprise deployment config"
                )
        _start_deployment_retention(application, config, deployment)
        logger.info(
            "Deployment config loaded: mode=%s require_login=%s "
            "pii=%s retention=%s audit=%s",
            deployment.mode, deployment.require_login,
            deployment.pii_redaction, deployment.retention_enabled, deployment.audit,
        )
    except Exception as _dep_exc:
        logger.warning("Deployment config wire failed (non-fatal): %s", _dep_exc)
        application.state.deployment = None

    # Phase 1: Admission gateway coverage self-check.
    # Uses _resolve_deployment() (fail-closed) rather than application.state.deployment
    # (which may be None if the load failed) so an enterprise box with a broken
    # config never silently skips a hard coverage check.
    # G-tranche: pass the real MCP server so dynamic tool enumeration catches
    # any newly-added tool that lacks both @admits and readOnlyHint=True.
    try:
        from superlocalmemory.core.admission import (
            _resolve_deployment as _adm_resolve,
            coverage_self_check,
        )
        from superlocalmemory.mcp import server as _mcp_server_mod
        _cov_deployment = _adm_resolve()
        _mcp_server = getattr(_mcp_server_mod, "server", None)
        coverage_self_check(_cov_deployment, server=_mcp_server)
    except RuntimeError as _cov_exc:
        raise
    except Exception as _cov_exc:
        logger.warning("admission coverage self-check failed (non-fatal): %s", _cov_exc)

    # Start idle watchdog if configured
    idle_timeout = int(os.environ.get("SLM_DAEMON_IDLE_TIMEOUT", "0"))
    if config and hasattr(config, 'daemon_idle_timeout'):
        idle_timeout = idle_timeout or config.daemon_idle_timeout
    _start_idle_watchdog(idle_timeout)

    # Start legacy port redirect
    enable_legacy = os.environ.get("SLM_DISABLE_LEGACY_PORT", "").lower() not in ("1", "true")
    if enable_legacy:
        identity = application.state.daemon_descriptor
        asyncio.create_task(_start_legacy_redirect(identity.port, _LEGACY_PORT))

    # V3.4.22 LLD-02: signal-worker background drainer (S8-SK-01 fix).
    # Without this, ``signals.enqueue`` fills a bounded queue and drops
    # silently after ~250 recalls — learning_signals never populates,
    # Phase 3 never activates, the whole Living Brain stays cold.
    if os.environ.get("SLM_SIGNALS_ENABLED", "1") != "0":
        try:
            from superlocalmemory.learning import signal_worker as _sw
            _learning_db = state_path("learning.db")
            _sw.start(_learning_db)
            application.state.signal_worker_started = True
            logger.info("signal_worker started on %s", _learning_db)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("signal_worker failed to start: %s", exc)
            application.state.signal_worker_started = False

    # V3.4.22 LLD-05: cross-platform adapter sync loop
    if os.environ.get("SLM_CROSS_PLATFORM_SYNC_DISABLED", "").lower() not in ("1", "true"):
        try:
            from superlocalmemory.cli.context_commands import build_default_adapters
            from superlocalmemory.hooks.sync_loop import schedule as _schedule_sync
            # Keep the task handle so it can be cancelled at shutdown (H-CONC-2)
            # — otherwise adapter file I/O outlives the daemon.
            application.state._sync_task = _schedule_sync(build_default_adapters())
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("cross-platform sync loop failed to start: %s", exc)

    # V3.4.22 LLD-03: bandit reward proxy settler + retention sweep loops
    if os.environ.get("SLM_BANDIT_DISABLED", "0") != "1":
        try:
            from superlocalmemory.server.bandit_loops import (
                schedule_bandit_loops,
            )
            schedule_bandit_loops(application, config)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("bandit loops failed to start: %s", exc)

    global _start_time
    _start_time = time.monotonic()
    _last_activity = time.monotonic()
    # v3.4.23: pre-format the ready message. Previous code passed a ternary as
    # the log format string with a fixed 2-arg tuple; when idle_timeout<=0 the
    # chosen branch had only one %d, triggering a TypeError on every startup.
    # Python's logging module then wrote the full stack to stderr. Because the
    # call runs inside FastAPI's stacked merged_lifespan, each dump was ~30 KB
    # and the error log grew to tens of MB within a day.
    _display_port = _configured_daemon_port()
    if idle_timeout <= 0:
        _ready_msg = f"Unified daemon ready on port {_display_port} (24/7 mode)"
    else:
        _ready_msg = (
            f"Unified daemon ready on port {_display_port} "
            f"(idle timeout: {idle_timeout}s)"
        )
    logger.info(_ready_msg)

    # Start optimize proxy httpx client if mounted
    try:
        _opt_proxy = getattr(application.state, "optimize_proxy", None)
        if _opt_proxy is not None:
            await _opt_proxy.startup()
    except Exception as _exc:  # pragma: no cover — defensive
        logger.warning("optimize_proxy startup failed (non-fatal): %s", _exc)

    # V3.6: Mount optimize API routes + restore persisted metrics + start flush loop
    try:
        from superlocalmemory.optimize.metrics.counters import MetricsCollector
        from superlocalmemory.optimize.metrics.persistence import MetricsPersistence
        from superlocalmemory.optimize.storage.db import CacheDB
        from superlocalmemory.server.routes.optimize import router as optimize_router
        application.include_router(optimize_router)

        # Restore persisted metrics counters on startup.
        # #48 fix: build ONE CacheDB + MetricsPersistence and reuse them for the
        # life of the daemon. The old code constructed a new CacheDB() on every
        # 60s flush, which re-ran schema init ("Schema initialized" log spam),
        # the corruption check, and AES-key derivation on every tick.
        _metrics_db = CacheDB()
        _metrics_persistence = MetricsPersistence()
        _metrics_persistence.load(MetricsCollector.get_instance(), _metrics_db)

        # Periodic flush — every 60s (OPT-005: guard + task ref for shutdown)
        _metrics_flush_task = getattr(application.state, "_optimize_flush_task", None)
        if _metrics_flush_task is None or _metrics_flush_task.done():
            async def _metrics_flush_loop():
                while True:
                    await asyncio.sleep(60)
                    try:
                        _metrics_persistence.flush(
                            MetricsCollector.get_instance(), _metrics_db
                        )
                    except Exception as e:
                        logger.warning("metrics flush error: %s", e)
            application.state._optimize_flush_task = asyncio.create_task(
                _metrics_flush_loop()
            )
    except Exception as e:
        logger.warning("optimize module not available: %s", e)

    # 4.0.8: periodic full consolidation. Idle-gated and lock-guarded — see
    # _consolidation_timer_loop. Started here rather than at import so a daemon
    # that never completes startup never schedules work.
    _consol_task = getattr(application.state, "_consolidation_task", None)
    if _consol_task is None or _consol_task.done():
        application.state._consolidation_task = asyncio.create_task(
            _consolidation_timer_loop(application)
        )

    # v3.6.7: Start MCP Streamable-HTTP session manager (GOTCHA #1).
    # streamable_http_app() carries its own Starlette lifespan that initialises
    # an anyio task group inside the session manager. Without entering that
    # lifespan every POST /mcp 500s with "Task group is not initialized."
    # AsyncExitStack enters the context only when _mcp_app was mounted; if the
    # mount failed (non-fatal) the daemon starts normally without HTTP MCP.
    # v3.6.9 (#34): wrap the MCP lifespan in shield so an unhandled exception
    # or tool-level cancellation inside a session manager task group cannot
    # propagate out and trigger uvicorn's graceful-shutdown handler.
    async with AsyncExitStack() as _mcp_stack:
        # Belt-and-suspenders: if an unexpected error occurs between here and
        # yield, the stack's __aexit__ ensures the lease is released even when
        # the normal teardown path (after yield) is bypassed.  The explicit
        # _release_canonical_remember_runtime call in teardown is idempotent.
        if canonical_remember_runtime is not None:
            _mcp_stack.callback(
                _release_canonical_remember_runtime, application, canonical_remember_runtime
            )

        if _mcp_app is not None:
            try:
                await _mcp_stack.enter_async_context(
                    _mcp_app.router.lifespan_context(_mcp_app)
                )
                logger.info("MCP HTTP session manager started (Streamable-HTTP on /mcp)")
            except Exception as _mcp_lifespan_exc:
                logger.warning(
                    "MCP HTTP session manager failed to start (non-fatal, stdio still works): %s",
                    _mcp_lifespan_exc,
                )

        # Publish the resident engine to the pending materializer only after
        # every synchronous startup writer has finished. Publishing it beside
        # engine.initialize() allowed a stranded ingestion operation to race
        # BackendOrchestrator status writes while the daemon was still inside
        # lifespan, so /health could never become reachable.
        global _engine, _profile_runtime
        _profile_runtime = profile_runtime
        _engine = engine

        # Boot sweep for wedged enrichment leases (#131): a killed daemon
        # leaves rows stuck in enriching; the materializer loop reclaims
        # them only once it cycles, and its reap used to sit behind the
        # embedder-warmth gate. Run the pure-SQL reap deterministically
        # here so recovery never depends on worker warmth. Fail-soft by
        # construction (the helper never raises).
        try:
            _swept = _reap_stuck_ingestion(getattr(engine, "_db", None))
            if _swept:
                logger.warning(
                    "Boot sweep terminalized %d stuck ingestion operation(s)",
                    len(_swept),
                )
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("ingestion boot sweep failed: %s", exc)

        # Uvicorn enters this lifespan only after it has bound the listener.
        # Publishing ``ready`` here prevents a failed competing process from
        # overwriting the live daemon descriptor before it owns the port.
        from superlocalmemory.server.routes.helpers import SLM_VERSION
        application.state.daemon_descriptor = _publish_process_descriptor(
            _configured_daemon_port(), SLM_VERSION, "ready",
        )
        _schedule_source_quality_repair(
            application,
            state_path("memory.db"),
            state_path("learning.db"),
        )
        _schedule_fact_entity_association_repair(
            application,
            state_path("memory.db"),
        )
        try:
            yield
        finally:
            await _cancel_fact_entity_association_repair(application)
            await _cancel_source_quality_repair(application)

    # Stop the projection drain. Its queue is durable, so an interrupted pass
    # costs a repeat of idempotent work and nothing else — but a live worker
    # writing into RocksDB and Lance while the process tears down around it has
    # no upside.
    try:
        from superlocalmemory.core.backend_orchestrator import get_orchestrator
        _orch = get_orchestrator()
        if _orch is not None:
            _orch.stop()
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("projection drain shutdown failed: %s", exc)

    # Cancel the cross-platform sync loop (H-CONC-2) so adapter file I/O does
    # not outlive the daemon.
    try:
        _sync_task = getattr(application.state, "_sync_task", None)
        if _sync_task is not None and not _sync_task.done():
            _sync_task.cancel()
            try:
                await _sync_task
            except asyncio.CancelledError:
                pass
    except Exception:  # pragma: no cover — defensive
        pass

    # Cancel the periodic consolidation loop. Not awaited to completion — a pass
    # can take minutes and shutdown must not block on it; the lock and the
    # engine's own transaction boundaries make an interrupted pass safe to redo.
    try:
        _consol = getattr(application.state, "_consolidation_task", None)
        if _consol is not None and not _consol.done():
            _consol.cancel()
    except Exception:  # pragma: no cover — defensive
        pass

    # Cancel optimize metrics flush loop + run final flush before shutdown
    try:
        _flush_task = getattr(application.state, "_optimize_flush_task", None)
        if _flush_task is not None and not _flush_task.done():
            _flush_task.cancel()
            try:
                await _flush_task
            except asyncio.CancelledError:
                pass
        # Final flush to persist the last window (H-04: use singleton)
        try:
            from superlocalmemory.optimize.metrics.counters import MetricsCollector
            from superlocalmemory.optimize.metrics.persistence import MetricsPersistence
            from superlocalmemory.optimize.storage.db import CacheDB as _FinalCacheDB
            MetricsPersistence().flush(
                MetricsCollector.get_instance(),
                _FinalCacheDB.get_default(),
            )
        except Exception:
            pass
    except Exception:  # pragma: no cover — defensive
        pass

    # Shutdown optimize proxy httpx client (symmetric with startup)
    try:
        _opt_proxy = getattr(application.state, "optimize_proxy", None)
        if _opt_proxy is not None:
            await _opt_proxy.shutdown()
    except Exception as _exc:  # pragma: no cover — defensive
        logger.warning("optimize_proxy shutdown failed (non-fatal): %s", _exc)

    # S9-W4 C2: symmetric shutdown. Prior version only flushed the
    # observe-buffer + signal_worker + engine. The following long-lived
    # subsystems lived on ``application.state`` but were never
    # explicitly cancelled / joined, so uvicorn's
    # ``timeout_graceful_shutdown=10`` silently killed live threads
    # mid-commit: HealthMonitor probes, MeshBroker cleanup thread,
    # bandit settler asyncio tasks, and the process-wide cost-log
    # connection cache. A WAL commit interrupted mid-flight could
    # leave ``evolution_llm_cost_log`` with torn rows.
    #
    # New policy: every subsystem that stored a handle on
    # ``application.state`` MUST be stopped here, in reverse start
    # order. Each stop is wrapped in try/except so one failure does
    # not skip the rest.
    _observe_buffer.flush_sync()

    _retention_stopped = _stop_deployment_retention(application)

    # S9-DASH-02: stop outcome-queue worker (final drain on graceful
    # shutdown). Any events left unpersisted are logged but not
    # replayed — signal capture is not load-bearing on correctness.
    try:
        from superlocalmemory.learning.outcome_queue import stop_worker
        _oq_remaining = stop_worker(timeout_s=2.0)
        if _oq_remaining:
            logger.info(
                "outcome_queue shutdown: %d events dropped on flush",
                _oq_remaining,
            )
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("outcome_queue stop failed: %s", exc)

    # Cancel bandit asyncio tasks (LLD-03). ``bandit_loops`` stashes
    # them at ``application.state.bandit_tasks``; if the attr is
    # missing we skip.
    _bandit_tasks = getattr(application.state, "bandit_tasks", None)
    if _bandit_tasks:
        try:
            for _t in _bandit_tasks:
                try:
                    _t.cancel()
                except Exception:  # pragma: no cover
                    pass
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("bandit_tasks cancel failed: %s", exc)

    # v3.4.36: Stop HookDaemon (Unix socket server).
    _hd = getattr(application.state, "hook_daemon", None)
    if _hd is not None:
        try:
            _hd.stop()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("hook_daemon stop failed: %s", exc)

    # v3.4.26: Stop QueueConsumer (recall_queue.db drainer).
    _qc = getattr(application.state, "queue_consumer", None)
    if _qc is not None:
        try:
            _qc.stop()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("queue_consumer stop failed: %s", exc)
    _rq = getattr(application.state, "recall_queue", None)
    if _rq is not None:
        try:
            _rq.close()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("recall_queue close failed: %s", exc)

    # v3.6.8: Stop recall-health monitor (owns a daemon thread).
    _rh_stop = getattr(application.state, "recall_health_stop", None)
    if _rh_stop is not None:
        try:
            _rh_stop.set()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("recall_health monitor stop failed: %s", exc)

    # Stop HealthMonitor (health_monitor.py owns a daemon thread).
    _health = getattr(application.state, "health_monitor", None)
    if _health is not None:
        try:
            stop_fn = getattr(_health, "stop", None)
            if callable(stop_fn):
                stop_fn()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("health_monitor stop failed: %s", exc)

    # Stop MeshBroker cleanup thread.
    _mesh = getattr(application.state, "mesh_broker", None)
    if _mesh is not None:
        try:
            stop_fn = getattr(_mesh, "stop_cleanup", None)
            if callable(stop_fn):
                stop_fn()
            else:  # pragma: no cover — older broker versions
                stop_fn = getattr(_mesh, "stop", None)
                if callable(stop_fn):
                    stop_fn()
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("mesh_broker stop failed: %s", exc)

    # Stop mDNS advertiser (symmetric with Phase C-2 startup). stop() joins
    # Zeroconf background threads (blocking) — run it OFF the event loop so
    # shutdown of other async resources isn't stalled (audit P1).
    _adv = getattr(application.state, "mesh_advertiser", None)
    if _adv is not None:
        try:
            await asyncio.to_thread(_adv.stop)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("mDNS advertiser stop failed (non-fatal): %s", exc)

    # LLD-02 SW3: flush pending signals to DB before closing. Bounded 3 s
    # to keep daemon shutdown snappy; drops + counts anything unwritten.
    if getattr(application.state, "signal_worker_started", False):
        try:
            from superlocalmemory.learning import signal_worker as _sw
            _sw.stop(timeout=3.0)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("signal_worker shutdown flush failed: %s", exc)

    # Close the process-wide evolution cost-log connection cache
    # BEFORE engine.close so fsyncs land under our own control, not
    # under uvicorn's SIGTERM timeout. ``_close_cost_conns`` is
    # idempotent — the atexit hook is still registered but won't
    # re-close since the cache is cleared.
    try:
        from superlocalmemory.evolution import llm_dispatch as _ld
        _ld._close_cost_conns()
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("evolution cost-conn cache close failed: %s", exc)

    # Drop the trigram cache conn symmetrically.
    # D-02: use module-level reference (_trigram_index_mod) to avoid re-importing
    # during interpreter teardown when the learning namespace may be gone.
    try:
        if _trigram_index_mod is not None:
            _trigram_index_mod._reset_cache_conn()
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("trigram cache conn close failed: %s", exc)

    # Flush the perf-log fd explicitly (the atexit hook still fires
    # but explicit close here is cheap insurance against uvicorn
    # killing the process before atexit runs).
    # D-03: use module-level reference (_perf_log_flush_fn) — a lazy import here
    # triggers macOS TCC xattr checks on the source .py at shutdown time, causing
    # PermissionError: "Operation not permitted: .../hooks/_outcome_common.py".
    try:
        if _perf_log_flush_fn is not None:
            _perf_log_flush_fn()
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("perf_log flush failed: %s", exc)

    # Shut down the enrichment pool before engine.close() so that any worker
    # still inside embed() receives cancellation before the embed pool is torn
    # down.  shutdown(wait=False, cancel_futures=True) is non-blocking: queued
    # futures are dropped and running futures complete their current call on
    # their own.  This prevents Python's atexit handler from calling
    # shutdown(wait=True) on a live embed worker, which would push the daemon
    # past the graceful-shutdown budget and cause the service manager to
    # SIGKILL the process.
    try:
        _shutdown_enrichment_pool_if_created()
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("enrichment pool shutdown failed (non-fatal): %s", exc)

    materializer_stopped = _stop_pending_materializer()
    canonical_writer_stopped = _release_canonical_remember_runtime(application)
    _profile_runtime = None
    _engine = None
    if engine is not None and materializer_stopped and canonical_writer_stopped:
        try:
            engine.close()
        except Exception:
            pass
    elif engine is not None:
        # The process is already shutting down. Do not close a database/model
        # object still owned by an admitted background operation; OS process
        # teardown is safer than racing that writer with engine.close().
        logger.warning(
            "Engine close deferred because a write-capable background component "
            "is still active"
        )
    _cleanup_process_descriptor(
        getattr(application.state, "daemon_descriptor", None),
    )
    logger.info("Unified daemon shutdown complete")
    if not _retention_stopped:
        raise RuntimeError(
            "retention scheduler remained active during daemon shutdown"
        )


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def _configure_mcp_transport_settings() -> dict:
    """Return kwargs for ``MCPServer.streamable_http_app(...)`` (mcp 2.0.0).

    FastMCP's mutable ``settings.stateless_http`` / ``.json_response`` /
    ``.streamable_http_path`` / ``.transport_security`` are gone in mcp 2.0.0.
    Those values are now keyword arguments to ``streamable_http_app()``.

    Fully-stateless is the default (``remote_mode.mcp_stateless()``). Under
    ``stateless_http=True`` we never pass ``session_idle_timeout`` or an
    event store — both are illegal/unused for transport sessions that do not
    exist. Callers pass the returned dict through as
    ``server.streamable_http_app(**kwargs)``.
    """
    from typing import Any

    from superlocalmemory.core.remote_mode import mcp_stateless

    stateless = bool(mcp_stateless())
    kwargs: dict[str, Any] = {
        "streamable_http_path": "/",
        "stateless_http": stateless,
        # json_response pairs with stateless so tool results complete as a
        # single HTTP body (no long-lived SSE). Required for reliable
        # gateway/hub forwarding and TestClient e2e.
        "json_response": True if stateless else False,
        "event_store": None,
        "host": "127.0.0.1",
    }

    # DNS-rebinding protection from env. Default: SDK localhost auto-protect
    # (host=127.0.0.1). Set SLM_MCP_ALLOWED_HOSTS=... to open to a LAN, or
    # "*" to disable protection entirely (trusted private network only).
    _mcp_allowed = os.environ.get("SLM_MCP_ALLOWED_HOSTS", "").strip()
    if _mcp_allowed:
        from mcp.server.transport_security import TransportSecuritySettings

        if _mcp_allowed == "*":
            logger.warning(
                "SLM_MCP_ALLOWED_HOSTS=* disables MCP DNS-rebinding "
                "protection entirely. Prefer an explicit host list; only "
                "use '*' on a trusted private network."
            )
            kwargs["transport_security"] = TransportSecuritySettings(
                enable_dns_rebinding_protection=False,
            )
        else:
            _hosts = [h.strip() for h in _mcp_allowed.split(",") if h.strip()]
            kwargs["transport_security"] = TransportSecuritySettings(
                enable_dns_rebinding_protection=True,
                allowed_hosts=_hosts,
                allowed_origins=[f"http://{h}" for h in _hosts],
            )
        logger.info("MCP transport security: allowed_hosts=%r", _mcp_allowed)

    return kwargs


def create_app() -> FastAPI:
    """Create the unified FastAPI application."""
    from superlocalmemory.server.routes.helpers import SLM_VERSION

    application = FastAPI(
        title="SuperLocalMemory V4 — Unified Daemon",
        description="Memory + Dashboard + Mesh — one process, one engine.",
        version=SLM_VERSION,
        lifespan=lifespan,
    )
    identity_port = _configured_daemon_port()
    application.state.daemon_descriptor = _process_descriptor(
        identity_port, SLM_VERSION, "starting",
    )
    application.state.reconfigure_engine = (
        lambda new_config, mode_change=False: _hot_reconfigure_engine(
            application, new_config, mode_change=mode_change,
        )
    )

    # -- Middleware --
    from superlocalmemory.server.profile_runtime import ProfileRuntimeMiddleware
    from superlocalmemory.server.security_middleware import SecurityHeadersMiddleware
    application.add_middleware(
        ProfileRuntimeMiddleware,
        app_state=application.state,
    )
    application.add_middleware(SecurityHeadersMiddleware)
    application.add_middleware(GZipMiddleware, minimum_size=1000)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:8765", "http://127.0.0.1:8765",
            "http://localhost:8767", "http://127.0.0.1:8767",  # legacy compat
            # M-04 (3.7.9): removed the undocumented port 8417 origin — it had
            # no known consumer and let any local service on 8417 make
            # credentialed cross-origin requests to the API.
        ],
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=[
            "Content-Type", "Authorization", "X-SLM-API-Key",
            "X-SLM-Daemon-Capability", "X-SLM-Target-Instance",
        ],
    )

    # -- Register all dashboard routes (from existing api.py) --
    _register_dashboard_routes(application)

    # -- Mesh routes (Phase C) --
    try:
        from superlocalmemory.server.routes.mesh import router as mesh_router
        application.include_router(mesh_router)
    except ImportError:
        pass

    # -- Mesh 3c protocol routes: state-delta (LWW) + lock-delta (fencing) --
    try:
        from superlocalmemory.server.routes.mesh_state import router as mesh_state_router
        application.include_router(mesh_state_router)
    except ImportError:
        pass
    try:
        from superlocalmemory.server.routes.mesh_lock import router as mesh_lock_router
        application.include_router(mesh_lock_router)
    except ImportError:
        pass

    # -- Entity routes (Phase D) --
    try:
        from superlocalmemory.server.routes.entity import router as entity_router
        application.include_router(entity_router)
    except ImportError:
        pass

    # -- Ingestion route (Phase E) --
    try:
        from superlocalmemory.server.routes.ingest import router as ingest_router
        application.include_router(ingest_router)
    except ImportError:
        pass

    # -- Brain route (LLD-04 v2: /api/v3/brain + deprecated shims) --
    try:
        from superlocalmemory.server.middleware.security_headers import (
            SecurityHeadersMiddleware as StrictSecurityHeadersMiddleware,
        )
        from superlocalmemory.server.routes.brain import (
            router as brain_router,
        )
        application.include_router(brain_router)
        # Strict CSP / XFO / XCTO / Referrer-Policy — applies to every
        # response including the Brain route. Added as the outermost
        # middleware so it overrides the legacy security_middleware's
        # looser CSP on requests that pass through this strict wall.
        application.add_middleware(StrictSecurityHeadersMiddleware)
    except ImportError as exc:  # pragma: no cover — defensive wiring
        logger.warning("brain router not wired: %s", exc)

    # -- Prewarm route (LLD-01 §4.4 — S8-SK-02 fix) --
    # POST /internal/prewarm populates active_brain_cache after every
    # tool_use. Without this handler, the async hook POSTs to a 404 and
    # the cache never gets populated, which made every UserPromptSubmit
    # a structural miss. All 4 auth gates applied inside the route.
    try:
        from superlocalmemory.server.routes.prewarm import (
            router as prewarm_router,
        )
        application.include_router(prewarm_router)
    except ImportError as exc:  # pragma: no cover — defensive wiring
        logger.warning("prewarm router not wired: %s", exc)

    # -- Token route — auto-inject install token into the local dashboard --
    # GET /internal/token returns the install token to loopback+origin-
    # scoped browser callers so brain.js (and any future token-gated
    # dashboard fetch) can include X-Install-Token without ever asking
    # the non-technical user to paste it. Non-browser clients (MCP, CLI,
    # IDE adapters) keep reading ~/.superlocalmemory/.install_token
    # directly and sending the header themselves.
    try:
        from superlocalmemory.server.routes.token import (
            router as token_router,
        )
        application.include_router(token_router)
    except ImportError as exc:  # pragma: no cover — defensive wiring
        logger.warning("token router not wired: %s", exc)

    # ── Optimize proxy (optional, fail-open) ──────────────────────────────
    # Mounts on the existing daemon port 8765. Proxy routes carry provider
    # API keys (x-api-key, Authorization), NOT the SLM API key. Auth-exempt
    # path prefixes are configured below in the auth_middleware block.
    try:
        from superlocalmemory.optimize.config import _set_config_store, get_shared_store
        from superlocalmemory.optimize.proxy.server import ProxyApp, build_proxy_router

        # ONE shared ConfigStore for daemon + routes + watchdog + proxy reload
        # (fixes W-05 fresh-store-per-request; powers runtime hot-reload).
        _opt_store = get_shared_store()
        _set_config_store(_opt_store)
        _opt_cfg = _opt_store.get()
        # W-03 fix: the proxy path is gated by proxy_enabled ALONE. The master
        # `enabled` gates only the SDK adapter, never the proxy mount.
        if _opt_cfg.proxy_enabled:
            _proxy = ProxyApp(config=_opt_cfg)
            application.state.optimize_proxy = _proxy
            _proxy_router = build_proxy_router(_proxy)
            # prefix="" — proxy claims /v1/*, /v1beta/* directly.
            application.include_router(_proxy_router, prefix="")
            # v3.6.10: runtime hot-reload — rebuild the proxy HookChain whenever
            # optimize.json changes so cache_enabled / compress_enabled can be
            # toggled INDEPENDENTLY from the UI with no restart. UI save fires the
            # callback immediately; external edits are caught by the 2s watchdog.
            _opt_store.register_change_callback(_proxy.reload_from_config)
            logger.info(
                "optimize.proxy mounted on /v1/*, /v1beta/*  port=8765 "
                "(runtime cache/compress hot-reload enabled)"
            )
        else:
            application.state.optimize_proxy = None
        # H1 fix: the config watchdog must run REGARDLESS of proxy state so
        # optimize.json edits (cache/compress toggles, and a future
        # proxy_enabled flip) are picked up at runtime. Previously it only
        # started when the proxy was already on, so a daemon that booted with
        # the proxy off never saw any optimize.json change. start_watchdog()
        # is idempotent.
        _opt_store.start_watchdog()
    except ImportError:
        application.state.optimize_proxy = None
        logger.debug("optimize.proxy not installed — skipping")
    except Exception as _exc:  # pragma: no cover — defensive
        application.state.optimize_proxy = None
        logger.warning("optimize.proxy mount failed (non-fatal): %s", _exc)

    # -- Daemon-specific routes --
    _register_daemon_routes(application)

    # -- MCP Streamable-HTTP transport at /mcp (mcp 2.0.0 fully-stateless) --
    # Mount the MCPServer as a Starlette ASGI sub-app so ALL clients
    # (Claude Code sessions, subagents, desktop, hermes) share ONE daemon
    # process instead of spawning an `slm mcp` subprocess per connection.
    # The session manager lifespan is started in lifespan() via AsyncExitStack.
    # Fail-open: if import or mount fails, stdio transport keeps working.
    #
    # streamable_http_path="/" so that when mounted at "/mcp" the effective
    # user-facing endpoint is exactly http://127.0.0.1:8765/mcp.
    # (FastAPI strips the mount prefix before the sub-app sees the request.)
    try:
        from superlocalmemory.mcp.server import server as _mcp_server
        from superlocalmemory.core.remote_mode import is_remote_mode

        # mcp 2.0.0: transport knobs are kwargs to streamable_http_app(), not
        # mutable settings.stateless_http / .json_response / .transport_security.
        _mcp_kwargs = _configure_mcp_transport_settings()
        if _mcp_kwargs.get("stateless_http"):
            if is_remote_mode():
                logger.info(
                    "MCP transport: STATELESS (default; SLM_REMOTE) — gateways/hubs "
                    "may forward tool calls without a transport session id. "
                    "App-level session_init remains available."
                )
            else:
                logger.info(
                    "MCP transport: STATELESS (default) — no Mcp-Session-Id "
                    "required; json_response=True. Opt out with SLM_MCP_STATEFUL=1."
                )
        else:
            logger.warning(
                "MCP transport: STATEFUL (SLM_MCP_STATEFUL or SLM_MCP_STATELESS=0) "
                "— clients must replay Mcp-Session-Id after initialize."
            )

        global _mcp_app
        _mcp_app = _mcp_server.streamable_http_app(**_mcp_kwargs)

        # v3.6.10: per-agent-ID routing — /mcp/{agent_id} extracts the agent
        # identity from the URL path and places it in a ContextVar so all MCP
        # tools (remember, recall, etc.) automatically use the correct namespace.
        # AgentIDExtractorASGI lives in mcp/agent_context so it is unit-testable
        # (tests/test_mcp/test_agent_context.py) rather than buried inline here.
        from superlocalmemory.mcp.agent_context import AgentIDExtractorASGI

        application.mount("/mcp", AgentIDExtractorASGI(_mcp_app))
        logger.info(
            "MCP HTTP transport mounted at /mcp (Streamable HTTP, mcp 2.0.0, "
            "stateless=%s, port %d; per-agent routing enabled)",
            bool(_mcp_kwargs.get("stateless_http")),
            _configured_daemon_port(),
        )
    except Exception as _mcp_exc:  # pragma: no cover — defensive
        logger.warning("MCP HTTP mount failed (non-fatal, stdio still works): %s", _mcp_exc)

    return application


def _register_dashboard_routes(application: FastAPI) -> None:
    """Mount all existing dashboard routes from server/routes/*.

    Extracted from api.py's create_app() to avoid duplicate MemoryEngine.
    """
    # D-04: Copy UI assets to the data dir at daemon startup to avoid macOS
    # xattr/TCC PermissionError on source-tree files in editable installs.
    # The data dir has no quarantine attributes; the copy is idempotent (same
    # content from the same package) so concurrent daemon starts are safe.
    # Falls back to the source path with a WARNING — never crashes the daemon.
    import shutil as _shutil

    from superlocalmemory.server.api import UI_DIR as _source_ui_dir
    _data_ui_dir = state_path("ui")
    try:
        _data_ui_dir.mkdir(parents=True, exist_ok=True)
        if _source_ui_dir.is_dir():
            _shutil.copytree(
                str(_source_ui_dir),
                str(_data_ui_dir),
                dirs_exist_ok=True,  # idempotent; safe under concurrent starts
            )
        UI_DIR = _data_ui_dir
    except Exception as _ui_copy_exc:
        # D-04 fallback: source path. Logged as WARNING (not DEBUG) so operators
        # can diagnose PermissionError on editable installs. Never silently hidden.
        logger.warning(
            "D-04: UI copy to data dir failed; serving from source path %s: %s",
            _source_ui_dir,
            _ui_copy_exc,
        )
        UI_DIR = _source_ui_dir

    # Rate limiting (graceful)
    try:
        from superlocalmemory.core.remote_mode import (
            is_rate_limit_exempt,
            rate_limit_config,
        )
        from superlocalmemory.infra.rate_limiter import RateLimiter
        # v3.6.12 (issue #40): thresholds are env-tunable (SLM_RATE_LIMIT_WRITE/
        # READ/WINDOW) so distributed/LAN operators can raise them. Defaults
        # unchanged (30 writes / 120 reads per 60s) for the local case.
        _rl_write, _rl_read, _rl_window = rate_limit_config()
        _write_limiter = RateLimiter(max_requests=_rl_write, window_seconds=_rl_window)
        _read_limiter = RateLimiter(max_requests=_rl_read, window_seconds=_rl_window)

        # S9-DASH-09: loopback (127.0.0.1 / ::1) is the local dashboard and
        # makes many rapid reads (Brain + tabs + polling). L-03 (3.7.9): rather
        # than exempt loopback entirely, give it a *generous* limit — far above
        # normal UI polling — so a runaway local agent's write flood is still
        # eventually throttled. A LAN browser allowlisted in SLM_REMOTE mode
        # (is_rate_limit_exempt, non-loopback) stays fully exempt.
        _lb_write = max(300, _rl_write * 10)
        _lb_read = max(2000, _rl_read * 20)
        _lb_write_limiter = RateLimiter(max_requests=_lb_write, window_seconds=_rl_window)
        _lb_read_limiter = RateLimiter(max_requests=_lb_read, window_seconds=_rl_window)

        # Task #47: register the live limiters so the dashboard PUT
        # /api/v3/ratelimit reconfigures them at runtime (no restart), then
        # apply any persisted override from config.json.
        try:
            from superlocalmemory.infra.rate_limiter import (
                register_managed as _reg_rl,
            )
            from superlocalmemory.infra.rate_limiter import (
                reset_managed as _reset_rl,
            )
            _reset_rl()
            _reg_rl("write", _write_limiter)
            _reg_rl("read", _read_limiter)
            _reg_rl("lb_write", _lb_write_limiter)
            _reg_rl("lb_read", _lb_read_limiter)
            from superlocalmemory.server.routes.ratelimit import (
                load_persisted_limits as _load_rl,
            )
            _load_rl()
        except Exception as _reg_exc:  # pragma: no cover - defensive
            logger.debug("rate-limit runtime registration skipped: %s", _reg_exc)

        @application.middleware("http")
        async def rate_limit_middleware(request, call_next):
            client_ip = request.client.host if request.client else "unknown"
            is_write = request.method in ("POST", "PUT", "DELETE", "PATCH")
            from superlocalmemory.server.loopback import is_loopback as _is_lb_rl
            loopback = _is_lb_rl(client_ip)
            if not loopback and is_rate_limit_exempt(client_ip):
                return await call_next(request)
            if loopback:
                limiter = _lb_write_limiter if is_write else _lb_read_limiter
            else:
                limiter = _write_limiter if is_write else _read_limiter
            allowed, remaining = limiter.is_allowed(client_ip)
            if not allowed:
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=429,
                    content={"error": "Too many requests."},
                    headers={"Retry-After": str(getattr(limiter, 'window', 60))},
                )
            response = await call_next(request)
            response.headers["X-RateLimit-Remaining"] = str(remaining)
            return response
    except Exception as _rl_exc:
        # v3.6.12 (failopen-4): don't silently swallow — a missing rate limiter
        # is anti-abuse degradation worth a log line (unlike auth, this may
        # fail-open: rate limiting is not a security boundary).
        logger.warning("Rate-limit middleware not installed (%s)", _rl_exc)

    # Auth middleware (graceful)
    try:
        from superlocalmemory.infra.auth_middleware import (
            authorize_http_mcp_request,
            check_api_key,
            loopback_strict_mode_enabled,
        )
        from superlocalmemory.server.write_identity import (
            require_http_mutation_actor,
        )

        # Auth-exempt path prefixes — proxy routes carry provider API keys
        # (x-api-key for Anthropic, Authorization: Bearer for OpenAI, x-goog-api-key
        # for Gemini), never X-SLM-API-Key. Verified: auth_middleware.py:50-82
        # returns False for POST when api_key file exists and X-SLM-API-Key
        # is absent.
        _AUTH_EXEMPT_PREFIXES = ("/v1/", "/v1beta/")

        @application.middleware("http")
        async def auth_middleware(request, call_next):
            # Exempt proxy paths — LLM clients carry provider keys, not SLM keys.
            if request.url.path.startswith(_AUTH_EXEMPT_PREFIXES):
                return await call_next(request)
            is_write = request.method in ("POST", "PUT", "DELETE", "PATCH")
            records_recall_telemetry = request.url.path.startswith("/recall")
            requires_mutation_actor = is_write or records_recall_telemetry
            headers = dict(request.headers)
            client_host = request.client.host if request.client else ""
            if request.url.path.startswith("/mcp") and not authorize_http_mcp_request(
                headers,
                client_host=client_host,
            ):
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=401,
                    content={
                        "error": "Remote HTTP MCP requires a configured SLM API key."
                    },
                )
            # Defense-in-depth CSRF/DNS-rebinding guard. A loopback hostname is
            # not, by itself, a trusted web origin: a different local process can
            # serve a page on another port. Credentialless browser writes must
            # therefore originate from this daemon's exact port. A local
            # integration on another port may still write when it presents a
            # valid credential; require_http_mutation_actor below validates it.
            # LAN origins remain opt-in through remote mode. Non-browser clients
            # (CLI/MCP/curl) send no Origin and are unaffected.
            if requires_mutation_actor:
                _origin = headers.get("origin", "") or headers.get("Origin", "")
                if _origin:
                    from superlocalmemory.server.origin import (
                        origin_is_daemon,
                        origin_is_loopback,
                    )

                    _daemon = getattr(application.state, "daemon_descriptor", None)
                    _daemon_port = getattr(_daemon, "port", None) or _configured_daemon_port()
                    _ok_origin = origin_is_daemon(_origin, port=int(_daemon_port))
                    _has_browser_credential = any(
                        headers.get(_header)
                        for _header in (
                            "x-slm-daemon-capability",
                            "x-install-token",
                            "x-slm-api-key",
                        )
                    )
                    if not _ok_origin and origin_is_loopback(_origin) and _has_browser_credential:
                        _ok_origin = True
                    if not _ok_origin:
                        from superlocalmemory.core.remote_mode import is_remote_origin_allowed
                        _ok_origin = is_remote_origin_allowed(_origin)
                    if not _ok_origin:
                        from fastapi.responses import JSONResponse
                        return JSONResponse(
                            status_code=403,
                            content={"error": "cross-origin request rejected"},
                        )
                _mesh_secret = None
                if request.url.path.startswith("/mesh"):
                    _mesh_broker = getattr(application.state, "mesh_broker", None)
                    _mesh_secret = getattr(_mesh_broker, "_shared_secret", None)
                try:
                    request.state.authenticated_actor = require_http_mutation_actor(
                        request,
                        getattr(application.state, "daemon_descriptor", None),
                        actor_kind="http-route",
                        mesh_secret=_mesh_secret,
                    )
                except Exception as _identity_exc:
                    from fastapi import HTTPException as _HTTPException
                    from fastapi.responses import JSONResponse
                    if isinstance(_identity_exc, _HTTPException):
                        return JSONResponse(
                            status_code=_identity_exc.status_code,
                            content={"error": str(_identity_exc.detail)},
                        )
                    raise
                # v3.7.6 (#71/#73/#74): require_http_mutation_actor above is
                # the authoritative write-auth boundary — it accepts the
                # daemon capability, the dashboard install token, a matching
                # X-SLM-API-Key, or an uncredentialed loopback caller, and
                # fails closed for everyone else. Running check_api_key as an
                # unconditional second gate used to 401 write paths stage 1
                # had already authorized: capability-authenticated daemon
                # write-throughs (MCP `remember`, #71) and install-token
                # dashboard writes / config tests (#73/#74) whenever an
                # api_key file existed.
                #
                # v3.7.8 (F1/F2): that fix silently narrowed the api_key
                # feature — a configured api_key file used to force even
                # loopback writes to present a credential; after #71/#73/#74
                # loopback writes need none, with no opt-back-in. This is the
                # single enforcement point for the opt-in strict posture
                # (SLM_REQUIRE_API_KEY_LOOPBACK): re-run check_api_key, but
                # ONLY for the uncredentialed-loopback case — a caller who
                # presented none of the three credential headers above and
                # was authorized purely by being loopback. Credentialed
                # callers (capability / install token / api key) were already
                # validated by require_http_mutation_actor and are never
                # re-gated here, so #71/#73/#74 stay fixed.
                if loopback_strict_mode_enabled():
                    _has_credential = any(
                        headers.get(_h)
                        for _h in (
                            "x-slm-daemon-capability",
                            "x-install-token",
                            "x-slm-api-key",
                        )
                    )
                    if not _has_credential and not check_api_key(
                        headers, is_write=True
                    ):
                        from fastapi.responses import JSONResponse
                        return JSONResponse(
                            status_code=401,
                            content={
                                "error": (
                                    "SLM_REQUIRE_API_KEY_LOOPBACK is set: "
                                    "loopback writes must present a matching "
                                    "X-SLM-API-Key."
                                )
                            },
                        )
            # RBAC read gate (C3/audit SEC-C-01): sensitive content reads must
            # also respect roles. Engages ONLY when RBAC is active (>=1 user) —
            # single-operator installs are unaffected. Owner (no session) reads
            # freely unless company mode (require_login) is on; a logged-in user
            # must hold READ on the active workspace.
            # Config, learning, and behavioral reads expose installation,
            # preference, workflow, source-reputation, or outcome data.
            if _is_sensitive_dashboard_read(
                request.method, request.url.path,
            ):
                _resp = _rbac_read_gate(request, application.state)
                if _resp is not None:
                    return _resp
            # RBAC write gate: adapter process-control and similar
            # state-changing dashboard routes require WRITE permission.
            # Checked after the mutation-actor boundary above, which already
            # validated the machine-level credential; this layer checks the
            # user-level role within the workspace.
            if _is_adapter_control_mutation(
                request.method, request.url.path,
            ):
                _resp = _rbac_write_gate(request, application.state)
                if _resp is not None:
                    return _resp
            return await call_next(request)
    except Exception as _auth_exc:
        # v3.6.12 (failopen-1): security middleware must NEVER fail open silently.
        # The old `except (ImportError, Exception): pass` meant any failure to
        # install the auth gate left ALL write endpoints unauthenticated. Instead
        # log critically and install a fail-CLOSED fallback: writes from
        # non-loopback clients are rejected (loopback dashboard keeps working).
        logger.critical(
            "Auth middleware failed to install (%s) — installing fail-CLOSED "
            "fallback; non-loopback writes will be rejected.", _auth_exc,
        )
        try:
            from superlocalmemory.server.loopback import is_loopback as _is_lb
        except Exception:
            import ipaddress as _ipa_fb

            def _is_lb(h: str) -> bool:  # type: ignore[misc]
                if not h or h.lower() == "localhost":
                    return bool(h)
                try:
                    return _ipa_fb.ip_address(h).is_loopback
                except ValueError:
                    return False

        @application.middleware("http")
        async def _failclosed_auth(request, call_next):
            if request.url.path.startswith(("/v1/", "/v1beta/")):
                return await call_next(request)
            is_write = request.method in ("POST", "PUT", "DELETE", "PATCH")
            client_host = request.client.host if request.client else ""
            if is_write and not _is_lb(client_host):
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=503,
                    content={"error": "Auth subsystem unavailable; writes disabled."},
                )
            return await call_next(request)

    # Migration-readiness gate — outermost middleware; runs before auth and
    # rate-limiting.  When required schema migrations are in a failed state every
    # feature route receives a 503 so callers see one consistent "not ready"
    # signal instead of route-specific errors that vary by which schema element
    # is missing.  Health, status, and repair paths are always reachable so that
    # operators can monitor and recover the daemon without waiting for migrations.
    @application.middleware("http")
    async def _migration_readiness_gate(request, call_next):
        migration_result = getattr(application.state, "migration_result", None)
        if migration_result and _serving_blocked_by(migration_result):
            if not _is_migration_exempt_path(request.url.path):
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=503,
                    content={
                        "error": (
                            "Service unavailable: required schema migrations have "
                            "not completed. Check /health for details."
                        )
                    },
                )
        return await call_next(request)

    # Static files — UI_DIR is already the effective path (data-dir or source
    # fallback) set by the D-04 copy block above; mkdir is a no-op for
    # the data-dir path (already created) and guarded in the source-fallback case.
    from fastapi.staticfiles import StaticFiles
    try:
        UI_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass  # source path may not be writable; StaticFiles reads, not writes
    application.mount("/static", StaticFiles(directory=str(UI_DIR)), name="static")

    # Route modules
    from superlocalmemory.server.routes.adapters import router as adapters_router
    from superlocalmemory.server.routes.agents import router as agents_router
    from superlocalmemory.server.routes.backup import router as backup_router
    from superlocalmemory.server.routes.data_io import router as data_io_router
    from superlocalmemory.server.routes.events import router as events_router
    from superlocalmemory.server.routes.memories import router as memories_router
    from superlocalmemory.server.routes.profiles import router as profiles_router
    from superlocalmemory.server.routes.stats import router as stats_router
    from superlocalmemory.server.routes.v3_api import router as v3_router
    from superlocalmemory.server.routes.ws import manager as ws_manager
    from superlocalmemory.server.routes.ws import router as ws_router

    application.include_router(memories_router)
    application.include_router(stats_router)
    application.include_router(profiles_router)
    application.include_router(backup_router)
    application.include_router(data_io_router)

    # Optional routers — ImportError-safe so missing modules don't crash startup
    try:
        from superlocalmemory.server.routes.tiers import router as tiers_router
        application.include_router(tiers_router)
    except ImportError:
        logger.debug("tiers_router not available")

    try:
        from superlocalmemory.server.routes.evolution import router as evolution_router
        application.include_router(evolution_router)
    except ImportError:
        logger.debug("evolution_router not available")
    application.include_router(events_router)
    application.include_router(agents_router)
    application.include_router(ws_router)
    application.include_router(v3_router)
    application.include_router(adapters_router)

    # RBAC / teams (C3) — user & role administration + login.
    try:
        from superlocalmemory.server.routes.rbac import router as rbac_router
        application.include_router(rbac_router)
    except ImportError:
        logger.debug("rbac_router not available")

    # Config endpoints (storage, daemon, mesh, trust, forgetting)
    from superlocalmemory.server.routes.config_api import router as config_api_router
    application.include_router(config_api_router)

    # Task #47: dashboard-editable rate limits (GET/PUT /api/v3/ratelimit)
    from superlocalmemory.server.routes.ratelimit import router as ratelimit_router
    application.include_router(ratelimit_router)

    # v3.4.1 chat SSE
    for _mod_name in ("chat",):
        try:
            _mod = __import__(
                f"superlocalmemory.server.routes.{_mod_name}", fromlist=["router"],
            )
            application.include_router(_mod.router)
        except (ImportError, Exception):
            pass

    # Optional routers
    for _mod_name in ("learning", "lifecycle", "behavioral", "compliance", "insights", "timeline", "abstraction"):
        try:
            _mod = __import__(
                f"superlocalmemory.server.routes.{_mod_name}", fromlist=["router"],
            )
            application.include_router(_mod.router)
        except (ImportError, Exception):
            pass

    # Wire WebSocket manager
    import superlocalmemory.server.routes.data_io as _data_io_mod
    import superlocalmemory.server.routes.profiles as _profiles_mod
    _profiles_mod.ws_manager = ws_manager
    _data_io_mod.ws_manager = ws_manager

    # Root page
    from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

    # v3.4.23: /api/version — dashboard polls this to detect daemon upgrades
    # and auto-reload stale tabs (see ui/js/core.js::checkVersionFingerprint).
    try:
        from superlocalmemory import __version__ as _SLM_VERSION
    except Exception:  # pragma: no cover — defensive
        _SLM_VERSION = "unknown"

    @application.get("/api/version")
    async def api_version():
        return JSONResponse({"version": _SLM_VERSION})

    # v3.4.55: Mode switching & config API for the dashboard UI.
    # The auto-settings.js expects /api/v3/* endpoints. These routes
    # bridge the 3-mode config system to the existing settings page.

    @application.get("/api/v3/auto")
    async def v3_auto_detect():
        """Auto-detect available providers from environment."""
        import os as _os
        providers = []
        if _os.environ.get("OPENROUTER_API_KEY"):
            providers.append({"id": "openrouter", "name": "OpenRouter", "has_key": True})
        if _os.environ.get("OPENAI_API_KEY"):
            providers.append({"id": "openai", "name": "OpenAI", "has_key": True})
        if _os.environ.get("ANTHROPIC_API_KEY"):
            providers.append({"id": "anthropic", "name": "Anthropic", "has_key": True})
        # Ollama is always available as a local option if the server is reachable
        try:
            import httpx as _hx
            _r = _hx.get("http://localhost:11434/api/tags", timeout=2.0)
            ollama_models = []
            if _r.status_code == 200:
                ollama_models = [m["name"] for m in _r.json().get("models", [])]
            providers.append({
                "id": "ollama", "name": "Ollama (local)",
                "has_key": False, "running": True,
                "models": ollama_models,
            })
        except Exception:
            providers.append({
                "id": "ollama", "name": "Ollama (local)",
                "has_key": False, "running": False, "models": [],
            })
        return {"providers": providers}

    @application.get("/", response_class=HTMLResponse)
    async def root():
        index_path = UI_DIR / "index.html"
        if not index_path.exists():
            return (
                "<html><head><title>SuperLocalMemory V4</title></head>"
                "<body style='font-family:Arial;padding:40px'>"
                "<h1>SuperLocalMemory V4 — Unified Daemon</h1>"
                "<p><a href='/docs'>API Documentation</a></p>"
                "</body></html>"
            )
        # v3.4.23: substitute version placeholder so the dashboard can detect
        # upgrades and auto-reload. Read fresh each request (daemon uptime is
        # days, but we want zero caching surprises during development).
        #
        # 4.0.10: asset ?v= strings are now derived from file content instead of
        # being hand-written literals that tracked nothing. See
        # server/asset_versions.py — including what that does and does not fix.
        # Asset versioning is cosmetic. It must never be why this page 500s.
        #
        # The import is deferred (house style, keeps startup lean), which means
        # it resolves at REQUEST time — so when `pip install -e .` replaced the
        # installed package underneath a running daemon, this route began
        # answering "Internal Server Error" on the dashboard while every other
        # endpoint was fine. A stale hand-written version string is a trifle; a
        # blank page is not. Fall back to the file as written.
        try:
            from superlocalmemory.server.asset_versions import render_index

            return render_index(
                index_path, UI_DIR, substitutions={"__SLM_VERSION__": _SLM_VERSION},
            )
        except Exception as exc:  # noqa: BLE001 — serve the page regardless
            logger.warning(
                "asset version rewrite unavailable, serving index.html as "
                "written: %s: %s", type(exc).__name__, exc,
            )
            return index_path.read_text().replace("__SLM_VERSION__", _SLM_VERSION)

    @application.get("/favicon.ico", include_in_schema=False)
    async def favicon():
        """Serve the packaged SVG icon for browsers that request favicon.ico."""
        return RedirectResponse(url="/static/favicon.svg", status_code=307)

def _register_daemon_routes(application: FastAPI) -> None:
    """Add daemon-specific routes for CLI integration."""
    global _last_activity

    from superlocalmemory.server.routes.helpers import get_engine_lazy

    def _get_engine_or_503():
        """Lazy-init engine; raise 503 if init fails.

        Shared by every daemon route so a mode switch that nulled
        ``application.state.engine`` never leaves the daemon stuck in
        503 until restart.
        """
        engine = get_engine_lazy(application.state)
        if engine is None:
            raise HTTPException(503, detail="Engine not initialized")
        return engine

    def _require_daemon_actor(request: Request) -> str:
        """Authenticate the private capability for this exact process."""
        from superlocalmemory.server.write_identity import require_daemon_actor

        return require_daemon_actor(
            request,
            getattr(application.state, "daemon_descriptor", None),
        )

    def _require_write_actor(request: Request) -> str:
        """Authenticate a local write and return its trusted actor.

        Caller-provided agent labels are audit metadata only.  A mutating
        daemon client may borrow the process actor only after proving the
        private capability for this exact instance.  Same-origin dashboard
        writers instead present the install token, which is never the daemon
        process capability.
        """
        from superlocalmemory.server.write_identity import require_write_actor

        return require_write_actor(
            request,
            getattr(application.state, "daemon_descriptor", None),
            actor_kind="dashboard",
        )

    @application.get("/health")
    async def health(request: Request = None):
        _update_activity()
        try:
            from superlocalmemory.server.recall_health import get_recall_health

            recall_health = get_recall_health()
        except Exception:
            recall_health = {"recall_healthy": None}
        # Non-blocking peek: report status without forcing a re-init.
        engine = getattr(application.state, "engine", None)
        embedding_ready = bool(_embedding_warm)
        if engine is not None:
            embedder = getattr(engine, "_embedder", None)
            if embedder is None:
                retrieval_engine = getattr(engine, "_retrieval_engine", None)
                embedder = (
                    getattr(retrieval_engine, "_embedder", None)
                    if retrieval_engine is not None
                    else None
                )
            if embedder is not None and hasattr(embedder, "is_warm"):
                try:
                    embedding_ready = bool(embedder.is_warm)
                except Exception:
                    embedding_ready = False
        migration_result = getattr(application.state, "migration_result", None)
        migration_failures = list(
            (migration_result or {}).get("failed", []) or []
        )
        migration_details = (migration_result or {}).get("details", {}) or {}
        # Ready means "can serve", so it keys off the failures that actually
        # stop this daemon serving -- not off every failure. A data invariant
        # that ordinary use re-violated leaves every route working; reporting
        # not-ready for it told operators to restart, which fixed nothing a
        # background repair would not have fixed. Everything still shows up in
        # migration_failures and migration_failure_reasons below, named.
        migration_blocking = _serving_blocked_by(migration_result or {})
        migrations_ready = bool(migration_result) and not migration_blocking
        if migration_details.get("_crash"):
            migrations_ready = False
        writer_runtime = getattr(
            application.state,
            "canonical_remember_runtime",
            None,
        )
        readiness = {
            "engine": engine is not None,
            "migrations": migrations_ready,
            "writer": bool(
                writer_runtime is not None
                and getattr(writer_runtime, "ready", False)
            ),
            "embedding": embedding_ready,
            "recall_health": recall_health.get("recall_healthy") is True,
            "migration_failures": migration_failures,
            # Which of those are the reason this daemon will not serve, as
            # opposed to the ones it is reporting while serving normally.
            "migration_blocking": migration_blocking,
            # WHY each one failed, not just which. The runner already produces
            # a precise sentence per migration -- "safe repair did not restore
            # M043_...", "schema verification failed ... : <sqlite error>" --
            # and this endpoint computed it and then dropped it on the floor.
            # A migration recorded ``complete`` in migration_log can still be
            # reported failed here, because a completed migration is re-checked
            # by its own verify() on every start; with only a name to go on,
            # that reads as the health check contradicting the database. It is
            # not: they are answering different questions, and this is the
            # sentence that says which. Reported as #125.
            "migration_failure_reasons": {
                name: str(migration_details.get(name, "(no detail recorded)"))
                for name in migration_failures
            },
        }
        readiness["retrieval"] = bool(
            readiness["embedding"] and readiness["recall_health"]
        )
        base_ready = all((
            readiness["engine"],
            readiness["migrations"],
            readiness["writer"],
        ))
        fully_ready = base_ready and readiness["retrieval"]
        if fully_ready:
            runtime_state = "serving_full"
        elif base_ready and readiness["embedding"]:
            runtime_state = "serving_degraded"
        elif base_ready:
            runtime_state = "warming"
        else:
            runtime_state = "not_ready"
        lifecycle_state = "ready" if base_ready else "starting"
        identity = getattr(application.state, "daemon_descriptor", None)
        from superlocalmemory.server.profile_runtime import get_profile_runtime

        profile_snapshot = get_profile_runtime(application.state).snapshot
        # H-05 (3.7.9): operational metadata (pid, daemon identity including
        # capability_fingerprint/instance_id, active profile, readiness detail)
        # is returned only to loopback callers. A remote or unauthenticated
        # probe receives liveness fields only, so it cannot harvest targeting
        # intel (version stays, since clients legitimately gate on it).
        public = {
            "status": "ok",
            "ready": fully_ready,
            # Runtime readiness is more precise than descriptor lifecycle.
            # A process can be alive and identity-valid while retrieval warms.
            "state": lifecycle_state,
            "runtime_state": runtime_state,
            "version": getattr(application, 'version', 'unknown'),
        }
        # request is None only for direct internal/test calls (no HTTP client),
        # which are trusted; over HTTP FastAPI always injects the real Request.
        from superlocalmemory.server.loopback import is_loopback as _is_loopback_host
        from superlocalmemory.server.write_identity import _TEST_ISOLATION_ALLOWED

        client_host = request.client.host if (request and request.client) else ""
        _trusted = (
            request is None
            or _is_loopback_host(client_host)
            or (client_host == "testclient" and _TEST_ISOLATION_ALLOWED)
        )
        if not _trusted:
            return public
        return {
            "status": "ok",
            "ready": fully_ready,
            "readiness": readiness,
            "pid": os.getpid(),
            "engine": "initialized" if engine else "unavailable",
            "version": getattr(application, 'version', 'unknown'),
            # v3.4.52: clients can poll this to wait for embedding model
            # readiness before issuing recall calls.
            "embedding_warm": embedding_ready,
            # v3.6.8: True iff the semantic channel actually fired on the last
            # health probe; includes self-heal counters.
            "recall_health": recall_health,
            **(identity.public_health_fields() if identity is not None else {}),
            # Lifecycle state remains backward compatible for daemon
            # discovery; channel degradation is exposed separately.
            "state": lifecycle_state,
            "runtime_state": runtime_state,
            "active_profile": profile_snapshot.profile_id,
            "profile_generation": profile_snapshot.generation,
            # operational failure counts (visible to all team members)
            **_ops_failure_counts(engine, application),
            # issue #107: does this daemon's *imported* code still match the
            # installed distribution? ``version`` above reports what this
            # process loaded, which is self-consistent and therefore cannot
            # reveal staleness on its own. Loopback-only, alongside the other
            # operational metadata.
            "version_integrity": _version_integrity_payload(),
            # How far behind the second graph store is. A drain that stops
            # advancing is the failure that does not announce itself: every
            # other signal here stays green while the graph quietly diverges
            # from the record, and the only symptom is answers that are subtly
            # worse. A depth that does not fall is the thing to alert on.
            "projection": _projection_health(),
        }

    @application.get("/recall")
    async def recall(
        request: Request,
        q: str = "", query: str = "", limit: int = CANONICAL_RECALL_LIMIT,
        session_id: str = "",
        # Per-request profile routing (spec section 3/5): a non-empty
        # profile_id serves this one recall against THAT profile — same
        # existence check and same 404 envelope as POST /remember — without
        # reading or moving the ProfileRuntime active pointer. Empty keeps
        # the legacy active-profile path byte-identical.
        profile_id: str = "",
        # v3.8.2 client-driven agentic: ``fast`` is left UNSET (None) by default
        # so the daemon resolves the configured policy (retrieval.client_driven_agentic,
        # ships True). The agent hot path is consumed by a frontier LLM that
        # reformulates queries far better than the local Ollama model, so it
        # skips the internal agentic round and returns fast local retrieval (all
        # six channels + reranker) plus confidence signals; the client re-queries
        # on low confidence. An explicit ?fast=true / ?fast=false always wins.
        # See recall_pipeline.resolve_hot_path_fast.
        fast: bool | None = None,
        full: bool = False,
        include_source: bool = False,
        include_global: bool | None = None,
        include_shared: bool | None = None,
        window: str = "",
        as_of: str = "",
        known_as_of: str = "",
        valid_at: str = "",
        include_unknown: bool = False,
    ):
        _update_activity()
        search_query = q or query  # Accept both ?q= and ?query= for compatibility
        engine = _get_engine_or_503()
        req_profile = (profile_id or "").strip()
        # 4.1.14 audit: permission before existence on the read path, the
        # same order the write path enforces. Existence-first lets a caller
        # without READ probe which profile ids exist (404 vs data); READ on
        # the served namespace comes first so present-but-forbidden reads
        # 403 without confirming existence.
        from superlocalmemory.access.rbac import Permission
        from superlocalmemory.server.rbac_enforce import require_permission
        require_permission(
            request, Permission.READ, profile=req_profile or engine._profile_id,
        )
        if req_profile and not _daemon_profile_exists(engine, req_profile):
            from starlette.responses import JSONResponse

            return JSONResponse(
                _unknown_profile_body(req_profile), status_code=404,
            )
        if req_profile:
            # Same one-line-per-routed-request contract as POST /remember:
            # the recall served a named namespace, silently as far as the
            # active pointer is concerned.
            logger.info(
                "per-request profile routing: %s %s profile=%s",
                "GET", "/recall", req_profile,
            )
        if not search_query:
            from superlocalmemory.server.profile_runtime import get_profile_runtime
            _empty_snapshot = get_profile_runtime(application.state).snapshot
            return {
                "results": [], "count": 0, "query_type": "none",
                "retrieval_time_ms": 0,
                # 4.1.14 audit: even the empty-query shape echoes the served
                # namespace — never let a routed call look active-profiled.
                "profile": req_profile or _empty_snapshot.profile_id,
                "profile_generation": _empty_snapshot.generation,
            }
        # Phase 4b: normalize as_of at HTTP boundary. Invalid → return error.
        _as_of_raw = as_of.strip() if as_of else ""
        if _as_of_raw:
            from superlocalmemory.retrieval.temporal_utils import normalize_as_of
            _as_of_norm = normalize_as_of(_as_of_raw)
            if _as_of_norm is None:
                # Audit P1a: hard-reject with HTTP 400 (a bare dict serializes as
                # 200, so status-code-only clients would miss the rejection).
                from starlette.responses import JSONResponse
                return JSONResponse(
                    {
                        "error": "invalid_as_of",
                        "message": f"Cannot parse as_of: {_as_of_raw!r}",
                    },
                    status_code=400,
                )
            as_of = _as_of_norm
        else:
            as_of = ""
        def _normalize_temporal_query(value: str, error_code: str):
            raw = value.strip() if value else ""
            if not raw:
                return ""
            from superlocalmemory.retrieval.temporal_utils import normalize_as_of
            normalized = normalize_as_of(raw)
            if normalized is None:
                from starlette.responses import JSONResponse
                return JSONResponse(
                    {"error": error_code, "message": f"Cannot parse {error_code}: {raw!r}"},
                    status_code=400,
                )
            return normalized
        known_as_of = _normalize_temporal_query(known_as_of, "invalid_known_as_of")
        if not isinstance(known_as_of, str):
            return known_as_of
        valid_at = _normalize_temporal_query(valid_at, "invalid_valid_at")
        if not isinstance(valid_at, str):
            return valid_at
        # v3.8.2: resolve the client-driven-agentic default now so the concrete
        # bool drives BOTH the full-recall semaphore below and engine.recall().
        from superlocalmemory.core.recall_pipeline import resolve_hot_path_fast
        fast = resolve_hot_path_fast(fast, engine._config)
        # S9-DASH-02: session_id for the outcome-queue producer.
        # Priority: ?session_id= > X-SLM-Session-Id header > synthetic
        # "http:<ts>". Without a session_id the recall still works
        # (outcome just can't be hook-matched).
        effective_sid = session_id
        if not effective_sid:
            effective_sid = request.headers.get("X-SLM-Session-Id", "")
        if not effective_sid:
            import time as _t
            effective_sid = f"http:{int(_t.time() * 1000)}"
        recall_actor = getattr(request.state, "authenticated_actor", "")
        if not recall_actor:
            from superlocalmemory.server.write_identity import (
                require_http_mutation_actor,
            )
            recall_actor = require_http_mutation_actor(
                request,
                getattr(application.state, "daemon_descriptor", None),
                actor_kind="http-recall",
            )
        # Phase-1/D2: clamp cross-profile scope flags per enterprise recall policy.
        from superlocalmemory.core.admission import enforce_read_scope
        include_global, include_shared = enforce_read_scope(include_global, include_shared)
        # v3.4.32: mark recall in-flight so the pending materializer pauses
        # v3.4.52: run engine.recall() in a thread-pool executor so the
        # FastAPI event loop stays responsive for /health, /remember, and
        # concurrent /recall requests. Without this, a single slow full
        # recall (reranker timeout, cold embedder) blocks ALL endpoints.
        import asyncio
        _begin_recall()
        # v3.4.53: Opt-in deep recalls are gated by a semaphore to
        # prevent resource oversaturation. Ollama serialises concurrent
        # embedding calls and the reranker subprocess has a single lock —
        # queuing more than ~3 concurrent full recalls just adds latency.
        # Fast recalls retain the bounded retrieval channels but skip remote
        # agentic verification, so they do not need the full-recall semaphore.
        if not fast:
            await _recall_semaphore.acquire()
        try:
            # v3.8.3: bound the recall so CLI/MCP callers never hang on a
            # wedged embedder. Poll the executor future (which cannot be
            # cancelled) without blocking the loop, and give quality recall a
            # GENEROUS budget; only if it is exceeded do we serve the fast
            # keyword fallback. The orphaned recall finishes in the background.
            loop = asyncio.get_running_loop()
            _rf = loop.run_in_executor(
                None,
                lambda: engine.recall(
                    search_query, limit=limit, session_id=effective_sid,
                    agent_id=recall_actor,
                    fast=fast,
                    profile_id=req_profile or None,
                    include_global=include_global,
                    include_shared=include_shared,
                    window=window or None,
                    as_of=as_of or None,
                    known_as_of=known_as_of or None,
                    valid_at=valid_at or None,
                    include_unknown=include_unknown,
                ),
            )
            _budget = _recall_budget_s()
            _deadline = loop.time() + _budget
            while not _rf.done() and loop.time() < _deadline:
                await asyncio.sleep(0.05)
            if not _rf.done():
                _rf.add_done_callback(lambda f: (f.cancelled() or f.exception()))
                logger.warning(
                    "recall: semantic recall exceeded %.0fs budget for %r — "
                    "serving keyword fallback", _budget, (search_query or "")[:80],
                )
                from superlocalmemory.server.profile_runtime import get_profile_runtime
                fallback_snapshot = get_profile_runtime(application.state).snapshot
                return _recall_keyword_fallback(
                    engine, search_query, limit, profile_id=req_profile or None,
                    profile=req_profile or fallback_snapshot.profile_id,
                    profile_generation=fallback_snapshot.generation,
                )
            response = _rf.result()
            # v3.4.26: return the same field shape as recall_worker so
            # MCP processes proxying through the daemon get recall_trace-
            # compatible data without a second round trip.
            memory_ids = list({
                r.fact.memory_id for r in response.results[:limit]
                if r.fact.memory_id
            })
            memory_map = (
                engine._db.get_memory_content_batch(
                    memory_ids, req_profile or engine.profile_id,
                    include_global=True, include_shared=True,
                )
                if memory_ids else {}
            )
            # v3.6.6: single shared serialization chokepoint — budget + source
            # discipline + no_confident_match, identical across every surface.
            from superlocalmemory.server.recall_serializer import (
                recall_response_metadata,
                serialize_recall_response,
            )
            _rc = getattr(engine._config, "retrieval", None)
            results, no_confident_match = serialize_recall_response(
                response,
                limit=limit,
                memory_map={k: _sanitize_json_text(v) for k, v in memory_map.items()},
                per_fact_max=getattr(_rc, "recall_per_fact_max_chars", 2400),
                total_max=getattr(_rc, "recall_total_max_chars", 12000),
                # Option B: markers only on session-bearing recalls. A marker can
                # only buy a learning signal when a pending_outcomes row exists
                # to settle, and those exist only when session_id is present.
                include_marker=bool(session_id),
                full=full,
                include_source=include_source,
            )
            for _r in results:
                _r["content"] = _sanitize_json_text(_r.get("content", ""))
            from superlocalmemory.server.profile_runtime import get_profile_runtime

            profile_snapshot = get_profile_runtime(application.state).snapshot
            return {
                "ok": True,
                # The profile that actually served this recall: the routed
                # profile when ?profile_id= named one, else the active one.
                # Reporting the active profile for a routed request would
                # tell the caller their b-profile answer came from "default".
                # profile_generation stays from the snapshot — it describes
                # global switch state, which per-request routing never moves.
                "profile": req_profile or profile_snapshot.profile_id,
                "profile_generation": profile_snapshot.generation,
                "query": search_query,
                "query_type": response.query_type,
                "result_count": len(results),
                "retrieval_time_ms": round(response.retrieval_time_ms, 1),
                "channel_weights": {
                    k: round(v, 3)
                    for k, v in (response.channel_weights or {}).items()
                },
                "total_candidates": getattr(response, "total_candidates", 0),
                "results": results,
                "count": len(results),
                "no_confident_match": no_confident_match,
                **recall_response_metadata(response),
            }
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))
        finally:
            if not fast:
                _recall_semaphore.release()
            _end_recall()

    @application.post("/remember")
    async def remember(
        req: RememberRequest,
        request: Request,
        wait: bool = False,
    ):
        """Journal and commit a bounded, immediately-queryable receipt.

        ``wait`` remains accepted for compatibility, but never permits inline
        enrichment on this path. The daemon materializer owns all model, graph,
        vector, and post-hook work after this response.
        """
        trusted_actor_id = _require_write_actor(request)
        _update_activity()
        engine = _get_engine_or_503()
        # Per-request profile routing (spec section 3/5): a non-empty
        # profile_id is PURE ROUTING — this one write is served against that
        # profile while the ProfileRuntime active pointer and its generation
        # stay untouched. Routing replaces the stale-client guard for these
        # requests (the daemon is no longer single-profile for them); the
        # guard keeps its legacy slot below for an empty profile_id, where it
        # is trivially satisfied and unreachable for routed requests.
        req_profile = (req.profile_id or "").strip()
        if not req_profile:
            # Pass the STRIPPED value: whitespace-only input normalizes to
            # the empty legacy shape, so the guard stays a no-op for it
            # instead of 409ing on a truthy-but-blank string (#audit).
            _require_remember_profile(req_profile, engine._profile_id)
        # Single write-target id for everything below: the routed profile,
        # or the engine's active profile on the legacy path. Never a 409.
        write_profile = req_profile or engine._profile_id

        # v3.6.15 multi-scope: resolve the write scope. ``None`` (not specified
        # by the caller) → the configured default_scope (personal). Shared
        # memory is opt-in, so the default keeps every write private.
        _scope_cfg = getattr(engine._config, "scope", None)
        scope = req.scope or getattr(_scope_cfg, "default_scope", "personal")
        shared_with = req.shared_with

        # Keep the daemon compatibility route behind the exact RBAC/session
        # boundary used by dashboard mutations. Machine authentication proves
        # the caller may reach this daemon; WRITE permission proves the
        # authenticated dashboard user may mutate this profile. This must run
        # before either the trust pre-hook or the durable admission journal.
        from superlocalmemory.access.rbac import Permission
        from superlocalmemory.server.rbac_enforce import (
            require_permission,
            resolve_actor_roles,
        )

        require_permission(request, Permission.WRITE, profile=write_profile)
        if scope in {"shared", "global"}:
            require_permission(request, Permission.SHARE, profile=write_profile)
        # Unknown-profile rejection comes AFTER the permission gate. With
        # existence checked first, a company-mode caller without WRITE could
        # probe which profile ids exist: 404 for an absent one vs 403 for a
        # present-but-forbidden one. Permission first keeps both codes intact
        # while closing the oracle.
        if req_profile and not _daemon_profile_exists(engine, req_profile):
            from starlette.responses import JSONResponse

            return JSONResponse(
                _unknown_profile_body(req_profile), status_code=404,
            )
        if req_profile:
            # One line per routed request, nothing on the legacy path. A
            # daemon serving a multi-client fleet is otherwise a black box
            # about which namespace each write actually went to — the
            # routing is invisible in both the response envelope and the
            # pointer, which never moves.
            logger.info(
                "per-request profile routing: %s %s profile=%s",
                "POST", "/remember", req_profile,
            )
        runtime = getattr(application.state, "canonical_remember_runtime", None)
        if runtime is None:
            raise HTTPException(
                503,
                detail="canonical remember writer is not ready; retry shortly",
            )

        try:
            from superlocalmemory.core.remember_runtime import (
                validate_deterministic_admission,
            )
            from superlocalmemory.storage.admission_journal import Actor, RememberRequest

            meta = {}
            if req.tags:
                meta["tags"] = req.tags
            extra = getattr(req, "metadata", None)
            if isinstance(extra, dict):
                meta.update(extra)

            store_config = getattr(engine._config, "store", None)
            validate_deterministic_admission(
                req.content,
                max_verbatim_chars=getattr(
                    store_config,
                    "max_verbatim_chars",
                    24_000,
                ),
                max_ingest_bytes=getattr(
                    store_config,
                    "max_ingest_bytes",
                    1_048_576,
                ),
            )

            # Trust policy is intentionally outside both the journal and the
            # coordinator transaction. It can reject or audit a caller, but
            # cannot hold SQLite's sole writer while hooks do their work.
            engine._hooks.run_pre("store", {
                "operation": "store",
                "agent_id": trusted_actor_id,
                "profile_id": write_profile,
                "content_preview": req.content[:100],
            })

            # V4 Phase 4: OperationPolicyRegistry evaluation.
            # ActorContext is server-derived — principal_id from _require_write_actor,
            # client_host from ASGI request, session_token_hash from server headers.
            # NONE of these values come from the request body (RememberRequest).
            # This block runs BEFORE the durable admission journal is written.
            from superlocalmemory.core.actor_context import (
                ActorContext as _ActorContext,
            )
            from superlocalmemory.core.actor_context import (
                Transport as _Transport,
            )
            from superlocalmemory.core.operation_policy_registry import (
                _DEFAULT_REGISTRY as _policy_registry,
            )
            from superlocalmemory.core.operation_request import OperationKind as _OpKind

            _client_host = (
                request.client.host if request.client is not None else ""
            ) or ""
            _token_raw = (
                request.headers.get("x-slm-user-session", "")
                or (request.cookies.get("slm_session", "") if request.cookies else "")
            ) or ""
            _token_hash = (
                hashlib.sha256(_token_raw.encode()).hexdigest()[:16]
                if _token_raw else ""
            )
            # Detect single-user vs. company mode from the RBAC engine (server-side
            # state). Fail-open if the RBAC state cannot be read — a 503 from RBAC
            # already blocks the request via _rbac_write_gate. Here we only need the
            # mode string for unknown-kind fallback; REMEMBER is always a known kind.
            _rbac_state = getattr(application.state, "rbac", None)
            try:
                _is_company = bool(
                    _rbac_state is not None and _rbac_state.user_count() > 0
                )
            except Exception:
                _is_company = False
            _policy_mode = "company" if _is_company else "local"

            _http_actor = _ActorContext(
                principal_id=trusted_actor_id,
                roles=resolve_actor_roles(request, profile=write_profile),
                # The daemon's ACTIVE profile stays truthful here: per-request
                # routing does not move it, and policy evaluates the caller
                # against the profile it is actually serving.
                active_profile_id=engine._profile_id,
                transport=_Transport.HTTP,
                client_host=_client_host,
                session_token_hash=_token_hash,
            )
            _policy_decision = _policy_registry.evaluate(
                _OpKind.REMEMBER, _http_actor, _policy_mode,
            )
            if not _policy_decision.allowed:
                # Map to PermissionError: the except block below converts this
                # to HTTP 403 — consistent with AdmissionAuthorizationError.
                raise PermissionError(
                    f"operation policy denied REMEMBER: {_policy_decision.reason}"
                )

            admission = RememberRequest(
                content=req.content,
                profile_id=write_profile,
                source_type="http",
                idempotency_key=req.idempotency_key or uuid.uuid4().hex,
                metadata=meta,
                scope=scope,
                shared_with=tuple(shared_with or ()),
                trusted_actor_id=trusted_actor_id,
                session_id=req.session_id,
                session_date=req.session_date,
            )
            actor = Actor(
                principal_id=trusted_actor_id,
                allowed_profiles=frozenset({write_profile}),
                allowed_scopes=frozenset({scope}),
            )
            # The whole request has a 1.5 s ceiling, and the two phases below
            # are sequential, so the ceiling has to be shared between them
            # rather than granted twice. Measured from here.
            _store_started = time.monotonic()
            receipt = await asyncio.to_thread(
                runtime.remember,
                admission,
                actor,
                deadline_ms=2_000,
            )
            payload = dict(receipt.payload)
            fact_ids = list(payload.get("fact_ids") or [])

            # The durable receipt is already committed above; nothing below can
            # fail this write. What remains is the window in which the memory can
            # only be found by quoting its own wording — a fact with no vector is
            # invisible to the semantic channel, so the memory describing what is
            # happening right now is the hardest one to find.
            #
            # Every entry point — command line, tool interface, dashboard —
            # arrives here, so closing the window here closes it for all of them
            # rather than for whichever door happened to be used.
            #
            # Strictly bounded, because this daemon serves many sessions at once:
            # the work runs off the event loop, on a two-worker pool, and yields
            # to any recall in flight. Past the deadline the caller gets exactly
            # the previous behaviour and the background materializer finishes the
            # job.
            # A caller that did not ask to wait still gets a real attempt, not a
            # token one. Almost no client passes wait=true, so a small budget
            # here meant almost every memory in practice was returned findable by
            # wording only — the default path deciding the product's behaviour.
            #
            # But it gets what is LEFT of the ceiling, not a second full budget.
            # The durable write above can legitimately consume most of the 1.5 s
            # under contention, and granting the full enrichment window on top of
            # that produced receipts well past 3 s — over a ceiling the changelog
            # states. A caller that asked to wait may exceed the shared ceiling,
            # because that is what asking to wait means; nobody else may.
            _elapsed = time.monotonic() - _store_started
            _remaining = _REMEMBER_TOTAL_CEILING_SECONDS - _elapsed
            if wait:
                enrich_budget = _REMEMBER_ENRICHMENT_WAIT_SECONDS
            else:
                enrich_budget = min(
                    1.0, _REMEMBER_ENRICHMENT_WAIT_SECONDS, max(0.0, _remaining),
                )
            if enrich_budget <= 0.0:
                logger.warning(
                    "the durable write used the whole %.1fs budget (%.2fs) — this "
                    "memory is findable by its wording and the background pass "
                    "will attach its vector",
                    _REMEMBER_TOTAL_CEILING_SECONDS, _elapsed,
                )
            enriched = 0
            # Taken before submitting, released by the worker. If none is free
            # the pool is already saturated, and queueing behind it would mean
            # writing to the database after this response has been sent — so the
            # write is simply reported as findable by wording and the background
            # pass picks it up, which is the intended degradation.
            _permit = _enrichment_semaphore.acquire(blocking=False)
            if not _permit:
                logger.warning(
                    "inline enrichment at capacity for %d fact(s) — deferred to "
                    "the background pass", len(fact_ids),
                )
            try:
                if not _permit:
                    raise _EnrichmentAtCapacity
                loop = asyncio.get_running_loop()
                try:
                    _pending = loop.run_in_executor(
                        _enrichment_executor(),
                        functools.partial(
                            _enrich_and_release,
                            engine, fact_ids, enrich_budget,
                            profile_id=write_profile,
                        ),
                    )
                except BaseException:
                    # Never handed to a worker, so nothing will release it.
                    _enrichment_semaphore.release()
                    raise
                enriched = await asyncio.wait_for(
                    _pending, timeout=enrich_budget + 0.25,
                )
            except _EnrichmentAtCapacity:
                pass
            except (TimeoutError, asyncio.TimeoutError):
                # Worth seeing. Sustained timeouts mean writes are coming back
                # findable by wording only, which is a real degradation and was
                # previously visible at debug level alone.
                logger.warning(
                    "inline enrichment exceeded its budget for %d fact(s) — "
                    "deferred to the background pass", len(fact_ids),
                )
            except Exception as exc:
                logger.warning(
                    "inline enrichment unavailable (%s: %s) — deferred to the "
                    "background pass", type(exc).__name__, exc,
                )

            searchable = "meaning" if enriched == len(fact_ids) and fact_ids else "wording"
            return {
                "ok": True,
                # The profile this write actually landed in: the routed
                # profile when the request named one, else the active one.
                # A routed caller must not be told the daemon's active
                # profile served their write.
                "profile": write_profile,
                "fact_ids": fact_ids,
                "count": len(fact_ids),
                # Storing a memory and being able to find it again are different
                # things, and reporting only the first is how a caller ends up
                # believing a memory is retrievable when it is not yet.
                "searchable_by": searchable,
                "enriched_now": enriched,
                "operation_id": payload["operation_id"],
                # One-release compatibility alias. The durable operation ID is
                # opaque and replaces the integer pending.db row identifier.
                "pending_id": payload["pending_id"],
                "status": "queryable",
                "materialization_state": payload["materialization_state"],
                "commit_sequence": payload.get("commit_sequence"),
                "note": (
                    "stored and searchable by meaning"
                    if searchable == "meaning"
                    else "stored and searchable by wording; "
                         "searchable by meaning shortly"
                ),
                # Retained for callers that already read it. It used to be
                # unconditionally true, because `wait` bought nothing. It now
                # buys a larger best-effort enrichment budget — still never a
                # guarantee, and still never a block on durability.
                "wait_ignored": False if wait else True,
            }
        except Exception as exc:
            from superlocalmemory.core.remember_admission import AdmissionRejected
            from superlocalmemory.core.remember_runtime import CanonicalRememberUnavailable
            from superlocalmemory.storage.admission_journal import (
                AdmissionAuthorizationError,
                AdmissionPayloadError,
                IdempotencyConflict,
            )

            # 4.1.14 audit: an unknown profile surfacing late (deleted
            # between the existence gate and admission) must stay a 404,
            # not a 503 retryable — a deleted profile never heals by
            # retrying. The coordinator wraps failures, so walk the cause
            # chain for the distinctive type instead of matching strings.
            from superlocalmemory.core.ingestion_command import (
                UnknownProfileError,
            )
            _cause: BaseException | None = exc
            _unknown = False
            _seen: set[int] = set()
            while _cause is not None and id(_cause) not in _seen:
                _seen.add(id(_cause))
                if isinstance(_cause, UnknownProfileError):
                    _unknown = True
                    break
                _cause = _cause.__cause__ or _cause.__context__
            if _unknown:
                from starlette.responses import JSONResponse

                return JSONResponse(
                    _unknown_profile_body(req_profile or write_profile),
                    status_code=404,
                )
            if isinstance(exc, CanonicalRememberUnavailable) or (
                isinstance(exc, AdmissionRejected) and exc.retryable
            ):
                raise HTTPException(
                    503,
                    detail="canonical remember is temporarily unavailable; retry shortly",
                ) from exc
            if isinstance(exc, AdmissionRejected):
                raise HTTPException(
                    422,
                    detail="remember admission was rejected by deterministic policy",
                ) from exc
            if isinstance(exc, (AdmissionAuthorizationError, PermissionError)):
                raise HTTPException(403, detail="remember admission is not authorized") from exc
            if isinstance(
                exc,
                (AdmissionPayloadError, IdempotencyConflict),
            ):
                raise HTTPException(422, detail=str(exc)) from exc
            logger.exception("canonical remember admission failed")
            raise HTTPException(500, detail="canonical remember admission failed") from exc

    @application.post("/observe")
    async def observe(req: ObserveRequest, request: Request):
        _update_activity()
        from superlocalmemory.server.write_identity import (
            authenticated_request_actor,
        )
        actor_id = authenticated_request_actor(
            request,
            getattr(application.state, "daemon_descriptor", None),
            actor_kind="http-observe",
        )
        result = _observe_buffer.enqueue(
            req.content,
            trusted_actor_id=actor_id,
        )
        return result

    # v3.4.26: CCQ consolidation via daemon so MCP clients don't need to
    # import CognitiveConsolidator (which pulls sentence-transformers).
    @application.post("/consolidate/cognitive")
    async def consolidate_cognitive_endpoint(body: dict, request: Request):
        _update_activity()
        engine = _get_engine_or_503()
        from superlocalmemory.access.rbac import Permission
        from superlocalmemory.server.rbac_enforce import require_permission
        require_permission(request, Permission.WRITE, profile=engine._profile_id)
        from superlocalmemory.server.route_mutations import (
            authorize_route_mutation,
        )
        authorization = authorize_route_mutation(
            request,
            operation="update",
            source_agent_id="http-cognitive-consolidation",
            profile_id=engine.profile_id,
        )
        try:
            pid = engine.profile_id
            from superlocalmemory.encoding.cognitive_consolidator import (
                CognitiveConsolidator,
            )
            consolidator = CognitiveConsolidator(db=engine._db)
            result = consolidator.run_pipeline(pid)
            authorization.complete()
            return {
                "ok": True,
                "profile_id": pid,
                "clusters_processed": result.clusters_processed,
                "blocks_created": result.blocks_created,
            }
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    # v3.4.26: run_maintenance via daemon so MCP doesn't import
    # EbbinghausCurve, ForgettingScheduler, or ConsolidationWorker.
    @application.post("/maintenance/run")
    async def run_maintenance_endpoint(body: dict, request: Request):
        _update_activity()
        engine = _get_engine_or_503()
        from superlocalmemory.access.rbac import Permission
        from superlocalmemory.server.rbac_enforce import require_permission
        require_permission(request, Permission.WRITE, profile=engine._profile_id)
        from superlocalmemory.server.route_mutations import (
            authorize_route_mutation,
        )
        authorization = authorize_route_mutation(
            request,
            operation="update",
            source_agent_id="http-maintenance",
            profile_id=engine.profile_id,
        )
        try:
            pid = engine.profile_id
            results: dict = {}
            try:
                from superlocalmemory.core.maintenance import run_maintenance as _run_maint
                maint_result = _run_maint(engine._db, engine._config, pid)
                results["langevin"] = {"updated": maint_result.get("updated", 0)}
            except Exception:
                logger.exception("maintenance langevin step failed")
                results["langevin"] = {"error": "internal error"}
            try:
                from superlocalmemory.learning.forgetting_scheduler import (
                    ForgettingScheduler,
                )
                from superlocalmemory.math.ebbinghaus import EbbinghausCurve
                ebb = EbbinghausCurve(engine._config.forgetting)
                sched = ForgettingScheduler(
                    engine._db, ebb, engine._config.forgetting,
                )
                results["forgetting"] = sched.run_decay_cycle(pid, force=False)
            except Exception:
                logger.exception("maintenance forgetting step failed")
                results["forgetting"] = {"error": "internal error"}
            try:
                from superlocalmemory.learning.consolidation_worker import (
                    ConsolidationWorker,
                )
                cw = ConsolidationWorker(
                    engine._db.db_path,
                    engine._db.db_path.parent / "learning.db",
                )
                count = cw._generate_patterns(pid, False)
                results["behavioral"] = {"patterns_mined": count}
            except Exception:
                logger.exception("maintenance behavioral step failed")
                results["behavioral"] = {"error": "internal error"}
            authorization.complete()
            return {"ok": True, "profile": pid, **results}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @application.get("/status")
    async def status():
        _update_activity()
        # Non-blocking peek — status must never force a re-init.
        engine = getattr(application.state, "engine", None)
        from superlocalmemory.server.profile_runtime import get_profile_runtime

        profile_snapshot = get_profile_runtime(application.state).snapshot
        config = getattr(application.state, "config", None)
        fact_count = 0
        entity_count = 0
        edge_count = 0
        projection_queue_depth = 0
        if engine is not None:
            try:
                fact_count = engine._db.get_fact_count(profile_snapshot.profile_id)
                entities = engine._db.execute(
                    "SELECT COUNT(*) AS c FROM canonical_entities "
                    "WHERE profile_id = ?",
                    (profile_snapshot.profile_id,),
                )
                entity_count = int(dict(entities[0])["c"]) if entities else 0
                edges = engine._db.execute(
                    "SELECT COUNT(*) AS c FROM graph_edges WHERE profile_id = ?",
                    (profile_snapshot.profile_id,),
                )
                edge_count = int(dict(edges[0])["c"]) if edges else 0
            except Exception:
                logger.debug("daemon status count query failed", exc_info=True)
            try:
                from superlocalmemory.storage import projection_outbox
                projection_queue_depth = projection_outbox.depth(engine._db)
            except Exception:
                logger.debug("projection queue depth unavailable", exc_info=True)
        db_path = getattr(config, "db_path", None)
        db_size_mb = (
            round(db_path.stat().st_size / 1024 / 1024, 2)
            if db_path is not None and db_path.exists()
            else 0.0
        )
        mode = getattr(getattr(config, "mode", None), "value", "unknown")
        provider = getattr(getattr(config, "llm", None), "provider", "") or "none"
        return {
            "status": "running",
            "pid": os.getpid(),
            "uptime_s": round(time.monotonic() - (_start_time or time.monotonic())),
            "mode": mode,
            "provider": provider,
            "fact_count": fact_count,
            "entity_count": entity_count,
            "edge_count": edge_count,
            "base_dir": str(getattr(config, "base_dir", "")),
            "db_path": str(db_path or ""),
            "db_size_mb": db_size_mb,
            "idle_s": round(time.monotonic() - _last_activity),
            "port": application.state.daemon_descriptor.port,
            "legacy_port": _LEGACY_PORT,
            "profile": profile_snapshot.profile_id,
            "profile_generation": profile_snapshot.generation,
            # Facts stored but not yet in the graph and vector projections. The
            # CLI and MCP read their own status from here, so this is where the
            # number has to be for all three surfaces to agree.
            "projection_queue_depth": projection_queue_depth,
            # F2 fix: expose M028 backfill progress so operators can monitor
            # the post-upgrade fact/entity association repair state.
            "m028_backfill": getattr(
                application.state,
                "fact_entity_association_repair_status",
                None,
            ),
            # v3.8.2: zero-pain self-heal progress (embeddings/expansion/vector
            # index backfill after an upgrade). Dashboard renders a plain
            # "Optimizing memory…" line from this. Defaults to idle before start.
            "self_heal": globals().get("_SELF_HEAL_STATUS", {"state": "idle"}),
            # operational failure counts (dead-letter, degraded, stalled)
            **_ops_failure_counts(engine, application),
        }

    @application.get("/api/v3/components")
    async def components():
        """Component / dependency health (v3.8.2).

        Read-only snapshot from the central registry (core.component_registry)
        — the same source the self-heal thread acts on. Powers the dashboard
        'what's missing' report and `slm doctor`. Includes live 'retrying'
        overlays while a background repair is in flight. Never mutates state.
        """
        _update_activity()
        try:
            from superlocalmemory.core import component_registry
            cfg = getattr(application.state, "config", None)
            return component_registry.snapshot(cfg)
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @application.post("/api/v3/components/heal")
    async def heal_components(request: Request):
        """Trigger a component self-heal pass (dashboard 'Retry now').

        Repairs auto-fixable missing components (re-download missing models,
        install sqlite-vec). Runs in a background thread and returns
        immediately so the HTTP request never blocks on a multi-minute
        download; the dashboard polls GET /api/v3/components to watch the
        'retrying' → 'ok' transition. Safe to call repeatedly (no-op when
        healthy). Requires the dashboard write principal, like other
        dashboard mutations.
        """
        _require_write_actor(request)
        _update_activity()
        cfg = getattr(application.state, "config", None)

        def _run():
            try:
                from superlocalmemory.core import component_healer
                res = component_healer.heal_missing(
                    cfg,
                    on_progress=lambda k, m: logger.info(
                        "Manual heal[%s]: %s", k, m,
                    ),
                )
                logger.info("Manual component heal: %s", res)
            except Exception as exc:
                logger.warning("Manual component heal failed (non-fatal): %s", exc)

        threading.Thread(target=_run, daemon=True, name="manual-heal").start()
        return {"status": "started"}

    # ------------------------------------------------------------------
    # Operational Recovery & Admin Remediation  (V4 resilience slice)
    # ------------------------------------------------------------------

    @application.get("/operations/failed")
    async def list_failed_operations_endpoint(
        request: Request,
        profile: str = None,
    ):
        """Return all failed/stuck/degraded operations — admin surface.

        Requires MANAGE permission (OWNER or ADMIN role).  Returns three
        categories: dead-letter DLQ entries, DEGRADED completion manifests,
        and exhausted projection obligations.  Safe read-only; never mutates.
        """
        from superlocalmemory.server.rbac_enforce import require_permission
        from superlocalmemory.access.rbac import Permission

        require_permission(request, Permission.MANAGE)
        _update_activity()

        config = getattr(application.state, "config", None)
        db_path = getattr(config, "db_path", None)
        if db_path is None or not db_path.exists():
            return {"dead_letter": [], "degraded_manifests": [],
                    "exhausted_obligations": [], "total": 0}

        try:
            from superlocalmemory.core.ops_remediation import list_failed_operations
            return list_failed_operations(db_path, profile_id=profile)
        except Exception as exc:
            logger.warning("list_failed_operations endpoint error: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail="Failed to query operations")

    @application.post("/operations/{operation_id}/resolve")
    async def resolve_operation_endpoint(request: Request, operation_id: str):
        """Admin remediation: retry / force-reconcile / cancel a stuck operation.

        Body JSON: ``{"action": "retry"|"force_reconcile"|"cancel"}``

        Requires MANAGE permission.  Writes an audit event for every mutation.
        The action itself is delegated to ``core.ops_remediation.resolve_operation``.
        Returns ``{"success": bool, "action": str, "operation_id": str, ...}``.
        """
        from superlocalmemory.server.rbac_enforce import require_permission
        from superlocalmemory.access.rbac import Permission

        require_permission(request, Permission.MANAGE)
        _update_activity()

        body: dict = {}
        try:
            body = await request.json()
        except Exception:
            raise HTTPException(status_code=400, detail="JSON body required")

        action = body.get("action", "")
        if action not in ("retry", "force_reconcile", "cancel"):
            raise HTTPException(
                status_code=400,
                detail="action must be one of: retry, force_reconcile, cancel",
            )

        config = getattr(application.state, "config", None)
        db_path = getattr(config, "db_path", None)
        if db_path is None or not db_path.exists():
            raise HTTPException(status_code=503, detail="Database not available")

        engine = getattr(application.state, "engine", None)

        try:
            from superlocalmemory.core.ops_remediation import resolve_operation
            result = resolve_operation(db_path, engine, operation_id, action)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        except Exception as exc:
            logger.warning(
                "resolve_operation endpoint error op=%s action=%s: %s",
                operation_id, action, exc, exc_info=True,
            )
            raise HTTPException(status_code=500, detail="Remediation failed")

        # Audit trail — best effort, non-blocking
        try:
            from superlocalmemory.compliance.audit import AuditChain
            audit_path = state_path("audit_chain.db")
            actor_header = request.headers.get("X-Actor-Id", "admin")
            AuditChain(str(audit_path)).log(
                operation=f"ops_resolve:{action}",
                agent_id=actor_header,
                profile_id="",
                content_hash="",
                metadata={"operation_id": operation_id, "result": result},
            )
        except Exception:
            logger.debug("audit log for ops_resolve failed (non-fatal)", exc_info=True)

        return result

    @application.get("/list")
    async def list_facts(limit: int = 50):
        _update_activity()
        engine = _get_engine_or_503()
        try:
            facts = engine.list_facts(limit=limit)
            items = [
                {
                    "content": f.content[:100],
                    "fact_type": getattr(f.fact_type, 'value', str(f.fact_type)),
                    "created_at": (f.created_at or "")[:19],
                    "fact_id": f.fact_id,
                }
                for f in facts
            ]
            return {"results": items, "count": len(items)}
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @application.post("/stop")
    async def stop(request: Request):
        """Gracefully stop only the capability-bound process instance."""
        _require_daemon_actor(request)
        logger.info("Stop requested via API")
        _observe_buffer.flush_sync()
        # Signal uvicorn to shut down gracefully
        os.kill(os.getpid(), signal.SIGTERM)
        return {"status": "stopping"}

    @application.post("/api/daemon/restart")
    async def restart_daemon(request: Request):
        """Restart the daemon from the dashboard (non-technical end users).

        Spawns a DETACHED ``slm restart`` process (its own session) so it
        survives this daemon being stopped, then returns immediately. The child
        stops this daemon and starts a fresh one via the standard 5-step
        pipeline (namespace lock → stop → start → warmup → verify).
        """
        # Dashboard-callable: accept the install-token principal (same auth as
        # /remember and other dashboard mutations), not just the private CLI
        # capability — a non-technical user restarts from their own dashboard.
        _require_write_actor(request)
        import subprocess
        import sys as _sys

        from superlocalmemory.core.platform_utils import popen_platform_kwargs

        logger.info("Daemon restart requested via API")
        _observe_buffer.flush_sync()
        try:
            subprocess.Popen(
                [_sys.executable, "-m", "superlocalmemory.cli.main", "restart",
                 "--json"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                # CP-04: use the shared platform kwargs (CREATE_NO_WINDOW on
                # Windows, start_new_session on POSIX) like every other Popen so
                # a GUI-triggered restart never flashes a console window.
                # close_fds defaults to True on all platforms.
                **popen_platform_kwargs(),
            )
        except Exception:
            logger.exception("Failed to spawn restart process")
            return {"success": False, "error": "Could not initiate restart"}
        return {
            "success": True,
            "status": "restarting",
            "message": "Daemon restart initiated — it will be back in a few seconds.",
        }

    @application.post("/session/open")
    async def session_open(req: SessionOpenRequest, request: Request):
        """#49: Open a session locally — warm recall context with no model
        roundtrip, so a shell/session-start hook can call it directly
        (`slm session open`) instead of going through the MCP tool.
        """
        _update_activity()
        engine = _get_engine_or_503()
        if req.query:
            query = req.query
        elif req.project_path:
            query = f"project context {req.project_path}"
        else:
            query = "recent important decisions"
        try:
            from superlocalmemory.server.write_identity import (
                authenticated_request_actor,
            )
            actor_id = authenticated_request_actor(
                request,
                getattr(application.state, "daemon_descriptor", None),
                actor_kind="http-session-open",
            )
            resp = engine.recall(
                query,
                limit=req.max_results,
                agent_id=actor_id,
            )
            results = (
                getattr(resp, "results", None)
                or getattr(resp, "memories", None)
                or []
            )
            return {"ok": True, "query": query, "warmed": len(results)}
        except HTTPException:
            raise
        except Exception as exc:
            # Warming is best-effort — never fail the session-open hook.
            return {"ok": True, "query": query, "warmed": 0, "warning": str(exc)}

    @application.post("/session/close")
    async def session_close(req: SessionCloseRequest, request: Request):
        """#49: Close a session locally (e.g. a Claude /quit hook calling
        `slm session close`). Creates per-entity temporal summary events.
        An empty session_id closes the most recent real session.
        """
        _update_activity()
        engine = _get_engine_or_503()
        from superlocalmemory.access.rbac import Permission
        from superlocalmemory.server.rbac_enforce import require_permission
        require_permission(request, Permission.WRITE, profile=engine._profile_id)
        from superlocalmemory.server.route_mutations import (
            authorize_route_mutation,
        )
        authorization = authorize_route_mutation(
            request,
            operation="update",
            source_agent_id="http-session-close",
            profile_id=engine.profile_id,
        )
        sid = req.session_id
        if not sid:
            # Fall back to the most recent session that has memories.
            try:
                db = getattr(engine, "_db", None) or getattr(engine, "db", None)
                if db is not None and hasattr(db, "execute"):
                    rows = db.execute(
                        "SELECT session_id FROM memories "
                        "WHERE session_id != '' ORDER BY created_at DESC LIMIT 1",
                        (),
                    )
                    if rows:
                        sid = str(rows[0][0])
            except Exception as exc:
                logger.debug("session_close fallback lookup failed: %s", exc)
        if not sid:
            return {"ok": True, "session_id": "", "summary_events_created": 0,
                    "message": "no session to close"}
        try:
            created = engine.close_session(sid)
            authorization.complete()
            return {"ok": True, "session_id": sid,
                    "summary_events_created": int(created)}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))


def _update_activity():
    global _last_activity
    _last_activity = time.monotonic()


_start_time: float | None = None

# v3.6.7: Starlette app returned by mcp_server.streamable_http_app().
# Set in create_app(); consumed by lifespan() to start the session manager.
_mcp_app = None


# ---------------------------------------------------------------------------
# Server entry point
# ---------------------------------------------------------------------------

def _start_memory_watchdog() -> None:
    """v3.4.7: Background watchdog that kills child workers exceeding memory limit.

    Prevents the orphan worker memory explosion that caused 16GB+ RAM usage.
    Checks every 60 seconds. Kills workers over 2GB RSS. Auto-restarts them
    on next request (workers are lazy-spawned).
    """
    import threading

    MAX_WORKER_MB = int(os.environ.get("SLM_MAX_WORKER_MB", "2500"))

    def watchdog_loop():
        while True:
            time.sleep(15)  # V3.4.37: 15s (was 60s) — catch spikes faster
            try:
                import psutil
                parent = psutil.Process(os.getpid())
                for child in parent.children(recursive=True):
                    try:
                        rss_mb = child.memory_info().rss / (1024 * 1024)
                        if rss_mb > MAX_WORKER_MB:
                            logger.warning(
                                "Memory watchdog: killing %s (PID %d, %.0f MB > %d MB limit)",
                                child.name(), child.pid, rss_mb, MAX_WORKER_MB,
                            )
                            child.kill()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
            except ImportError:
                pass  # psutil not available — watchdog disabled
            except Exception as exc:
                logger.debug("Memory watchdog error: %s", exc)

    t = threading.Thread(target=watchdog_loop, daemon=True, name="memory-watchdog")
    t.start()
    logger.info("Memory watchdog started (limit: %d MB per worker)", MAX_WORKER_MB)


_materializer_stop = threading.Event()
_materializer_thread: threading.Thread | None = None


class _PendingProfileMismatchError(RuntimeError):
    """A legacy pending row no longer matches the admitted profile lease."""


def _version_integrity_payload() -> dict:
    """Report whether this daemon's imported code matches what is installed.

    Issue #107.  ``/health``'s ``version`` field reports the version this
    process loaded at import, so a stale daemon reports its *own* stale version
    perfectly happily -- self-consistent and useless as a staleness signal.
    This compares that against the distribution metadata on disk.

    Fail-open by construction: any error degrades to a ``state`` of
    ``"unknown"`` rather than raising, because ``/health`` is what clients poll
    to decide whether the daemon is usable and must not start returning 500s
    over a diagnostic.
    """
    try:
        from superlocalmemory.infra.version_integrity import check_version_integrity

        return check_version_integrity().as_dict()
    except Exception as exc:  # noqa: BLE001 - health must never fail on this
        return {"state": "unknown", "detail": f"version check failed: {exc}"}


def _materializer_actor_id() -> str:
    """Return the process-owned actor identity used by background writes."""
    descriptor = _ACTIVE_DAEMON_DESCRIPTOR
    if descriptor is None:
        from superlocalmemory.server.routes.helpers import SLM_VERSION

        descriptor = _process_descriptor(_DEFAULT_PORT, SLM_VERSION, "ready")
    return f"daemon-capability:{descriptor.capability_fingerprint}"


def _run_materializer_operation(
    runtime,
    engine_supplier,
    operation,
    *,
    expected_profile_id: str | None = None,
):
    """Run one bounded background unit against an admitted engine snapshot.

    Cooperative preemption: if a profile transition is already in progress,
    skip this materialization cycle entirely and return None.  The caller's
    loop retries on the next iteration, by which time the switch has committed
    and a clean admission is available.  This prevents the materializer from
    holding the operation lease during the transition drain window.
    """
    # Writer-priority: don't acquire a new lease when a transition is draining.
    if runtime is not None and runtime.transitioning:
        if expected_profile_id is not None:
            raise _PendingProfileMismatchError(
                "pending materialization deferred during profile transition"
            )
        return None
    with runtime.operation() as snapshot:
        if (
            expected_profile_id is not None
            and snapshot.profile_id != expected_profile_id
        ):
            raise _PendingProfileMismatchError(
                "pending profile changed before materializer admission"
            )
        # Resolve the engine only after admission. A concurrent mode/provider
        # reconfiguration may have replaced the module-level engine while this
        # worker was waiting at the transition barrier.
        engine = engine_supplier()
        if engine is None:
            return None
        engine_profile_id = getattr(engine, "_profile_id", None)
        if (
            expected_profile_id is not None
            and engine_profile_id != expected_profile_id
        ):
            raise _PendingProfileMismatchError(
                "resident engine does not match pending profile"
            )
        from superlocalmemory.core.recall_gate import background_work
        with background_work(
            preempt_requested=lambda: bool(runtime is not None and runtime.transitioning),
        ):
            return operation(engine)


def _reconcile_projection_manifest(
    engine, operation_id: str, profile_id: str, fact_ids,
) -> None:
    try:
        from superlocalmemory.core.transactions.concrete_owners import (
            REQUIRED_ADMISSION_OWNERS,
            build_transaction_service,
        )
        from superlocalmemory.core.transactions.owners import ObligationKind

        if not profile_id:
            return
        context = _context_for_operation(engine, operation_id)
        if context is None:
            _terminalize_orphan_operation(engine, operation_id)
            return
        service = build_transaction_service(engine)
        with engine._db.raw_connection() as conn:
            service.record(
                conn, context,
                owners=REQUIRED_ADMISSION_OWNERS,
                kind=ObligationKind.APPLY,
            )
        service.reconcile_operation(engine._db, context)
    except Exception as exc:
        logger.warning(
            "projection reconciliation skipped for %s: %s", operation_id, exc,
        )


def _context_for_operation(engine, operation_id: str):
    import json as _json

    from superlocalmemory.core.transactions.owners import OperationContext

    db = getattr(engine, "_db", None)
    if db is None:
        return None
    rows = db.execute(
        "SELECT profile_id, final_fact_ids_json, queryable_fact_ids_json "
        "FROM ingestion_operations WHERE operation_id = ?",
        (operation_id,),
    )
    if not rows:
        return None
    row = dict(rows[0])
    if row.get("profile_id") != getattr(engine, "_profile_id", None):
        return None
    try:
        fact_ids = _json.loads(row.get("final_fact_ids_json") or "[]") or _json.loads(
            row.get("queryable_fact_ids_json") or "[]"
        )
    except (TypeError, ValueError):
        return None
    if not isinstance(fact_ids, list) or not fact_ids:
        return None
    fact_ids = [str(fid) for fid in fact_ids]
    return OperationContext(
        operation_id=operation_id,
        profile_id=row["profile_id"],
        subject_id=operation_id,
        fact_ids=tuple(fact_ids),
    )


_REDRIVE_INTERVAL_S = 30.0
_last_redrive_ts = 0.0


def _reconcile_pending_projections(
    engine, *, limit: int = 20, force: bool = False,
) -> int:
    global _last_redrive_ts
    now = time.monotonic()
    if not force and now - _last_redrive_ts < _REDRIVE_INTERVAL_S:
        return 0
    _last_redrive_ts = now
    try:
        from superlocalmemory.core.transactions.concrete_owners import (
            build_transaction_service,
        )
        from superlocalmemory.core.transactions.obligations import ObligationLedger

        db = getattr(engine, "_db", None)
        profile_id = getattr(engine, "_profile_id", None)
        if db is None or not profile_id:
            return 0
        ledger = ObligationLedger()
        with db.raw_connection() as conn:
            op_ids = set(
                ledger.pending_operation_ids(conn, profile_id=profile_id, limit=limit)
            )
            op_ids.update(
                ledger.operations_missing_manifest(
                    conn, profile_id=profile_id, limit=limit,
                )
            )
        if not op_ids:
            return 0
        service = build_transaction_service(engine)
        done = 0
        for operation_id in sorted(op_ids):
            try:
                context = _context_for_operation(engine, operation_id)
                if context is None:
                    _terminalize_orphan_operation(engine, operation_id)
                    continue
                service.reconcile_operation(db, context)
                done += 1
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "projection redrive failed for %s: %s", operation_id, exc,
                )
        return done
    except Exception as exc:  # noqa: BLE001
        logger.warning("projection redrive pass skipped: %s", exc)
        return 0


def _terminalize_orphan_operation(engine, operation_id: str) -> None:
    from superlocalmemory.core.transactions.obligations import ObligationLedger
    from superlocalmemory.core.transactions.owners import ObligationState
    from superlocalmemory.core.transactions.reconciler import Reconciler
    from superlocalmemory.core.transactions.service import MAX_APPLY_ATTEMPTS

    db = getattr(engine, "_db", None)
    profile_id = getattr(engine, "_profile_id", None)
    if db is None or not profile_id:
        return
    ledger = ObligationLedger()
    with db.raw_connection() as conn:
        for obligation in ledger.fetch(conn, operation_id):
            if obligation.attempts >= MAX_APPLY_ATTEMPTS:
                continue
            ledger.mark(
                conn, operation_id, obligation.owner, obligation.kind,
                ObligationState.FAILED,
                detail={"phase": "orphan", "error": "canonical record missing"},
                bump_attempts=True,
            )
        Reconciler(ledger).reconcile(
            conn, operation_id, profile_id, canonical_committed=False,
        )


def _projection_health() -> dict:
    """Queue depth, stall count, and whether the worker is running.

    Never raises: a health endpoint that fails because one of its fields could
    not be computed is worse than the missing field.

    Takes no application. It used to accept one and never read it -- the
    orchestrator is a process singleton -- which made the signature claim a
    dependency the body did not have, and made a test that handed it a broken
    application look like it was exercising the failure path when it was only
    observing whatever the process had already built. Compare
    ``_ops_failure_counts`` directly below, which takes an application because it
    genuinely reads one.
    """
    try:
        from superlocalmemory.core.backend_orchestrator import get_orchestrator

        orchestrator = get_orchestrator()
        if orchestrator is None:
            return {"available": False}
        health = dict(orchestrator.outbox_health())
        health["available"] = True
        # One boolean an alert can key on without knowing what a healthy depth
        # looks like on this store.
        health["behind"] = bool(health.get("depth", 0)) or bool(
            health.get("stalled", 0)
        )
        return health
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "error": str(exc)[:120]}


def _ops_failure_counts(engine, application) -> dict:
    """Return operational failure counts for /status and /health.

    Always returns a dict (never raises). Counts default to 0 on any error.
    Includes: dead_letter_count, degraded_operations, exhausted_obligations,
    writer_stalled (bool), writer_stalled_op_id, writer_stalled_age_s.
    """
    result: dict = {
        "dead_letter_count": 0,
        "degraded_operations": 0,
        "exhausted_obligations": 0,
        "writer_stalled": False,
        "writer_stalled_op_id": None,
        "writer_stalled_age_s": None,
    }
    # ``application`` is explicitly passed by the route handlers.  There is no
    # module-global FastAPI app; relying on one silently returned all-zero
    # counters whenever this helper caught the resulting NameError.
    # Writer stall info from canonical coordinator
    try:
        writer_runtime = getattr(application.state, "canonical_remember_runtime", None)
        coordinator = getattr(writer_runtime, "_coordinator", None) if writer_runtime else None
        if coordinator is None:
            coordinator = getattr(application.state, "write_coordinator", None)
        if coordinator is not None and hasattr(coordinator, "inflight_info"):
            info = coordinator.inflight_info()
            result["writer_stalled"] = bool(info.get("stalled"))
            result["writer_stalled_op_id"] = info.get("op_id")
            result["writer_stalled_age_s"] = info.get("age_s")
    except Exception:
        pass

    # DB failure counts
    try:
        from superlocalmemory.core.ops_remediation import get_failure_counts
        db_path = getattr(getattr(application.state, "config", None), "db_path", None)
        if db_path is not None and db_path.exists():
            counts = get_failure_counts(db_path)
            result["dead_letter_count"] = counts.get("dead_letter_count", 0)
            result["degraded_operations"] = counts.get("degraded_operations", 0)
            result["exhausted_obligations"] = counts.get("exhausted_obligations", 0)
    except Exception:
        pass

    return result


def _materializer_should_idle(
    pending: object, durable_complete: int, durable_failed: int,
) -> bool:
    """Whether the materializer pass earned a sleep before the next one.

    ``durable_failed`` used to suppress the sleep. The pass runs one operation
    at a time, so a single operation that cannot succeed kept this loop at full
    speed indefinitely, re-reaping and re-listing on every iteration. A failure
    is activity, not progress. GitHub #137.
    """
    return not pending and not durable_complete


def _reap_stuck_ingestion(db) -> list[str]:
    """Terminalize expired enrichment leases that exhausted retries.

    Pure-SQL compare-and-swap transitions: needs no embedder, no LLM, and
    no recall quiescence — so it runs unconditionally at daemon boot and
    at the top of every materializer pass, ahead of the warmth/recall
    gates that must never gate recovery (#131). Under-attempt rows need
    no reset here; the pass reclaims them through list_materializable.
    Never raises: recovery failing must not fail startup or the pass.
    """
    try:
        from superlocalmemory.core.ingestion_command import (
            IngestionOperationRepository,
        )
        return IngestionOperationRepository(db).reap_stuck_enriching()
    except Exception as exc:
        logger.warning("ingestion stuck-lease sweep failed (non-fatal): %s", exc)
        return []


def _materialize_ingestion_one_pass(
    engine,
    *,
    limit: int = 50,
    min_queryable_age_seconds: float = 1.0,
) -> tuple[int, int]:
    """Materialize durable M018 work once; return ``(complete, failed)``."""
    # Recovery first, unconditionally: terminalizing exhausted leases is
    # pure SQL and must never wait on recall quiescence or embedder
    # warmth — a cold embedder blocked the reap forever on one operator
    # box, wedging the write pipeline until manual DB surgery (#131).
    db = getattr(engine, "_db", None)
    reaped = _reap_stuck_ingestion(db) if db is not None else []
    if reaped:
        logger.warning(
            "Materializer terminalized %d exhausted ingestion operation(s)",
            len(reaped),
        )
    # The durable queue shares the embedder/LLM with foreground recall just
    # like the legacy pending queue.  Yield before even constructing/claiming
    # work so an active user recall cannot suffer priority inversion.
    if _recalls_in_flight() > 0:
        return 0, 0

    # A local sentence-transformers cold start can take minutes.  Remember's
    # queryable projection is already durable, so defer enrichment until the
    # daemon warmup/health monitor has proved the worker ready.  This preserves
    # every enrichment layer while preventing a background cold load from
    # monopolizing the same worker needed by foreground recall.
    embedder = getattr(engine, "_embedder", None)
    if embedder is not None and hasattr(embedder, "is_warm"):
        try:
            if not bool(embedder.is_warm):
                return 0, 0
        except Exception:
            return 0, 0

    from superlocalmemory.core.engine_ingestion import build_engine_ingestion_command
    from superlocalmemory.core.ingestion_command import IngestionState

    command = build_engine_ingestion_command(engine)
    completed = failed = 0
    for operation in command.repository.list_materializable(
        limit=limit,
        min_queryable_age_seconds=min_queryable_age_seconds,
    ):
        try:
            result = command.materialize(operation.operation_id)
        except Exception as exc:
            failed += 1
            logger.warning(
                "Ingestion operation %s could not be materialized: %s",
                operation.operation_id,
                exc,
            )
            continue
        if result.state is IngestionState.COMPLETE:
            completed += 1
            _reconcile_projection_manifest(
                engine,
                result.operation_id,
                getattr(operation, "profile_id", ""),
                result.fact_ids,
            )
            _emit_event(
                "memory.stored",
                payload={
                    "operation_id": result.operation_id,
                    "fact_ids": list(result.fact_ids),
                    "path": "canonical_materializer",
                    "content_preview": result.raw_content[:120],
                },
                source_agent="materializer",
            )
        else:
            failed += 1
            logger.warning(
                "Ingestion operation %s failed: %s",
                result.operation_id,
                result.last_error,
            )
    _reconcile_pending_projections(engine)
    return completed, failed


def _materialize_legacy_pending_item(engine, item: dict) -> str:
    """Backfill one pre-M018 pending.db row through canonical ingestion."""
    from superlocalmemory.core.engine_ingestion import build_engine_ingestion_command
    from superlocalmemory.core.ingestion_command import (
        IngestionRequest,
        IngestionState,
    )

    expected_profile_id = str(item.get("profile_id") or "default")
    if getattr(engine, "_profile_id", None) != expected_profile_id:
        raise _PendingProfileMismatchError(
            "legacy pending item does not match resident engine profile"
        )

    metadata_value = item.get("metadata") or "{}"
    try:
        metadata = (
            json.loads(metadata_value)
            if isinstance(metadata_value, str)
            else dict(metadata_value)
        )
    except (TypeError, ValueError):
        metadata = {}
    if item.get("tags"):
        metadata.setdefault("tags", item["tags"])
    scope = metadata.pop("scope", None) or "personal"
    shared_with = tuple(metadata.pop("shared_with", None) or ())
    source_type = str(metadata.pop("_slm_source_type", "legacy-pending"))
    idempotency_key = str(
        metadata.pop("_slm_idempotency_key", f"pending:{item['id']}")
    )
    command = build_engine_ingestion_command(engine)
    receipt = command.submit(IngestionRequest(
        content=item["content"],
        profile_id=expected_profile_id,
        source_type=source_type,
        idempotency_key=idempotency_key,
        metadata=metadata,
        scope=scope,
        shared_with=shared_with,
        trusted_actor_id=_materializer_actor_id(),
        session_id=str(metadata.get("session_id") or ""),
    ))
    result = command.materialize(receipt.operation_id)
    if result.state is not IngestionState.COMPLETE:
        raise RuntimeError(result.last_error or "legacy pending materialization failed")
    return result.operation_id


def _start_pending_materializer() -> None:
    """Drain M018 operations and backfill the legacy pending.db queue."""
    global _materializer_thread

    if _materializer_thread is not None and _materializer_thread.is_alive():
        return
    _materializer_stop.clear()

    def _loop():
        from superlocalmemory.cli.pending_store import (
            get_pending,
            mark_done,
            mark_failed,
        )
        # v3.4.38: log first engine acquisition so we know materializer is alive
        _engine_logged = False
        _waiting_logged = False
        while not _materializer_stop.is_set():
            try:
                # v3.4.38: Read fresh module global on every iteration so we
                # pick up the engine after lifespan sets it. Use the import
                # trick to ensure we're reading the live module attribute,
                # not a stale local reference.
                import superlocalmemory.server.unified_daemon as _ud
                engine = _ud._engine
                runtime = _ud._profile_runtime
                if engine is None or runtime is None:
                    if not _waiting_logged:
                        logger.info(
                            "Materializer: waiting for engine/runtime to init..."
                        )
                        _waiting_logged = True
                    time.sleep(0.5)
                    continue
                if not _engine_logged:
                    logger.info("Materializer: engine acquired, starting drain loop")
                    _engine_logged = True

                cycle_result = _run_materializer_operation(
                    runtime,
                    lambda: _ud._engine,
                    lambda admitted_engine: _materialize_ingestion_one_pass(
                        admitted_engine,
                        # One operation per lease bounds profile-switch wait
                        # time without allowing engine components to rebind
                        # halfway through an enrichment pipeline.
                        limit=1,
                    ),
                )
                durable_complete, durable_failed = cycle_result or (0, 0)
                # Only backfill legacy pending items enqueued under the active
                # profile — never materialize another profile's queued memory
                # under whichever profile happens to be active now.
                _active_profile = runtime.snapshot.profile_id
                pending = get_pending(limit=50, profile_id=_active_profile)
                if _materializer_should_idle(
                    pending, durable_complete, durable_failed,
                ):
                    time.sleep(1.0)
                    continue
                if pending:
                    logger.info(
                        "Materializer: backfilling %d legacy pending memories",
                        len(pending),
                    )
                for item in pending:
                    if _materializer_stop.is_set():
                        break
                    waits = 0
                    while _recalls_in_flight() > 0 and waits < 60:
                        time.sleep(0.5)
                        waits += 1
                    try:
                        pending_profile_id = str(
                            item.get("profile_id") or "default"
                        )
                        operation_id = _run_materializer_operation(
                            runtime,
                            lambda: _ud._engine,
                            lambda admitted_engine: _materialize_legacy_pending_item(
                                admitted_engine, item,
                            ),
                            expected_profile_id=pending_profile_id,
                        )
                        if operation_id is None:
                            raise RuntimeError("resident engine became unavailable")
                        mark_done(item["id"])
                        _emit_event(
                            "memory.stored",
                            payload={
                                "pending_id": item["id"],
                                "operation_id": operation_id,
                                "path": "legacy_pending_backfill",
                                "content_preview": item["content"][:120],
                            },
                            source_agent="materializer",
                        )
                    except _PendingProfileMismatchError:
                        # A profile transition committed after this row was
                        # fetched but before it obtained an operation lease.
                        # Leave it pending, without consuming a retry, so the
                        # owning profile can safely drain it later.
                        logger.debug(
                            "Pending %d deferred after profile switch",
                            item["id"],
                        )
                    except Exception as exc:
                        logger.warning(
                            "Pending %d failed: %s", item["id"], exc,
                        )
                        mark_failed(item["id"], str(exc))
            except Exception as exc:
                logger.warning("materializer loop error: %s", exc)
                time.sleep(5.0)

    _materializer_thread = threading.Thread(
        target=_loop, daemon=True, name="pending-materializer",
    )
    _materializer_thread.start()
    logger.info("Pending materializer started (recall-priority)")


def _stop_pending_materializer(timeout: float = 5.0) -> bool:
    """Stop and join the background writer before closing its engine."""
    global _materializer_thread

    _materializer_stop.set()
    thread = _materializer_thread
    if thread is not None and thread.is_alive():
        thread.join(timeout=timeout)
        if thread.is_alive():
            logger.warning("Pending materializer did not stop within %.1fs", timeout)
            return False
    _materializer_thread = None
    return True


_thread_dump_file = None


def install_thread_dump_signal() -> "os.PathLike | str | None":
    """Make ``kill -USR1 <pid>`` dump every Python thread's stack to a file.

    WHY THIS EXISTS. #137 was a 100%-CPU daemon, and on the two machines it was
    investigated on, nobody could see inside the process. macOS needs root for
    ``task_for_pid``, so py-spy is unavailable to any user not in sudoers --
    which on a managed corporate Mac is the normal case, and was the case for
    the author. The reporter on Ubuntu got py-spy attached and it was still
    blind to the threads that mattered, so they fell back to ``gdb``. Between
    them that is every standard tool defeated, for a defect whose entire
    signature is "which thread is busy, doing what".

    ``faulthandler`` needs no root, no attach, and no install: the process
    dumps its own stacks on a signal it registered itself.

    WHAT IT DOES NOT SHOW, said plainly: Python frames only. A native thread
    with no Python frame -- a LanceDB tokio worker, for instance -- is
    invisible here exactly as it was to py-spy. What it does show is which
    Python thread is where, which is the question that went unanswered for
    eleven days on the author's own machine.

    Returns the dump path, or None where the platform has no SIGUSR1.
    """
    global _thread_dump_file
    if not hasattr(signal, "SIGUSR1"):
        return None
    try:
        import faulthandler

        from superlocalmemory.infra.data_root import state_path

        path = state_path("thread-dump.log")
        # Held on a module global on purpose: faulthandler keeps the raw file
        # descriptor, so a closed or garbage-collected handle turns the next
        # signal into a crash instead of a diagnostic.
        _thread_dump_file = open(path, "a", buffering=1)  # noqa: SIM115
        faulthandler.register(
            signal.SIGUSR1, file=_thread_dump_file,
            all_threads=True, chain=False,
        )
        logger.info(
            "thread dump armed: kill -USR1 %d  ->  %s", os.getpid(), path,
        )
        return path
    except Exception:  # noqa: BLE001 -- a diagnostic must never block start
        logger.debug("thread dump handler not installed", exc_info=True)
        return None


def start_server(port: int = _DEFAULT_PORT) -> None:
    """Start the unified daemon. Blocks until stopped."""
    global _start_time
    install_thread_dump_signal()
    assert_no_durable_root_conflict()
    import socket

    import uvicorn

    # Bind before any migration or engine work.  A process which cannot own
    # the listener must not open the user's databases or publish lifecycle
    # state: otherwise a stale service and a manual restart can briefly run
    # two engines against one SQLite root.
    bind_host = (
        os.environ.get("SLM_DAEMON_HOST")
        or os.environ.get("SLM_HOST")
        or "127.0.0.1"
    )
    # M-01 / L-02 (3.7.9): binding beyond loopback exposes the write API to the
    # network, where the loopback trusted-actor bypass no longer protects it.
    # Warn loudly unless the operator has opted into credential enforcement.
    if bind_host not in ("127.0.0.1", "::1", "localhost") and \
            os.environ.get("SLM_REQUIRE_CREDENTIALS") != "1":
        logger.warning(
            "SLM daemon binding to %s (non-loopback): the write API is "
            "reachable from the network but SLM_REQUIRE_CREDENTIALS is not set "
            "and API-key auth may be off. A remote caller could write without "
            "credentials. Set SLM_REQUIRE_CREDENTIALS=1 and configure an API "
            "key before exposing this instance. "
            "NOTE (issue #90): SLM 3.8.4 fixes IPv4-mapped loopback address "
            "normalization — if curl/dashboard writes fail with 403 from a "
            "container, upgrade to 3.8.4. Immediate workaround: set "
            "SLM_DAEMON_HOST=127.0.0.1 (IPv4 only) or configure an API key.",
            bind_host,
        )
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # This handles a just-closed connection in TIME_WAIT.  It is safe only
    # with the active-listener probe immediately below; without that guard,
    # macOS can permit a second SO_REUSEADDR listener on the same port.
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.5)
            if probe.connect_ex(("127.0.0.1", port)) == 0:
                raise OSError("an active daemon listener already owns the port")
        listener.bind((bind_host, port))
        listener.listen(socket.SOMAXCONN)
    except OSError as exc:
        listener.close()
        logger.error(
            "SLM daemon will not start: %s:%d is already unavailable (%s)",
            bind_host, port, exc,
        )
        return
    # The lifespan uses the configured port for its identity and health
    # payload, so a CLI --port must be reflected there as well.
    os.environ["SLM_DAEMON_PORT"] = str(port)

    # v3.4.23: rotate oversized logs before anything else so both the CLI
    # path (`slm serve`) and the LaunchAgent path (__main__) are covered.
    try:
        rotate_oversized_logs()
    except Exception:
        pass  # never block startup on log housekeeping

    from superlocalmemory.server.routes.helpers import SLM_VERSION

    _publish_process_descriptor(port, SLM_VERSION, "starting")
    _start_time = time.monotonic()

    try:
        from superlocalmemory.migrations.v3_4_25_to_v3_4_26 import (
            is_ready as _is_ready,
        )
        from superlocalmemory.migrations.v3_4_25_to_v3_4_26 import (
            migrate as _migrate,
        )
        _data = canonical_data_root()
        if not _is_ready(_data):
            _migrate(_data)
    except Exception as exc:
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "v3.4.26 migration on daemon start failed: %s", exc,
        )

    # v3.4.7: Start memory watchdog to prevent runaway workers
    _start_memory_watchdog()

    # v3.4.32: Continuous pending-queue materializer with recall priority.
    _start_pending_materializer()

    log_dir = state_path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)

    config = uvicorn.Config(
        app="superlocalmemory.server.unified_daemon:create_app",
        factory=True,
        host=bind_host,
        port=port,
        log_level="warning",
        timeout_graceful_shutdown=10,
    )
    server = uvicorn.Server(config)

    try:
        server.run(sockets=[listener])
    finally:
        listener.close()
        _cleanup_process_descriptor(_ACTIVE_DAEMON_DESCRIPTOR)


# ---------------------------------------------------------------------------
# v3.4.23 — Startup log rotation
# ---------------------------------------------------------------------------
# The LaunchAgent plist redirects stdout/stderr to daemon.log and
# daemon-error.log. Those files are managed by launchd, not Python, so
# Python's RotatingFileHandler cannot prune them. If any bug ever writes
# large amounts of data to stderr (the v3.4.22 logger-format bug produced
# ~30 KB per startup and the file grew to 69 MB), end users end up with a
# disk-eating log they never knew existed.
#
# rotate_oversized_logs() is a belt-and-suspenders guard: every time the
# daemon starts, if either log exceeds MAX_LOG_BYTES we rename the current
# file to ".1" (keeping one rotated copy) and truncate the original so
# launchd's open file descriptor keeps working. This is cheap, stateless,
# and independent of whatever caused the overflow.
# ---------------------------------------------------------------------------

_MAX_LOG_BYTES = 10 * 1024 * 1024  # 10 MB


def rotate_oversized_logs(log_dir: Optional[Path] = None,
                          max_bytes: int = _MAX_LOG_BYTES) -> None:
    """Rotate daemon.log and daemon-error.log at startup if oversized.

    Keeps one rotated copy (.1). Safe under concurrent start attempts:
    rename is atomic on POSIX, and truncation is idempotent.
    """
    log_dir = log_dir or state_path("logs")
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        return
    for name in ("daemon.log", "daemon-error.log", "daemon.json.log"):
        path = log_dir / name
        try:
            if not path.exists() or path.stat().st_size <= max_bytes:
                continue
            rotated = log_dir / f"{name}.1"
            try:
                if rotated.exists():
                    rotated.unlink()
            except Exception:
                pass
            try:
                path.rename(rotated)
            except Exception:
                # If rename fails (e.g., file is the open stderr fd under
                # launchd), fall back to truncation so we at least reclaim
                # disk without breaking the redirect.
                try:
                    with open(path, "w"):
                        pass
                except Exception:
                    pass
                continue
            # Re-create the original path as empty so launchd's redirect
            # keeps appending to a fresh file.
            try:
                path.touch()
            except Exception:
                pass
        except Exception:
            # Log rotation must never prevent daemon startup.
            continue


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Rotate first, then configure logging, so the first log line lands in a
    # freshly-sized file.
    rotate_oversized_logs()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    # v3.6.9 (#33): honour SLM_DAEMON_PORT env so operators can configure the
    # port without changing the launch command. --port= arg takes precedence.
    port = int(os.environ.get("SLM_DAEMON_PORT", "") or _DEFAULT_PORT)
    for arg in sys.argv:
        if arg.startswith("--port="):
            port = int(arg.split("=")[1])
    if "--start" in sys.argv:
        start_server(port=port)
    else:
        print("Usage: python -m superlocalmemory.server.unified_daemon --start [--port=8765]")
