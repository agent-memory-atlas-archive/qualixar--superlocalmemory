# compress/ccr.py
# Copyright (c) 2026 Varun Pratap Bhardwaj / Qualixar
# Licensed under AGPL-3.0-or-later
#
# Storage: llmcache_ccr table defined in INTERFACE-CONTRACT §1.
# Database access: CacheDB.ccr_put() and CacheDB.ccr_get() per INTERFACE-CONTRACT §1.

"""CCRStore — stores pre-compression originals, provides retrieval tool."""

from __future__ import annotations

import logging
import re
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from superlocalmemory.optimize.storage.db import CacheDB

logger = logging.getLogger("slm.optimize.compress.ccr")

# SEC-C-04: UUID4 format validator — only ^UUID4^ values pass
_UUID4_RE = re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
)


class CCRStore:
    """Stores compression originals and retrieves them by ccr_id.

    Thread-safe. Singleton per daemon instance.
    """

    _instance: "CCRStore | None" = None
    _lock: threading.Lock = threading.Lock()

    @classmethod
    def get_instance(cls) -> "CCRStore":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def __init__(self) -> None:
        self._db: "CacheDB | None" = None

    def store(
        self,
        original: bytes,
        model: str = "",
        tenant_id: str = "default",
        ttl_seconds: int | None = None,
    ) -> str:
        """Store a pre-compression original. Returns ccr_id (UUID4) or '' on failure.

        B-03: Called BEFORE compression runs.
        RB-05: Only original bytes accepted; compressed bytes stored via update_compressed().
        """
        try:
            import uuid as _uuid_mod
            import time as _time_mod
            ccr_id = str(_uuid_mod.uuid4())
            db = self._get_db()
            ttl_expires = (
                _time_mod.time() + ttl_seconds
                if ttl_seconds is not None
                else None
            )
            db.ccr_put(ccr_id, original, ttl_expires=ttl_expires, tenant_id=tenant_id)
            logger.debug("CCR stored ccr_id=%s orig_bytes=%d tenant=%s", ccr_id, len(original), tenant_id)
            return ccr_id
        except Exception as exc:
            logger.warning("CCRStore.store failed (fail-open): %s", exc)
            return ""

    def update_compressed(self, ccr_id: str, compressed_bytes: bytes) -> None:
        """Update the compressed_hash for an existing CCR row. Non-fatal if fails."""
        try:
            db = self._get_db()
            if hasattr(db, "ccr_update_compressed"):
                db.ccr_update_compressed(ccr_id, compressed_bytes)
        except Exception as exc:
            logger.debug("CCRStore.update_compressed failed (non-fatal): %s", exc)

    def retrieve(self, ccr_id: str, *, tenant_id: str = "default") -> bytes | None:
        """Retrieve a CCR original by ccr_id scoped to tenant. Returns None if not found or TTL expired.

        H-02: tenant_id enforces row-level isolation — a caller cannot retrieve
        content stored under a different tenant's scope.
        """
        try:
            db = self._get_db()
            return db.ccr_get(ccr_id, tenant_id=tenant_id)
        except Exception as exc:
            logger.warning("CCRStore.retrieve failed (ccr_id=%s): %s", ccr_id, exc)
            return None

    def delete(self, ccr_id: str, *, tenant_id: str = "default") -> None:
        """Delete a CCR row by ccr_id scoped to tenant. Idempotent — never raises.

        Defensive delete — idempotent: deleting a non-existent ccr_id is a no-op.
        H-02: tenant_id guard prevents cross-tenant deletion.
        """
        try:
            db = self._get_db()
            db.ccr_delete(ccr_id, tenant_id=tenant_id)
            logger.debug("CCR deleted ccr_id=%s tenant=%s", ccr_id, tenant_id)
        except Exception as exc:
            logger.warning("CCRStore.delete failed (non-fatal): %s", exc)

    def _get_db(self) -> "CacheDB":
        if self._db is None:
            from superlocalmemory.optimize.storage.db import CacheDB
            self._db = CacheDB()
        return self._db
